<?php
return array (
  '<b>No public contents to display found!</b>' => '<b>Geen openbare inhoud gevonden!</b>',
);
