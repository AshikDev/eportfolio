<?php
return array (
  '<b>Your dashboard is empty!</b><br>Post something on your profile or join some spaces!' => '<b>Uw dashboard is leeg!</b><br>Plaats een bericht op uw profiel of word lid van een aantal ruimtes!',
);
