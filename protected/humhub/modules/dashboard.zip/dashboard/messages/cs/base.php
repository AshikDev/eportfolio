<?php
return array (
  'Dashboard' => 'Nástěnka',
);
