<?php
return array (
  '<b>No public contents to display found!</b>' => '<b>Nebyly nalezeny žádné veřejné příspěvky!</b>',
);
