<?php
return array (
  '<b>Your dashboard is empty!</b><br>Post something on your profile or join some spaces!' => '<b>የመከወኛ ሰሌዳዎ ባዶ ነው!</b><br>በግል መረጃዎ ላይ የሆነ ነገር ይለጥፉ ወይም የተወሰኑ ምህዳሮችን ይቀላቀሉ!',
);
