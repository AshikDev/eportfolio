<?php
return array (
  '<b>No public contents to display found!</b>' => '<b>ምንም አይነት በይፋ የሚቀርብ ይዘት አልተገኘም!</b>',
);
