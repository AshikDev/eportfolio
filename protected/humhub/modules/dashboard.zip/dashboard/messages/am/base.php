<?php
return array (
  'Dashboard' => 'የመከወኛሰሌዳ',
);
