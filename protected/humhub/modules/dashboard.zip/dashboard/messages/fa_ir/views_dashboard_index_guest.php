<?php
return array (
  '<b>No public contents to display found!</b>' => '<b>هیچ محتوای عمومی‌ای برای نمایش یافت نشد!</b>',
);
