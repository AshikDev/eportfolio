<?php
return array (
  'Dashboard' => 'خانه',
);
