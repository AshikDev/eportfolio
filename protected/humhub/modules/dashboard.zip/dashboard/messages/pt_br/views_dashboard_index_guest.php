<?php
return array (
  '<b>No public contents to display found!</b>' => '<b>Nenhum conteúdo foi encontrado!</b>',
);
