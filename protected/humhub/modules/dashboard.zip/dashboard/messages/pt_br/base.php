<?php
return array (
  'Dashboard' => 'Painel',
);
