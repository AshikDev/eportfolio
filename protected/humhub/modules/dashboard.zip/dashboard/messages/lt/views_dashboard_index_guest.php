<?php
return array (
  '<b>No public contents to display found!</b>' => '<b>Nerasta viešojo turinio!</b>
',
);
