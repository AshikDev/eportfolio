<?php
return array (
  'Dashboard' => 'Valdymo skydelis',
);
