<?php
return array (
  '<b>No public contents to display found!</b>' => '<b>Keine öffentlichen Inhalte gefunden!</b>',
);
