<?php
return array (
  'Dashboard' => 'Übersicht',
);
