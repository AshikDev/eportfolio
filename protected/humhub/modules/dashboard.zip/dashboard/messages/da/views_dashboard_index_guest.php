<?php
return array (
  '<b>No public contents to display found!</b>' => '<b>Intet offentligt indhold er fundet!</b>',
);
