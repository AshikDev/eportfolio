<?php
return array (
  'Dashboard' => 'Dashboard',
);
