<?php
return array (
  'Dashboard' => 'Ταμπλό',
);
