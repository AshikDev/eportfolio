<?php
return array (
  '<b>Your dashboard is empty!</b><br>Post something on your profile or join some spaces!' => '<b>Din oversikt er tom!</b><br>Post noe på din profil eller meld deg inn i noen grupper!',
);
