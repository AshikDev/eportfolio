<?php
return array (
  '<b>No public contents to display found!</b>' => '<b>Ingen åpne innlegg funnet!</b>',
);
