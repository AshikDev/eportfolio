<?php
return array (
  'Dashboard' => 'Oversikt',
);
