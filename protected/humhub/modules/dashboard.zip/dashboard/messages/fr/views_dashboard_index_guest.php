<?php
return array (
  '<b>No public contents to display found!</b>' => '<b>Aucun contenu public à afficher actuellement.</b>',
);
