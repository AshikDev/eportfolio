<?php
return array (
  'Dashboard' => 'Fil d\'actualités',
);
