<?php
return array (
  '<b>Your dashboard is empty!</b><br>Post something on your profile or join some spaces!' => '<b>Votre fil d\'actualités est vide.</b><br>Publiez quelque chose sur votre profil ou rejoignez des espaces.',
);
