<?php
return array (
  'Dashboard' => 'Panel',
);
