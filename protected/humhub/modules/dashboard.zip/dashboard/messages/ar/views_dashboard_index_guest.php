<?php
return array (
  '<b>No public contents to display found!</b>' => '<b>لا توجد مواضيع منشورة للعامة في الوقت الحالي, حاول تسجيل الدخول او العودة لاحقاً.</b>',
);
