<?php
return array (
  'Dashboard' => 'سطح المكتب',
);
