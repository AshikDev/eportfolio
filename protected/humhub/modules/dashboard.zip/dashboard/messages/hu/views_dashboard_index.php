<?php
return array (
  '<b>Your dashboard is empty!</b><br>Post something on your profile or join some spaces!' => '<b>Még nincs mit áttekinteni!</b><br />Hozz létre egy bejegyzést a profilodban, vagy lépj be néhány közösségbe!',
);
