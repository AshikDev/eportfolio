<?php
return array (
  'Dashboard' => 'Áttekintés',
);
