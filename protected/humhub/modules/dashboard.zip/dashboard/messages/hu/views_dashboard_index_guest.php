<?php
return array (
  '<b>No public contents to display found!</b>' => '<b>Nincs megjeleníthető nyilvános tartalom.</b>',
);
