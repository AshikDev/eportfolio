<?php
return array (
  'Dashboard' => 'Informācijas panelis',
);
