<?php
return array (
  '<b>Your dashboard is empty!</b><br>Post something on your profile or join some spaces!' => '<b>Tavs informācijas panelis ir tukšs!</b><br>Publicē kaut ko savā profilā, vai pievienojies kādai vietai!',
);
