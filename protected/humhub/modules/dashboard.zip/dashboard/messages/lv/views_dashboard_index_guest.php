<?php
return array (
  '<b>No public contents to display found!</b>' => '<b>Nav atrasts publisks saturs ko parādīt!</b>',
);
