<?php
return array (
  'Dashboard' => 'ダッシュボード',
);
