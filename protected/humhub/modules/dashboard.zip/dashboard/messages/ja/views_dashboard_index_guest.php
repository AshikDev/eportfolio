<?php
return array (
  '<b>No public contents to display found!</b>' => 'お見せできるようなコンテンツはまだないようですが、気をおとさず間をおいて再訪問してみましょう。',
);
