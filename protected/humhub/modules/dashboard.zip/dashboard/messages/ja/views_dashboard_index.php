<?php
return array (
  '<b>Your dashboard is empty!</b><br>Post something on your profile or join some spaces!' => 'おっと、この部分にはまだ何も表示されていませんね。プロフィールに何か書き込んでみたり、掲示版（スペース）に参加したりと、活動してみましょう。',
);
