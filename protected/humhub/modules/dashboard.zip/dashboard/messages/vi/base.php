<?php
return array (
  'Dashboard' => 'Trang chính',
);
