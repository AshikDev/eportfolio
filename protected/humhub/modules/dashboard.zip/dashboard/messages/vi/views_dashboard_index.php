<?php
return array (
  '<b>Your dashboard is empty!</b><br>Post something on your profile or join some spaces!' => '<b>Trang chính của bạn chưa có nội dung!</b><br>Hãy viết một vài điều ở trang cá nhân của bạn hoặc trong phòng làm việc nào đó mà bạn tham gia!',
);
