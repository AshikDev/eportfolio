<?php
return array (
  '<b>No public contents to display found!</b>' => '<b>Không tìm thấy nội dung công cộng nào!</b>',
);
