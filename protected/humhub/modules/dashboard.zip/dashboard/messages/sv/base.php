<?php
return array (
  'Dashboard' => 'Tidslinje',
);
