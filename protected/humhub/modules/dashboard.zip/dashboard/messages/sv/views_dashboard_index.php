<?php
return array (
  '<b>Your dashboard is empty!</b><br>Post something on your profile or join some spaces!' => '<b>Din tidslinje är tom!</b><br />Posta något i din profil eller gå med i ett nätverk!',
);
