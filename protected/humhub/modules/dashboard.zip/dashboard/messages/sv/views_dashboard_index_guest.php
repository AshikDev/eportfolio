<?php
return array (
  '<b>No public contents to display found!</b>' => '<b>Inget publikt innehåll kunde hittas!</b>',
);
