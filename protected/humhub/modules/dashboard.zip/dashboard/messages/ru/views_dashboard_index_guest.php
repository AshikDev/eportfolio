<?php
return array (
  '<b>No public contents to display found!</b>' => '<b>Открытого контента для отображения не найдено!</b>',
);
