<?php
return array (
  'Dashboard' => 'События',
);
