<?php
return array (
  '<b>No public contents to display found!</b>' => '<b>Nessun contenuto pubblico da visualizzare trovato!</b>',
);
