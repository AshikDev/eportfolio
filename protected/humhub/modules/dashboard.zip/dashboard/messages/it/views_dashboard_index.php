<?php
return array (
  '<b>Your dashboard is empty!</b><br>Post something on your profile or join some spaces!' => '<b>La tua bacheca è vuota!</b><br>Scrivi qualcosa sul tuo profilo o unisciti a qualche spazio!',
);
