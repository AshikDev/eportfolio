<?php
return array (
  'Dashboard' => 'Bacheca',
);
