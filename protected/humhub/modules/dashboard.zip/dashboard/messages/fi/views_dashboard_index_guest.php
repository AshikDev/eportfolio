<?php
return array (
  '<b>No public contents to display found!</b>' => 'Julkista tieto ei ole!',
);
