<?php
return array (
  'Dashboard' => 'Etusivu',
);
