<?php
return array (
  'Dashboard' => 'Inici',
);
