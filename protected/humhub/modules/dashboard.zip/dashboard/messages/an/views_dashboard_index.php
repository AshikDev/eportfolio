<?php
return array (
  '<b>Your dashboard is empty!</b><br>Post something on your profile or join some spaces!' => '<b>O tuyo inicio ye vuedo!</b><br>Publica bella cosa en o tuyo perfil u une-te a bell espacio!',
);
