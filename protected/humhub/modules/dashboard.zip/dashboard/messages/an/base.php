<?php
return array (
  'Dashboard' => 'Inicio',
);
