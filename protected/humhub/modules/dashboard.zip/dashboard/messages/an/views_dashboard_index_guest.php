<?php
return array (
  '<b>No public contents to display found!</b>' => '<b>No s\'ha trobau garra conteniu publico!</b>',
);
