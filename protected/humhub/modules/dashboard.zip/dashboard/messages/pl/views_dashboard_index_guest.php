<?php
return array (
  '<b>No public contents to display found!</b>' => '<b>Nie znaleziono publicznie dostępnych treści!</b>',
);
