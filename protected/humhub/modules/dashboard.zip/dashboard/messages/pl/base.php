<?php
return array (
  'Dashboard' => 'Kokpit',
);
