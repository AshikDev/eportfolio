<?php
return array (
  '<b>No public contents to display found!</b>' => '<b>Nu există conținut public de afișat!</b>',
);
