<?php
return array (
  'Dashboard' => 'Panou',
);
