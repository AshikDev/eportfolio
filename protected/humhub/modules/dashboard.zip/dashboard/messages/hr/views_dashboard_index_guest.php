<?php
return array (
  '<b>No public contents to display found!</b>' => '<b>Nije pronađen sadržaj za javnu objavu!</b>',
);
