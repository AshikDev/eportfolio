<?php
return array (
  'Dashboard' => 'Upravljačka ploča',
);
