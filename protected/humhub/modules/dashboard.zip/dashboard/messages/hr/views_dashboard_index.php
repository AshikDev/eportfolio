<?php
return array (
  '<b>Your dashboard is empty!</b><br>Post something on your profile or join some spaces!' => '<b>Vaša upravljačka ploča je prazna!</b><br> Objavlite nešto na vašem profilu ili se pridružite nekim prostorima!',
);
