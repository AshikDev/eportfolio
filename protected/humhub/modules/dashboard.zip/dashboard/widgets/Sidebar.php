<?php

/**
 * @link https://www.humhub.org/
 * @copyright Copyright (c) 2016 HumHub GmbH & Co. KG
 * @license https://www.humhub.com/licences
 */

namespace humhub\modules\dashboard\widgets;

use humhub\widgets\BaseSidebar;

/**
 * Sidebar implements the dashboards sidebar
 */
class Sidebar extends BaseSidebar
{
    
}
