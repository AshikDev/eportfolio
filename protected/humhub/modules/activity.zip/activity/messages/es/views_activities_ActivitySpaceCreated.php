<?php
return array (
  '%displayName% created the new space %spaceName%' => '%displayName% creó un nuevo espacio: %spaceName%',
  '%displayName% created this space.' => '%displayName% creó este espacio.',
);
