<?php
return array (
  'See online:' => 'Ver en línea:',
  'see online' => 'ver en línea',
  'via' => 'en',
);
