<?php
return array (
  '%displayName% left the space %spaceName%' => '%displayName% dejó el espacio %spaceName%',
  '%displayName% left this space.' => '%displayName% dejó este espacio.',
);
