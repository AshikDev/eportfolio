<?php
return array (
  '%displayName% created the new space %spaceName%' => '%displayName% izveidoja jaunu vietu %spaceName%',
  '%displayName% created this space.' => '%displayName% izveidoja šo vietu.',
);
