<?php
return array (
  '<strong>Latest</strong> activities' => '<strong>Pēdējās</strong> aktivitātes',
  'There are no activities yet.' => 'Šeit pašlaik nav aktivitāšu.',
);
