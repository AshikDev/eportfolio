<?php
return array (
  '%displayName% left the space %spaceName%' => '%displayName% pameta vietu %spaceName%',
  '%displayName% left this space.' => '%displayName% pameta šo vietu.',
);
