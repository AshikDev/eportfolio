<?php
return array (
  'See online:' => 'Skatīties tiešsaistē:',
  'see online' => 'skatīties tiešsaistē',
  'via' => 'caur',
);
