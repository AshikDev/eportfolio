<?php
return array (
  '%displayName% created the new space %spaceName%' => '%displayName% hat einen neuen Space »%spaceName%« erstellt.',
  '%displayName% created this space.' => '%displayName% hat diesen Space erstellt.',
);
