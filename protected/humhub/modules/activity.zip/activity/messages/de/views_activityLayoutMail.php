<?php
return array (
  'See online:' => 'Online ansehen:',
  'see online' => 'online ansehen',
  'via' => 'via',
);
