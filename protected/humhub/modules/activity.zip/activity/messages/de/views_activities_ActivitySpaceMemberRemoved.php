<?php
return array (
  '%displayName% left the space %spaceName%' => '%displayName% hat den Space »%spaceName%« verlassen',
  '%displayName% left this space.' => '%displayName% hat diesen Space verlassen.',
);
