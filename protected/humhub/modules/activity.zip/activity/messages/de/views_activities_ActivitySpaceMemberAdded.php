<?php
return array (
  '%displayName% joined the space %spaceName%' => '%displayName% ist dem Space »%spaceName%« beigetreten',
  '%displayName% joined this space.' => '%displayName% ist diesem Space beigetreten.',
  '%spaceName% has been archived' => '%spaceName% wurde archiviert',
  '%spaceName% has been unarchived' => 'Die Archivierung im Space %spaceName% wurde zurückgenommen',
);
