<?php
return array (
  '%displayName% joined the space %spaceName%' => '%displayName% a rejoint l\'espace %spaceName%',
  '%displayName% joined this space.' => '%displayName% a rejoint cet espace.',
  '%spaceName% has been archived' => '%spaceName% a été archivé',
  '%spaceName% has been unarchived' => '%spaceName% a été désarchivé',
);
