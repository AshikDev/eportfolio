<?php
return array (
  '<strong>Latest</strong> activities' => '<strong>Activité</strong> récente',
  'There are no activities yet.' => 'Il n\'y a pas d\'activité.',
);
