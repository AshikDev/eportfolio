<?php
return array (
  '{user1} now follows {user2}.' => '{user1} suit maintenant {user2}.',
);
