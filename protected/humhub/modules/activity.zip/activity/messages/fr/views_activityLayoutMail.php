<?php
return array (
  'See online:' => 'Voir en ligne : ',
  'see online' => 'voir en ligne',
  'via' => 'depuis',
);
