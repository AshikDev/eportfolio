<?php
return array (
  '<strong>Latest</strong> activities' => '<strong>Viimeisimmät</strong> tapahtumat',
  'There are no activities yet.' => 'Täällä ei ole tapahtumia.',
);
