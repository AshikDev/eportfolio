<?php
return array (
  '%displayName% left the space %spaceName%' => '%displayName% lähti sivulta %spaceName%',
  '%displayName% left this space.' => '%displayName% lähti tältä sivulta.',
);
