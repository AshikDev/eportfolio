<?php
return array (
  '%displayName% joined the space %spaceName%' => '%displayName% liityi sivulle %spaceName%',
  '%displayName% joined this space.' => '%displayName% liityi tälle sivulle.',
  '%spaceName% has been archived' => '%spaceName% arkistoitiin',
  '%spaceName% has been unarchived' => '%spaceName% arkistointi poistettiin',
);
