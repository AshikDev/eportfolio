<?php
return array (
  '%displayName% created the new space %spaceName%' => '%displayName% loi uuden sivun %spaceName%',
  '%displayName% created this space.' => '%displayName% loi tämän sivun.',
);
