<?php
return array (
  'See online:' => 'Näytä verkossa:',
  'see online' => 'näytä verkossa',
  'via' => 'kautta',
);
