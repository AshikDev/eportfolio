<?php
return array (
  '%displayName% left the space %spaceName%' => '%displayName% kilépett a(z) %spaceName% közösségből',
  '%displayName% left this space.' => '%displayName% kilépett ebből a közösségből.',
);
