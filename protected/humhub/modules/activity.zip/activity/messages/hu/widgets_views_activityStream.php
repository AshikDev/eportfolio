<?php
return array (
  '<strong>Latest</strong> activities' => '<strong>Legfrissebb</strong> tevékenységek',
  'There are no activities yet.' => 'Még nem történt semmi.',
);
