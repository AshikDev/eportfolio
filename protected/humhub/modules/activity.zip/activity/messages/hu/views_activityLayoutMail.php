<?php
return array (
  'See online:' => 'Online megtekintés:',
  'see online' => 'online megtekint',
  'via' => 'keresztül',
);
