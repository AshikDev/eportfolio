<?php
return array (
  '%displayName% joined the space %spaceName%' => '%displayName% csatlakozott a(z) %spaceName% közösséghez.',
  '%displayName% joined this space.' => '%displayName% csatlakozott ehhez a közösséghez.',
  '%spaceName% has been archived' => '%spaceName% archiválásra került',
  '%spaceName% has been unarchived' => '%spaceName% kikerült az archiválásból',
);
