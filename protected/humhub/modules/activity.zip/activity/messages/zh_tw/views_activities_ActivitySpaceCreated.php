<?php
return array (
  '%displayName% created the new space %spaceName%' => '%displayName% 創建了 %spaceName% 新空間',
  '%displayName% created this space.' => '%displayName% 創建此空間',
);
