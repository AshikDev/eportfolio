<?php
return array (
  'See online:' => '',
  'see online' => '在線查看',
  'via' => '通過',
);
