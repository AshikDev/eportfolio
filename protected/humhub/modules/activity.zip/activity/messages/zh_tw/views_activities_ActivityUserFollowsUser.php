<?php
return array (
  '{user1} now follows {user2}.' => '{user1} 現在跟隨 {user2}.',
);
