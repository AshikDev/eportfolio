<?php
return array (
  '%displayName% left the space %spaceName%' => '%displayName% 退出了 %spaceName% 空間',
  '%displayName% left this space.' => '%displayName% 已退出此空間',
);
