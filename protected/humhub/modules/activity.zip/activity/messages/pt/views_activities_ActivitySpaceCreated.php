<?php
return array (
  '%displayName% created the new space %spaceName%' => '%displayName% criou um novo espaço %spaceName%',
  '%displayName% created this space.' => '%displayName% criou este espaço.',
);
