<?php
return array (
  '%displayName% left the space %spaceName%' => '%displayName% saiu do espaço %spaceName%',
  '%displayName% left this space.' => '%displayName% saiu deste espaço.',
);
