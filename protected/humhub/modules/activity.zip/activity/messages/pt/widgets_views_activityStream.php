<?php
return array (
  '<strong>Latest</strong> activities' => '<strong>Últimas</strong> atividades',
  'There are no activities yet.' => 'Ainda não existem actividades.',
);
