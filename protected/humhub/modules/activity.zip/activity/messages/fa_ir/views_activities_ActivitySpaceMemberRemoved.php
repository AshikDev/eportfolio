<?php
return array (
  '%displayName% left the space %spaceName%' => '%displayName% انجمن%spaceName% را ترک کرد.',
  '%displayName% left this space.' => '%displayName% این انجمن را ترک کرد.',
);
