<?php
return array (
  '<strong>Latest</strong> activities' => '<strong> آخرین </strong> فعالیت‌ها',
  'There are no activities yet.' => 'هنوز فعالیتی وجود ندارد.',
);
