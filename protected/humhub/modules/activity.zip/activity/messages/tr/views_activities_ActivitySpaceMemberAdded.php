<?php
return array (
  '%displayName% joined the space %spaceName%' => '%displayName% - %spaceName% mekana katıldı',
  '%displayName% joined this space.' => '%displayName% mekana katıldı.',
  '%spaceName% has been archived' => '%spaceName% arşivlendi',
  '%spaceName% has been unarchived' => '%spaceName% arşivden kaldırıldı',
);
