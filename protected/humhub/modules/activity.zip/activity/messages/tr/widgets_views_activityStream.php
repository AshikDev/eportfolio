<?php
return array (
  '<strong>Latest</strong> activities' => '<strong>Son</strong> aktiviteler',
  'There are no activities yet.' => 'Henüz bir aktivite yok.',
);
