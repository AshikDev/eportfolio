<?php
return array (
  '%displayName% created the new space %spaceName%' => '%displayName% yeni bir alan oluşturdu %spaceName%',
  '%displayName% created this space.' => '%displayName% bu alanı oluşturdu.',
);
