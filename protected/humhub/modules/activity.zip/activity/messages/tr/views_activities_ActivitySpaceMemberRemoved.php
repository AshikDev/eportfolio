<?php
return array (
  '%displayName% left the space %spaceName%' => '%displayName% - %spaceName% mekanından ayrıldı',
  '%displayName% left this space.' => '%displayName% mekandan ayrıldı.',
);
