<?php
return array (
  'See online:' => 'Çevrimiçi olaraklar:',
  'see online' => 'kimle çevrimiçi',
  'via' => 'ile',
);
