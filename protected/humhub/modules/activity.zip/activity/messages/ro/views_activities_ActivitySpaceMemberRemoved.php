<?php
return array (
  '%displayName% left the space %spaceName%' => '%displayName% a părăsit spațiul %spaceName%',
  '%displayName% left this space.' => '%displayName% a părăsit acest spațiu.',
);
