<?php
return array (
  '<strong>Latest</strong> activities' => '<strong>Ultimele</strong> activități',
  'There are no activities yet.' => 'Nu sunt activități încă.',
);
