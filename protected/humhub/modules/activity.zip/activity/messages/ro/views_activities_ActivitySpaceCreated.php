<?php
return array (
  '%displayName% created the new space %spaceName%' => '%displayName% a creat noul spațiu %spaceName%',
  '%displayName% created this space.' => '%displayName% a creat acest spațiu.',
);
