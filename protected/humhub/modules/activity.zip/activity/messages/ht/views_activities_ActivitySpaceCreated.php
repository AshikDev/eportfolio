<?php
return array (
  '%displayName% created the new space %spaceName%' => '%displayName% kreye yon nouvo espas nan %spaceName%',
  '%displayName% created this space.' => '%displayName% kreye espas sa.',
);
