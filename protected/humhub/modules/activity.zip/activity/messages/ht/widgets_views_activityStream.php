<?php
return array (
  '<strong>Latest</strong> activities' => '<strong>Dènye</strong> aktivite',
  'There are no activities yet.' => 'Pa gen oken\'n aktivite ankò.',
);
