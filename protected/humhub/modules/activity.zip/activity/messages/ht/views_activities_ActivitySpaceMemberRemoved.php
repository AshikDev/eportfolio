<?php
return array (
  '%displayName% left the space %spaceName%' => '%displayName% kite espas %spaceName%',
  '%displayName% left this space.' => '%displayName% kite espas sa.',
);
