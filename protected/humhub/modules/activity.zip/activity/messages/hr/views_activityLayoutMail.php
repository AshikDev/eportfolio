<?php
return array (
  'See online:' => 'Tko je online:',
  'see online' => 'vidjeti online',
  'via' => 'preko',
);
