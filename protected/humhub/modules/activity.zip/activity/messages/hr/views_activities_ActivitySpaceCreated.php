<?php
return array (
  '%displayName% created the new space %spaceName%' => '%displayName% kreirao je novi prostor %spaceName%',
  '%displayName% created this space.' => '%displayName% kreirao je ovaj prostor.',
);
