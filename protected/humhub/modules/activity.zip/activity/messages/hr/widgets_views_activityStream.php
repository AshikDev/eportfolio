<?php
return array (
  '<strong>Latest</strong> activities' => '<strong>Posljednje</strong> aktivnosti',
  'There are no activities yet.' => 'Još nema aktivnosti.',
);
