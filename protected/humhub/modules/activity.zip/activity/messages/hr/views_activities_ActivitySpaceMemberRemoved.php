<?php
return array (
  '%displayName% left the space %spaceName%' => '%displayName% napustio je prostor %spaceName%',
  '%displayName% left this space.' => '%displayName% napustio je ovaj prostor.',
);
