<?php
return array (
  '<strong>Latest</strong> activities' => 'Aktivitas terakhir',
  'There are no activities yet.' => 'belum ada aktivitas',
);
