<?php
return array (
  '%displayName% created the new space %spaceName%' => 'membuat ruang baru',
  '%displayName% created this space.' => 'buat ruang ini',
);
