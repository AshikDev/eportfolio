<?php
return array (
  'See online:' => 'Lihat online',
  'see online' => 'lihat online',
  'via' => 'melalui',
);
