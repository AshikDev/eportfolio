<?php
return array (
  '%displayName% left the space %spaceName%' => 'keluar dari ruang ',
  '%displayName% left this space.' => 'telah keluar dari ruang ini',
);
