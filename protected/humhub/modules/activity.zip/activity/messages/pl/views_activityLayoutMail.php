<?php
return array (
  'See online:' => 'Zobacz online:',
  'see online' => 'zobacz zalogowanych',
  'via' => 'przez',
);
