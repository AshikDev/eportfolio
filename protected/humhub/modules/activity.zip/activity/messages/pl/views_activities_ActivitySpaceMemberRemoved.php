<?php
return array (
  '%displayName% left the space %spaceName%' => '%displayName% opuścił strefę %spaceName%',
  '%displayName% left this space.' => '%displayName% opuścił tę strefę. ',
);
