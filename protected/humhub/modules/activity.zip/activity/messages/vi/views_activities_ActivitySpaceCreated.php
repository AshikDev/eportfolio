<?php
return array (
  '%displayName% created the new space %spaceName%' => '%displayName% vừa tạo phòng làm việc %spaceName%',
  '%displayName% created this space.' => '%displayName% đã tạo phòng làm việc này.',
);
