<?php
return array (
  '<strong>Latest</strong> activities' => 'Các hoạt động <strong>mới nhất</strong>',
  'There are no activities yet.' => 'Chưa có hoạt động nào.',
);
