<?php
return array (
  '%displayName% left the space %spaceName%' => '%displayName% đã rời khỏi phòng làm việc %spaceName%',
  '%displayName% left this space.' => '%displayName% đã rời phòng làm việc này.',
);
