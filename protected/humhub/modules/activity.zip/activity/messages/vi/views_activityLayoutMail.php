<?php
return array (
  'See online:' => 'Xem trực tuyến: ',
  'see online' => 'Xem trực tuyến',
  'via' => 'qua',
);
