<?php
return array (
  '%displayName% left the space %spaceName%' => '%displayName% 님이 %spaceName% 스페이스를 떠나셨습니다.',
  '%displayName% left this space.' => '%displayName% 님이 이 스페이스를 떠나셨습니다.',
);
