<?php
return array (
  '<strong>Latest</strong> activities' => '<strong>최근</strong> 활동들',
  'There are no activities yet.' => '아직 활동이 없습니다.',
);
