<?php
return array (
  '{user1} now follows {user2}.' => '{user1} 님은 이제 {user2} 님을 팔로우합니다.',
);
