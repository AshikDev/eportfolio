<?php
return array (
  '%displayName% created the new space %spaceName%' => '%displayName% 님이 새 스페이스를 만들었습니다 :  %spaceName%.',
  '%displayName% created this space.' => '%displayName% 님이 이 스페이스를 만들었습니다.',
);
