<?php
return array (
  '<strong>Latest</strong> activities' => '<strong>Activitat</strong> recent',
  'There are no activities yet.' => 'Encara no hi ha activitat',
);
