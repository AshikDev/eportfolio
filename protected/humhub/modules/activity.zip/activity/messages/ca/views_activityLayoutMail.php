<?php
return array (
  'See online:' => 'Veure en línia',
  'see online' => 'veure en línia',
  'via' => 'via',
);
