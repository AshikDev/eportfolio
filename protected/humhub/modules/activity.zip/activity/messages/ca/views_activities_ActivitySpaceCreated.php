<?php
return array (
  '%displayName% created the new space %spaceName%' => '%displayName% ha creat el nou espai %spaceName%',
  '%displayName% created this space.' => '%displayName% ha creat aquest espai.',
);
