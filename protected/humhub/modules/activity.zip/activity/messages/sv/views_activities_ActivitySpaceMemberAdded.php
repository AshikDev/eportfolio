<?php
return array (
  '%displayName% joined the space %spaceName%' => '%displayName% gick med i nätverket %spaceName%',
  '%displayName% joined this space.' => '%displayName% gick med i detta nätverk.',
  '%spaceName% has been archived' => '%spaceName% har blivit arkiverad',
  '%spaceName% has been unarchived' => '%spaceName% har blivit återaktiverad',
);
