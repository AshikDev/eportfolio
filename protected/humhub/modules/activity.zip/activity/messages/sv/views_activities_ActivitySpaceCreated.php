<?php
return array (
  '%displayName% created the new space %spaceName%' => '%displayName% skapade ett nytt nätverk %spaceName%',
  '%displayName% created this space.' => '%displayName% skapade detta nätverk.',
);
