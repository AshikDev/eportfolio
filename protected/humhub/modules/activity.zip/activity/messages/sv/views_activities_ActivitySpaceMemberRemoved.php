<?php
return array (
  '%displayName% left the space %spaceName%' => '%displayName% lämnade nätverket %spaceName%',
  '%displayName% left this space.' => '%displayName% lämnade detta nätverk.',
);
