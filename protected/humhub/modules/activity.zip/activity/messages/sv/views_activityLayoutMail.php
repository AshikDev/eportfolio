<?php
return array (
  'See online:' => 'Visa online:',
  'see online' => 'via',
  'via' => 'via',
);
