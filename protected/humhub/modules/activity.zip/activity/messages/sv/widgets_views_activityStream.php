<?php
return array (
  '<strong>Latest</strong> activities' => '<strong>Senaste</strong> aktiviteter',
  'There are no activities yet.' => 'Det finns inga aktiviteter ännu.',
);
