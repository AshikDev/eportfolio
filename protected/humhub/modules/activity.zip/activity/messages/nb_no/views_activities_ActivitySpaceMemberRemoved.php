<?php
return array (
  '%displayName% left the space %spaceName%' => '%displayName% forlot gruppen %spaceName%',
  '%displayName% left this space.' => '%displayName% forlot denne gruppen.',
);
