<?php
return array (
  '<strong>Latest</strong> activities' => '<strong>Siste</strong> hendelser',
  'There are no activities yet.' => 'Det er ingen aktivitet her enda.',
);
