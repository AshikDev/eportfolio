<?php
return array (
  '%displayName% created the new space %spaceName%' => '%displayName% opprettet gruppen %spaceName%',
  '%displayName% created this space.' => '%displayName% opprettet denne gruppen.',
);
