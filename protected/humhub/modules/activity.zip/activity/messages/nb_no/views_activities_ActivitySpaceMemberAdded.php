<?php
return array (
  '%displayName% joined the space %spaceName%' => '%displayName% ble medlem av %spaceName%',
  '%displayName% joined this space.' => '%displayName% ble medlem av denne gruppen.',
  '%spaceName% has been archived' => '%spaceName% er arkivert',
  '%spaceName% has been unarchived' => '%spaceName% er tatt ut fra arkivet',
);
