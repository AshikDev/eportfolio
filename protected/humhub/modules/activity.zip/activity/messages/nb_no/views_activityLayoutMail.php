<?php
return array (
  'See online:' => 'Se online:',
  'see online' => 'se online',
  'via' => 'gjennom',
);
