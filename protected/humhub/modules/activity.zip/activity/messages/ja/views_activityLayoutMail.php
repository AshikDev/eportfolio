<?php
return array (
  'See online:' => 'オンライン：',
  'see online' => 'オンラインで見る',
  'via' => '経由',
);
