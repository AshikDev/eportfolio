<?php
return array (
  '%displayName% joined the space %spaceName%' => '%displayName%さんは、%spaceName% スペースに参加しました',
  '%displayName% joined this space.' => '%displayName%さんが、このスペースに参加しました。',
  '%spaceName% has been archived' => '%spaceName%はアーカイブされました',
  '%spaceName% has been unarchived' => '%spaceName%は復元されました',
);
