<?php
return array (
  '<strong>Latest</strong> activities' => '<strong>みんなの反応</strong>',
  'There are no activities yet.' => 'まだ何の反応もありません。',
);
