<?php
return array (
  '%displayName% created the new space %spaceName%' => '%displayName% создал новое пространство %spaceName%',
  '%displayName% created this space.' => '%displayName% создал это пространство.',
);
