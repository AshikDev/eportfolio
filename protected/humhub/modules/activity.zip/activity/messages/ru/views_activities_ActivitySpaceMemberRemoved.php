<?php
return array (
  '%displayName% left the space %spaceName%' => '%displayName% покинул пространство %spaceName%',
  '%displayName% left this space.' => '%displayName% покинул это пространство.',
);
