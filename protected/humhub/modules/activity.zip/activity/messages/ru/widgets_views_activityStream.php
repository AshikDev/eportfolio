<?php
return array (
  '<strong>Latest</strong> activities' => '<strong>Лента</strong> активности',
  'There are no activities yet.' => 'Пока ничего нет.',
);
