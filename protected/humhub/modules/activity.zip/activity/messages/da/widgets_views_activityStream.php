<?php
return array (
  '<strong>Latest</strong> activities' => '<strong>Seneste</strong> aktiviteter',
  'There are no activities yet.' => 'Der er ingen aktiviteter endnu.',
);
