<?php
return array (
  '%displayName% created the new space %spaceName%' => '%displayName% har oprettet den nye side %spaceName%',
  '%displayName% created this space.' => '%displayName% oprettede denne side.',
);
