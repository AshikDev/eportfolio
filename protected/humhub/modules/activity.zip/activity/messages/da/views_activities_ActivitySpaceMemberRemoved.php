<?php
return array (
  '%displayName% left the space %spaceName%' => '%displayName% har forladt siden %spaceName%',
  '%displayName% left this space.' => '%displayName% har forladt denne side.',
);
