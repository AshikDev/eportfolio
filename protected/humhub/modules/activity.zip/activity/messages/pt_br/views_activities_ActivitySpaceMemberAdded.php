<?php
return array (
  '%displayName% joined the space %spaceName%' => '%displayName% entrou no espaço %spaceName%',
  '%displayName% joined this space.' => '%displayName% entrou neste espaço.',
  '%spaceName% has been archived' => '%spaceName% foi arquivado',
  '%spaceName% has been unarchived' => '%spaceName% foi desarquivado',
);
