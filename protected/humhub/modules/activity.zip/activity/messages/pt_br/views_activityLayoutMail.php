<?php
return array (
  'See online:' => 'Ver online:',
  'see online' => 'ver online',
  'via' => 'via',
);
