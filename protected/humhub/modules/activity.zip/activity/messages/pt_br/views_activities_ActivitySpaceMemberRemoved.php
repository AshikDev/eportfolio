<?php
return array (
  '%displayName% left the space %spaceName%' => '%displayName% deixou o espaço %spaceName%',
  '%displayName% left this space.' => '%displayName% deixou este espaço.',
);
