<?php
return array (
  'See online:' => 'Bekijk online',
  'see online' => 'Bekijk online',
  'via' => 'via',
);
