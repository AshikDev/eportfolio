<?php
return array (
  '%displayName% joined the space %spaceName%' => '%displayName% is lid geworden van ruimte %spaceName%.',
  '%displayName% joined this space.' => '%displayName% is van deze ruimte lid geworden.',
  '%spaceName% has been archived' => '%spaceName% is gearchiveerd.',
  '%spaceName% has been unarchived' => '%spaceName% is uit het archief gehaald.',
);
