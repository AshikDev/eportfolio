<?php
return array (
  '<strong>Latest</strong> activities' => '<strong>Laatste</strong> activiteiten',
  'There are no activities yet.' => 'Er zijn nog geen activiteiten.',
);
