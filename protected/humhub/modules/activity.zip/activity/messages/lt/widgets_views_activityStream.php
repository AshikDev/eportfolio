<?php
return array (
  '<strong>Latest</strong> activities' => '<strong>Naujausi</strong> pasikeitimai',
  'There are no activities yet.' => 'Kol kas nėra jokių pasikeitimų',
);
