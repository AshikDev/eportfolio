<?php
return array (
  '%displayName% left the space %spaceName%' => '%displayName% paliko paskyrą %spaceName%',
  '%displayName% left this space.' => '%displayName% paliko šią paskyrą.',
);
