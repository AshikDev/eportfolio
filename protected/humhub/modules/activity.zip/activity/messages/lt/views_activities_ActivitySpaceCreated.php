<?php
return array (
  '%displayName% created the new space %spaceName%' => '%displayName% sukūrė naują paskyrą %spaceName%',
  '%displayName% created this space.' => '%displayName% sukūrė šią paskyrą',
);
