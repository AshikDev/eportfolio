<?php
return array (
  'See online:' => 'Otevřít v prohlížeči',
  'see online' => 'Otevřít v prohlížeči',
  'via' => 'prostřednictvím',
);
