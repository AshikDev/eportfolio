<?php
return array (
  '%displayName% created the new space %spaceName%' => '%displayName% vytvořil(a) nový prostor "%spaceName%',
  '%displayName% created this space.' => 'Tento prostor vytvořil(a) %displayName%.',
);
