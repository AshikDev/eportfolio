<?php
return array (
  '%displayName% left the space %spaceName%' => '%displayName% opustil(a) prostor %spaceName%',
  '%displayName% left this space.' => '%displayName% opustil(a) tento prostor.',
);
