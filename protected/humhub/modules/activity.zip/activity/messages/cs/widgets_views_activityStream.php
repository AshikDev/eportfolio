<?php
return array (
  '<strong>Latest</strong> activities' => '<strong>Poslední</strong> aktivita',
  'There are no activities yet.' => 'Zatím zde není žádná aktivita.',
);
