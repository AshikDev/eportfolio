<?php
return array (
  '{user1} now follows {user2}.' => '{user1} nyní sleduje uživatele {user2}.',
);
