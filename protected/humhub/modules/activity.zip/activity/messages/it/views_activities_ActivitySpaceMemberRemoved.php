<?php
return array (
  '%displayName% left the space %spaceName%' => '%displayName% ha lasciato lo spazio %spaceName%',
  '%displayName% left this space.' => '%displayName% ha lasciato questo spazio.',
);
