<?php
return array (
  'See online:' => 'Vedi online:',
  'see online' => 'vedi online',
  'via' => 'via',
);
