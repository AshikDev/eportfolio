<?php
return array (
  '<strong>Latest</strong> activities' => '<strong>Ultime</strong> attività',
  'There are no activities yet.' => 'Non ci sono ancora attività.',
);
