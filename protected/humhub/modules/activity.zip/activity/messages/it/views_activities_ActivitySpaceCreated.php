<?php
return array (
  '%displayName% created the new space %spaceName%' => '%displayName% ha creato il nuovo spazio %spaceName%',
  '%displayName% created this space.' => '%displayName% ha creato questo spazio.',
);
