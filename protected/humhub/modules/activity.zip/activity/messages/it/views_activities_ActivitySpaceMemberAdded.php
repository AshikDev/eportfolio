<?php
return array (
  '%displayName% joined the space %spaceName%' => '%displayName% si è aggiunto allo spazio %spaceName%',
  '%displayName% joined this space.' => '%displayName% si è aggiunto a questo spazio.',
  '%spaceName% has been archived' => '%spaceName% è stato archiviato.',
  '%spaceName% has been unarchived' => '%spaceName% non è più archiviato. ',
);
