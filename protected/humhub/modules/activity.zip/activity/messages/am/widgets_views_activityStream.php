<?php
return array (
  '<strong>Latest</strong> activities' => '<strong>የቅርብ</strong> ተግባራት',
  'There are no activities yet.' => 'እስካሁን የተደረጉ ምንም አይነት ተግባራት የሉም።',
);
