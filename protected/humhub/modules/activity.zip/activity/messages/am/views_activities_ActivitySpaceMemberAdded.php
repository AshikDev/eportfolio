<?php
return array (
  '%displayName% joined the space %spaceName%' => '%displayName% %spaceName%ን ተቀላቅለዋል።',
  '%displayName% joined this space.' => '%displayName% ይህን ምህዳር ተቀላቅለዋል።',
  '%spaceName% has been archived' => '%spaceName% በማህደር ላይ ሰፍሯል።',
  '%spaceName% has been unarchived' => '%spaceName% ከምህዳሩ ላይ ተነስቷል።',
);
