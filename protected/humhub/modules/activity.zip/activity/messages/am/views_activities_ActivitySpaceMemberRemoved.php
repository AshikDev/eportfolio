<?php
return array (
  '%displayName% left the space %spaceName%' => '%displayName% %spaceName%ን ምህዳሩን ለቀው ወጥተዋል።',
  '%displayName% left this space.' => '%displayName% ይህን ምህዳር ለቀው ወጥተዋል።',
);
