<?php
return array (
  'See online:' => 'በመስመር ላይ ሆነው ይመልከቱ፡',
  'see online' => 'በመስመር ላይ ሆነው ይመልከቱ',
  'via' => 'በኩል',
);
