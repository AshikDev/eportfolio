<?php
return array (
  '{user1} now follows {user2}.' => '{user1} {user2}ን አሁን እየተከተሉ ይገኛሉ።',
);
