<?php
return array (
  '%displayName% created the new space %spaceName%' => '%displayName% %spaceName% የተሰኘ አዲስ ምህዳር ፈጥረዋል',
  '%displayName% created this space.' => '%displayName% ይህን ምህዳር ፈጥረዋል።',
);
