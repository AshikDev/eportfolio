<?php
return array (
  '<strong>Latest</strong> activities' => '<strong>أحدث</strong> النشاطات',
  'There are no activities yet.' => 'لا توجد نشاطات بعد',
);
