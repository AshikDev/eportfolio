<?php
return array (
  '%displayName% created the new space %spaceName%' => '%displayName% قام بافتتاح باحة جديدة %spaceName%',
  '%displayName% created this space.' => '%displayName% قام بافتتاح هذه الباحة',
);
