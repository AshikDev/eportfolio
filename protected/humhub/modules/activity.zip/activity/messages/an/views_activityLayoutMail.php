<?php
return array (
  'See online:' => 'Veyer en linia:',
  'see online' => 'veyer en linia.',
  'via' => 'vía',
);
