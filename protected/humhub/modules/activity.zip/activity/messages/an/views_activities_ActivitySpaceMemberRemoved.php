<?php
return array (
  '%displayName% left the space %spaceName%' => '%displayName% deixó l\'espacio %spaceName%',
  '%displayName% left this space.' => '%displayName% deixó iste espacio.',
);
