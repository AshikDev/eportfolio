<?php
return array (
  '<strong>Latest</strong> activities' => '<strong>Πρόσφατες</strong> δραστηριότητες',
  'There are no activities yet.' => 'Δεν υπάρχουν ακόμα δραστηριότητες.',
);
