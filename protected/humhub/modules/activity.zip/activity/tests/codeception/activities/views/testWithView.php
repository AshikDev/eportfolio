<?php
/* @var $this \humhub\components\View */
?>

<h2>My special activity view content</h2>
