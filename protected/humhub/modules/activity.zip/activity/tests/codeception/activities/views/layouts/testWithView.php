<?php
/* @var $this \humhub\components\View */
?>

<div>
    <h1>My special activity view layout</h1>
    <?= $content; ?>
</div>