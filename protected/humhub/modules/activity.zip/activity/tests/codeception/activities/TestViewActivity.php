<?php

namespace humhub\modules\activity\tests\codeception\activities;

/**
 * Description of TestActivity
 *
 * @author buddha
 */
class TestViewActivity extends \humhub\modules\activity\components\BaseActivity {

    public $moduleId = 'test';

    public $viewName = 'testWithView';
}
