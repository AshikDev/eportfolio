<?php

namespace humhub\modules\activity\tests\codeception\unit\activities;

/**
 * Description of TestActivity
 *
 * @author buddha
 */
class TestActivity extends \humhub\modules\activity\components\BaseActivity {
    public $moduleId = 'test';
}
