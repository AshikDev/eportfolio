<?php

/**
 * @link https://www.humhub.org/
 * @copyright Copyright (c) 2017 HumHub GmbH & Co. KG
 * @license https://www.humhub.com/licences
 */
?>
<?php $this->beginContent('@activity/views/layouts/web.php', $_params_); ?>
    <?= html ?>
<?php $this->endContent(); ?>