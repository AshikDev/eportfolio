## Installation

You can install the module in any one of the below two ways:
 1. Easy installation
    - Install from marketplace then enable the module
 2. Manual installation
    - Download the release from https://github.com/evnix/freichat-integrations/releases
    - Extract the zip file and copy freichat folder to protected/modules/ directory
    - Go to Humhub Admin -> Modules -> Install -> Enable 

## Uninstallation

1. Click uninstall in Humhub Admin.

If it gives error during uninstall, give 0777 permissions to freichat folder and then try again.