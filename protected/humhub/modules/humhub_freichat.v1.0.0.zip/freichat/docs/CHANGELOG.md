Changelog
=========

1.0.0 - Aug 7, 2019
------------------------
 - Add integration to load current user
 - Generate saas token and register with saas server automatically
