<?php
    return [
        'Token used to communicate with FreiChat server. Please do not edit this.' => 'Token used to communicate with FreiChat server. Please do not edit this.',
        'FreiChat Token:' => 'FreiChat Token:',
        'FreiChat configuration' => 'FreiChat configuration',
        'Save' => 'Save',
        'Back to modules' => 'Back to modules'
    ];
