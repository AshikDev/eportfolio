<?php

return [
    'fixtures' => ['default']
];
