<?php

return \tests\codeception\_support\HumHubTestConfiguration::getSuiteConfig('functional');
