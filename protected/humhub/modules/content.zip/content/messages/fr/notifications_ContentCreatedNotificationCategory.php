<?php
return array (
  'New Content' => 'Contenus',
  'Receive Notifications for new content you follow.' => 'Recevoir une notification pour les nouveaux contenus suivis.',
);
