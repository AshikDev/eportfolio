<?php
return array (
  'Turn off notifications' => 'Désactiver les notifications',
  'Turn on notifications' => 'Activer les notifications',
);
