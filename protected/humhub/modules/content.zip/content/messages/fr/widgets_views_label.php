<?php
return array (
  'Archived' => 'Archivé',
  'Public' => 'Public',
  'Pinned' => 'Mis en avant',
);
