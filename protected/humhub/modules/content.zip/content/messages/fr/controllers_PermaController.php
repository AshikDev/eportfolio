<?php
return array (
  'Could not find requested content!' => 'Impossible de trouver le contenu demandé.',
);
