<?php
return array (
  'Pin to top' => 'Épingler en haut de page',
  'Unpin' => 'Détacher',
);
