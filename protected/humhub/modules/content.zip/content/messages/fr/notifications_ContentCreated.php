<?php
return array (
  '{originator} just wrote {contentInfo}' => '{originator} vient d\'écrire {contentInfo}',
  '{originator} just wrote {contentInfo} in space {space}' => '{originator} vient d\'écrire {contentInfo} dans l\'espace {space}',
  '{originator} notifies you about {contentInfo}' => '{originator} vous informe sur {contentInfo}',
  '{originator} notifies you about {contentInfo} in {space}' => '{originator} vous informe sur {contentInfo} dans l\'espace {space}',
);
