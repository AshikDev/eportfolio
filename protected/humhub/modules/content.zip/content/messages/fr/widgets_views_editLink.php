<?php
return array (
  'Cancel Edit' => 'Annuler la modification',
  'Edit' => 'Modifier',
);
