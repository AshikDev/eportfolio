<?php
return array (
  'Contents' => 'Publications',
  'Whenever a new content (e.g. post) has been created.' => 'Chaque fois qu\'un nouveau contenu a été publié.',
);
