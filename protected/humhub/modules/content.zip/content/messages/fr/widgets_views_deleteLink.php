<?php
return array (
  '<strong>Confirm</strong> post deletion' => '<strong>Confirmer</strong> la suppression de la publication',
  'Cancel' => 'Annuler',
  'Delete' => 'Supprimer',
  'Do you really want to delete this post? All likes and comments will be lost!' => 'Souhaitez-vous vraiment supprimer cette publication ? Tous les "j\'aime" et les commentaires seront définitivement perdus !',
);
