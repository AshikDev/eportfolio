<?php
return array (
  'None' => 'Aucun',
);
