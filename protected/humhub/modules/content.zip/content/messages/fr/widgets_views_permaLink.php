<?php
return array (
  '<strong>Permalink</strong> to this post' => '<strong>Raccourci</strong> vers cette publication',
  'Permalink' => 'Raccourci',
);
