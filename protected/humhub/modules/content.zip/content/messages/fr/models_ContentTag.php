<?php
return array (
  'Tag' => 'Mot-clé',
  'The given name is already in use.' => 'Ce nom est déjà utilisé.',
);
