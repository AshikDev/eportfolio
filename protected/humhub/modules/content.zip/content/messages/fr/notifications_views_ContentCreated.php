<?php
return array (
  '{displayName} created {contentTitle}.' => '{displayName} a créé {contentTitle}.',
  '{displayName} posted on your profile {contentTitle}.' => '{displayName} a publié sur votre profil {contentTitle}.',
);
