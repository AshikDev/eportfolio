<?php
return array (
  'Could not delete content!' => 'Impossible de supprimer le contenu.',
  'Could not delete content: Access denied!' => 'Impossible de supprimer le contenu : Accès refusé.',
  'Could not load requested object!' => 'Impossible de charger l\'objet demandé.',
  'Invalid request method!' => 'Méthode de demande non valide.',
  'Maximum number of pinned items reached!

You can pin to top only two items at once.
To however pin this item, unpin another before!' => 'Nombre maximum d\'articles épinglés atteints. Vous pouvez épingler seulement deux articles à la fois.',
  'This action is disabled!' => 'Cette action est désactivée.',
);
