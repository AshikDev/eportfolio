<?php
return array (
  'Pinned' => 'Épinglé',
  'Unpinned' => 'Détaché',
);
