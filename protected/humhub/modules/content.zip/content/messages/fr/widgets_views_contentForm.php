<?php
return array (
  'Add a member to notify' => 'Ajouter les utilisateurs à avertir',
  'Content visibility' => 'Visibilité du contenu',
  'Make private' => 'Rendre privé',
  'Make public' => 'Rendre public',
  'Notify members' => 'Avertir des utilisateurs',
  'Public' => 'Public',
  'This space is archived.' => 'Cet espace est archivé',
);
