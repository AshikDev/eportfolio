<?php
return array (
  'View Online' => 'Voir en ligne',
);
