<?php
return array (
  'Submit' => 'Publier',
);
