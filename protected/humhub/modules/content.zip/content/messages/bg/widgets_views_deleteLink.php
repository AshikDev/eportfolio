<?php
return array (
  '<strong>Confirm</strong> post deletion' => '',
  'Cancel' => 'Отказ',
  'Delete' => 'Изтрий',
  'Do you really want to delete this post? All likes and comments will be lost!' => '',
);
