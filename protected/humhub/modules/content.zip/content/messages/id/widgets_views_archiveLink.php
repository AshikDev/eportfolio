<?php
return array (
  'Move to archive' => 'Pindahkan ke arsip',
  'Unarchive' => 'arsipkan',
);
