<?php
return array (
  'Archived' => '',
  'Pinned' => '',
  'Public' => 'Publik',
);
