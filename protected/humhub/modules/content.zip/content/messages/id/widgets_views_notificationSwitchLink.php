<?php
return array (
  'Turn off notifications' => '',
  'Turn on notifications' => '',
);
