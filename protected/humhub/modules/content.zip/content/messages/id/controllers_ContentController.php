<?php
return array (
  'Could not delete content!' => 'Tidak dapat menghapus konten!',
  'Could not delete content: Access denied!' => 'Tidak dapat menghapus konten!Akses ditolak!',
  'Could not load requested object!' => 'Tidak dapat menjalankan permintaan!',
  'Invalid request method!' => 'Kesalahan metode permintaan!',
  'Maximum number of pinned items reached!

You can pin to top only two items at once.
To however pin this item, unpin another before!' => '',
  'This action is disabled!' => 'Untuk aksi ini dinonaktifkan',
);
