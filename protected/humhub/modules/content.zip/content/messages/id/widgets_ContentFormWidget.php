<?php
return array (
  'Submit' => 'Kirim',
);
