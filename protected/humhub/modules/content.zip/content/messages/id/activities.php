<?php
return array (
  'Contents' => 'Konten',
  'Whenever a new content (e.g. post) has been created.' => '
kapanpun konten baru(e.g. post) sudah dibuat.
',
);
