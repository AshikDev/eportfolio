<?php
return array (
  '<strong>Confirm</strong> post deletion' => '',
  'Cancel' => 'Batal',
  'Delete' => 'Hapus',
  'Do you really want to delete this post? All likes and comments will be lost!' => '',
);
