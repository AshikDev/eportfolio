<?php
return array (
  'Cancel Edit' => 'Batal Ubah',
  'Edit' => 'Ubah',
);
