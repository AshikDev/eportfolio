<?php
return array (
  'Pinned' => '',
  'Unpinned' => '',
);
