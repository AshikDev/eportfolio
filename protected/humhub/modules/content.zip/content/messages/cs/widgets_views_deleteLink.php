<?php
return array (
  '<strong>Confirm</strong> post deletion' => '<strong>Potvrzení</strong> smazání příspěvku',
  'Cancel' => 'Zrušit',
  'Delete' => 'Smazat',
  'Do you really want to delete this post? All likes and comments will be lost!' => 'Opravdu chcete smazat tento příspěvek? Všechny komentáře a označení Libí se mi budou smazány.',
);
