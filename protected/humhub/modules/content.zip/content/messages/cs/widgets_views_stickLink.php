<?php
return array (
  'Pinned' => 'Připnout',
  'Unpinned' => 'Odepnout',
);
