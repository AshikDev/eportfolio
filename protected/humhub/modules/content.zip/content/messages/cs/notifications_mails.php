<?php
return array (
  'View Online' => 'Zobrazit online',
);
