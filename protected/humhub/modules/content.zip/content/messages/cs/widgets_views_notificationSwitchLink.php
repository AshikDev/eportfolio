<?php
return array (
  'Turn off notifications' => 'Vypnout upozornění',
  'Turn on notifications' => 'Zapnout upozornění',
);
