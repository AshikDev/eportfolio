<?php
return array (
  'Contents' => 'Obsah',
  'Whenever a new content (e.g. post) has been created.' => 'Kdykoli byl vytvořen nový obsah (například příspěvek).',
);
