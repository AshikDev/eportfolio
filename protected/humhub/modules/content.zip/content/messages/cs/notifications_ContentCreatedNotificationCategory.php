<?php
return array (
  'New Content' => 'Nový obsah',
  'Receive Notifications for new content you follow.' => 'Obdržíte oznámení o novém obsahu, který sledujete.',
);
