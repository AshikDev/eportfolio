<?php
return array (
  'Pin to top' => 'Připnout na úvod',
  'Unpin' => 'Odepnout',
);
