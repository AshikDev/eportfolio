<?php
return array (
  'Move to archive' => 'Archivovat',
  'Unarchive' => 'Obnovit z archívu',
);
