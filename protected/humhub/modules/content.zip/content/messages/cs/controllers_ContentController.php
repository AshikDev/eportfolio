<?php
return array (
  'Could not delete content!' => 'Nelze smazat obsah!',
  'Could not delete content: Access denied!' => 'Nelze odstranit obsah: Přístup byl odepřen!',
  'Could not load requested object!' => 'Nelze načíst požadovaný objekt!',
  'Invalid request method!' => 'Neplatná metoda požadavku!',
  'Maximum number of pinned items reached!

You can pin to top only two items at once.
To however pin this item, unpin another before!' => 'Maximální počet připnutých položek! Do horní části můžete zařadit  pouze dvě položky najednou. Chcete-li tuto položku připnout, ještě předtím odepněte jinou!
',
  'This action is disabled!' => 'Tato akce je zakázána!',
);
