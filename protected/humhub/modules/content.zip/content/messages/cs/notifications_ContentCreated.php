<?php
return array (
  '{originator} just wrote {contentInfo}' => '{originator} právě napsal/a {contentInfo}',
  '{originator} just wrote {contentInfo} in space {space}' => '{originator} právě napsal/a {contentInfo} v prostoru {space}',
  '{originator} notifies you about {contentInfo}' => '{originator} Vás označil/a {contentInfo}',
  '{originator} notifies you about {contentInfo} in {space}' => '{originator} Vás označil/a {contentInfo} v {space}',
);
