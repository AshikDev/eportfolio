<?php
return array (
  'Submit' => 'Odeslat',
);
