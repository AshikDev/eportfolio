<?php
return array (
  'Cancel Edit' => 'Zrušit úpravy',
  'Edit' => 'Upravit',
);
