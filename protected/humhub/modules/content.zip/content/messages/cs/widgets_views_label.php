<?php
return array (
  'Archived' => 'Archivováno',
  'Public' => 'Veřejné',
  'Pinned' => 'Připnuto',
);
