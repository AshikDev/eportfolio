<?php
return array (
  '{displayName} created {contentTitle}.' => '{displayName} ha creado {contentTitle}.',
  '{displayName} posted on your profile {contentTitle}.' => '{displayName} ha publicado en su perfil {contentTitle}.',
);
