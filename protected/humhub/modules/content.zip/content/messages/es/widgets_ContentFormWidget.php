<?php
return array (
  'Submit' => 'Publicar',
);
