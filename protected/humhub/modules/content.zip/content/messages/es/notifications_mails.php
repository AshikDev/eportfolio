<?php
return array (
  'View Online' => 'Ver en línea',
);
