<?php
return array (
  'Archived' => 'Archivado',
  'Public' => 'Público',
  'Pinned' => 'Fijado',
);
