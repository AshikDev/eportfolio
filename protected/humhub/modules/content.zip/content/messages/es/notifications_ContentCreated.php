<?php
return array (
  '{originator} just wrote {contentInfo}' => '{originator} acaba de escribir {contentInfo}',
  '{originator} just wrote {contentInfo} in space {space}' => '{originator} acaba de escribir {contentInfo} en {space}',
  '{originator} notifies you about {contentInfo}' => '{originator} te notifica acerca de {contentInfo}',
  '{originator} notifies you about {contentInfo} in {space}' => '{originator} te notifica acerca de {contentInfo} en {space}',
);
