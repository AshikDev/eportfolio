<?php
return array (
  'New Content' => 'Nuevo Contenido',
  'Receive Notifications for new content you follow.' => 'Recibir Notificaciones de nuevo contenido que sigues.',
);
