<?php
return array (
  'Contents' => 'Contenidos',
  'Whenever a new content (e.g. post) has been created.' => 'Cuando sea que un nuevo contenido sea creado (ej: publicación).',
);
