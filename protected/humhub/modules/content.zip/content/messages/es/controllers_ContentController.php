<?php
return array (
  'Could not delete content!' => '¡No se pudo borrar el contenido!',
  'Could not delete content: Access denied!' => 'No se pudo borrar el contenido: ¡Acceso denegado!',
  'Could not load requested object!' => '¡No se pudo cargar el objeto solicitado!',
  'Invalid request method!' => '¡Método de solicitud no válido!',
  'Maximum number of pinned items reached!

You can pin to top only two items at once.
To however pin this item, unpin another before!' => 'Se ha alcanzado el máximo de ítems fijados. Puedes fijar dos ítems al mismo tiempo. Para fijar este ítem, debes desfijar algún otro primero.',
  'This action is disabled!' => '¡Esta acción no está permitida!',
);
