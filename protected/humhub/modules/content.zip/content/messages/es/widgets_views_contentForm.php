<?php
return array (
  'Add a member to notify' => 'Añadir un miembro a notificar',
  'Content visibility' => 'Visibilidad del contenido',
  'Make private' => 'Hacer Privado',
  'Make public' => 'Hacer Público',
  'Notify members' => 'Notificar Miembros',
  'Public' => 'Público',
  'This space is archived.' => 'Este espacio ha sido archivado.',
);
