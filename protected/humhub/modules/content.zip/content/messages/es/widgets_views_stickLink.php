<?php
return array (
  'Pinned' => 'Fijar',
  'Unpinned' => 'Desfijar',
);
