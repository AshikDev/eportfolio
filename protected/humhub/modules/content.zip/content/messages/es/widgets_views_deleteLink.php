<?php
return array (
  '<strong>Confirm</strong> post deletion' => '<strong>Confirma</strong> el borrado de la entrada',
  'Cancel' => 'Cancelar',
  'Delete' => 'Borrar',
  'Do you really want to delete this post? All likes and comments will be lost!' => '¿Realmente deseas borrar esta entrada? ¡Todos los "Me gusta" y los comentarios se perderán!',
);
