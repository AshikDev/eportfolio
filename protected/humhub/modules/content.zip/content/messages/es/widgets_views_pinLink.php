<?php
return array (
  'Pin to top' => 'Fijar en la parte superior',
  'Unpin' => 'Desfijar',
);
