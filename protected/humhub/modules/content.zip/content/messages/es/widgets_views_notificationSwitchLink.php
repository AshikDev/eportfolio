<?php
return array (
  'Turn off notifications' => 'Desactivar notificaciones',
  'Turn on notifications' => 'Activar Notificaciones',
);
