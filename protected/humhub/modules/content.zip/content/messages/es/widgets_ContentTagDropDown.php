<?php
return array (
  'None' => 'Ninguno',
);
