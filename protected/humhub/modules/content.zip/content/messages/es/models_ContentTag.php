<?php
return array (
  'Tag' => 'Etiqueta',
  'The given name is already in use.' => 'El nombre está ya en uso.',
);
