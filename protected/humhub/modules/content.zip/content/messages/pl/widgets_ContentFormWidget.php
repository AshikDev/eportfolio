<?php
return array (
  'Submit' => 'Opublikuj ',
);
