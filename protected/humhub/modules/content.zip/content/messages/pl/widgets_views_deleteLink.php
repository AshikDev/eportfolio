<?php
return array (
  '<strong>Confirm</strong> post deletion' => '<strong>Potwierdź</strong> usunięcie postu',
  'Cancel' => 'Anuluj',
  'Delete' => 'Usuń',
  'Do you really want to delete this post? All likes and comments will be lost!' => 'Czy naprawdę chcesz usunąć ten post? Wszystkie polubienia i komentarze zostaną utracone! ',
);
