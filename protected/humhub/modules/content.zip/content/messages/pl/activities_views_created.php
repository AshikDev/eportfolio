<?php
return array (
  '{displayName} created a new {contentTitle}.' => 'Nowy {contentTitle} został utworzony przez {displayName}.',
);
