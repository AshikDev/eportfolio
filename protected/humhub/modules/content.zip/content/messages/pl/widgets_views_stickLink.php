<?php
return array (
  'Pinned' => 'Przypnij',
  'Unpinned' => 'Odepnij ',
);
