<?php
return array (
  'Contents' => 'Zawartości',
  'Whenever a new content (e.g. post) has been created.' => 'Zawsze, gdy została utworzona nowa treść (np. Post).',
);
