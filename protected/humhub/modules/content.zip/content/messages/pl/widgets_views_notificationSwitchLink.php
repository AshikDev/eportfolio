<?php
return array (
  'Turn off notifications' => 'Wyłącz powiadomienia',
  'Turn on notifications' => 'Włącz powiadomienia ',
);
