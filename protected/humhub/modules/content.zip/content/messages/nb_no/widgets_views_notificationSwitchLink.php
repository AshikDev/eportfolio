<?php
return array (
  'Turn off notifications' => 'Skru av varsler',
  'Turn on notifications' => 'Skru på varsler',
);
