<?php
return array (
  'Cancel Edit' => 'Avbryt redigering',
  'Edit' => 'Rediger',
);
