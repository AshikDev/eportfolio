<?php
return array (
  'Archived' => 'Arkivert',
  'Public' => 'Offentlig',
  'Pinned' => 'Låst',
);
