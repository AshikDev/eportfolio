<?php
return array (
  'Add a member to notify' => 'Legg til en følger',
  'Content visibility' => 'Innholdssynlighet',
  'Make private' => 'Gjør privat',
  'Make public' => 'Gjør offentlig',
  'Notify members' => 'Varsle medlemmer',
  'Public' => 'Offentlig',
  'This space is archived.' => 'Denne gruppen er arkivert',
);
