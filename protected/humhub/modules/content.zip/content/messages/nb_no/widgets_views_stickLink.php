<?php
return array (
  'Pinned' => 'Lås',
  'Unpinned' => 'Lås opp',
);
