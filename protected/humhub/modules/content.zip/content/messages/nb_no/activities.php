<?php
return array (
  'Contents' => 'Innhold',
  'Whenever a new content (e.g. post) has been created.' => 'når noen publiserer innhold i en av dine grupper.',
);
