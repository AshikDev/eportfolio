<?php
return array (
  'Submit' => 'Send',
);
