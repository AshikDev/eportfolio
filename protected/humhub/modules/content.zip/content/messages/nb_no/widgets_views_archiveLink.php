<?php
return array (
  'Move to archive' => 'Flytt til arkiv',
  'Unarchive' => 'Ta ut fra arkiv',
);
