<?php
return array (
  '<strong>Confirm</strong> post deletion' => '<strong>Bekreft</strong> sletting av innlegg',
  'Cancel' => 'Avbryt',
  'Delete' => 'Slett',
  'Do you really want to delete this post? All likes and comments will be lost!' => 'Ønsker du virkelig og slette dette innlegget? Alle likes og kommentarer vil bli tapt!',
);
