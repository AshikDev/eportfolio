<?php
return array (
  'View Online' => 'Se online',
);
