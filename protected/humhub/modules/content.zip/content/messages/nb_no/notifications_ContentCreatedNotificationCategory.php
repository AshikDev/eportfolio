<?php
return array (
  'New Content' => 'Nytt innhold',
  'Receive Notifications for new content you follow.' => 'Få varsling om nytt innhold du følger.',
);
