<?php
return array (
  'Pin to top' => 'Pin til toppen',
  'Unpin' => 'Fjern pin',
);
