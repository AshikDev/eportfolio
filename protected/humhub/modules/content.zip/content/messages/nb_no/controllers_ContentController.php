<?php
return array (
  'Could not delete content!' => 'Kunne ikke slette innhold.',
  'Could not delete content: Access denied!' => 'Kan ikke slette innhold: ingen tilgang.',
  'Could not load requested object!' => 'Kunne ikke laste ønsket innhold.',
  'Invalid request method!' => 'Feil.',
  'Maximum number of pinned items reached!

You can pin to top only two items at once.
To however pin this item, unpin another before!' => 'Maks antall pins er nådd. Du kan bare pinne to innlegg på en gang. For å pinne dette innlegget, fjern pin på et annet innlegg først.',
  'This action is disabled!' => 'Denne handlingen er ikke tilgjengelig.',
);
