<?php
return array (
  'None' => 'Ingen',
);
