<?php
return array (
  'Tag' => 'Stikkord',
  'The given name is already in use.' => 'Oppgitt navn er allerede i bruk.',
);
