<?php
return array (
  '{displayName} created {contentTitle}.' => '{displayName} opprettet {contentTitle}.',
  '{displayName} posted on your profile {contentTitle}.' => '{displayName} postet på din profil {contentTitle}.',
);
