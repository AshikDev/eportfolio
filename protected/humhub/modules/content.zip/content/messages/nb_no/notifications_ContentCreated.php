<?php
return array (
  '{originator} just wrote {contentInfo}' => '{originator} skrev akkurat {contentInfo}',
  '{originator} just wrote {contentInfo} in space {space}' => '{originator} skrev akkurat {contentInfo} i gruppen {space}',
  '{originator} notifies you about {contentInfo}' => '{originator} varsler deg om {contentInfo}',
  '{originator} notifies you about {contentInfo} in {space}' => '{originator} varsler deg om {contentInfo} i gruppen {space}',
);
