<?php
return array (
  '{displayName} created {contentTitle}.' => '{displayName} ha creyau {contentTitle}.',
  '{displayName} posted on your profile {contentTitle}.' => '{displayName} ha publicau en o tuyo perfil {contentTitle}.',
);
