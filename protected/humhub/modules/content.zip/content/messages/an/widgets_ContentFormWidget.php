<?php
return array (
  'Submit' => 'Ninviar',
);
