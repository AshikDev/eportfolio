<?php
return array (
  'Turn off notifications' => 'Desactivar as notificacions',
  'Turn on notifications' => 'Activar as notificacions',
);
