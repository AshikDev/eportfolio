<?php
return array (
  '<strong>Confirm</strong> post deletion' => '<strong>Confirmar</strong> a eliminación d\'a publicación',
  'Cancel' => 'Cancelar',
  'Delete' => 'Eliminar',
  'Do you really want to delete this post? All likes and comments will be lost!' => 'Seguro que quiers borrar ista publicación? Totz os "me fa goyo" y comentarios tamién se borrarán!',
);
