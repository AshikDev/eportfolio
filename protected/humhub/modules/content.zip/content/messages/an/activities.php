<?php
return array (
  'Contents' => 'Contenius',
  'Whenever a new content (e.g. post) has been created.' => 'Quan un nuevo conteniu (eix. una publicación) s\'ha creyau.',
);
