<?php
return array (
  '{originator} just wrote {contentInfo}' => '{originator} acaba d\'escribir una {contentInfo}',
  '{originator} just wrote {contentInfo} in space {space}' => '{originator} acaba d\'escribir una {contentInfo} en l\'espacio {space}',
  '{originator} notifies you about {contentInfo}' => '{originator} t\'ha ninviau una aviso sobre un/una {contentInfo}',
  '{originator} notifies you about {contentInfo} in {space}' => '{originator} t\'ha ninviau una aviso sobre un/una {contentInfo} en {space}',
);
