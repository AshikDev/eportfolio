<?php
return array (
  'Pin to top' => 'Fixar a o principio',
  'Unpin' => 'Des-fixar',
);
