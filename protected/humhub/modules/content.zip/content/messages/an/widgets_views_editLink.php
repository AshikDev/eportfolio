<?php
return array (
  'Cancel Edit' => 'Cancelar edición',
  'Edit' => 'Editar',
);
