<?php
return array (
  'Pinned' => 'Fixau',
  'Unpinned' => 'Des-fixau',
);
