<?php
return array (
  'Add a member to notify' => 'Adhibir un miembro pa notificar-le',
  'Content visibility' => 'Visibilidat d\'o conteniu',
  'Make private' => 'Fer privau',
  'Make public' => 'Fer publico',
  'Notify members' => 'Notificar miembros',
  'Public' => 'Publico',
  'This space is archived.' => 'Iste espacio ye archivau.',
);
