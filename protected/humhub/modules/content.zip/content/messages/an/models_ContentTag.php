<?php
return array (
  'Tag' => 'Etiquetas',
  'The given name is already in use.' => '',
);
