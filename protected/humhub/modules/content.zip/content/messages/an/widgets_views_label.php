<?php
return array (
  'Archived' => 'Archivau',
  'Pinned' => 'Fixau',
  'Public' => 'Publico',
);
