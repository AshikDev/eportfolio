<?php
return array (
  'Move to archive' => 'Mover a l\'archivo',
  'Unarchive' => 'Quitar de l\'archivo',
);
