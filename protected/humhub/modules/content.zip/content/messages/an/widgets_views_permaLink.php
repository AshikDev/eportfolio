<?php
return array (
  '<strong>Permalink</strong> to this post' => '<strong>Vinclo</strong> a ista publicación',
  'Permalink' => 'Vinclo permanent',
);
