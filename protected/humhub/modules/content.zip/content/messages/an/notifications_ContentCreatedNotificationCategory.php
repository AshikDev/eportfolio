<?php
return array (
  'New Content' => 'Nuevo conteniu',
  'Receive Notifications for new content you follow.' => 'Recibir notificacions pa nuevo conteniu que sigues.',
);
