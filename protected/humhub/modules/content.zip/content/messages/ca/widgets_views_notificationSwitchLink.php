<?php
return array (
  'Turn off notifications' => 'Deshabilitar notificacions',
  'Turn on notifications' => 'Habilitar notificacions',
);
