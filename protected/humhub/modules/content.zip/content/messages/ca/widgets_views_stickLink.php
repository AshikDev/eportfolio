<?php
return array (
  'Pinned' => 'Fixa a dalt',
  'Unpinned' => 'Desfixa',
);
