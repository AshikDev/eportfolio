<?php
return array (
  'Could not delete content!' => 'No es pot eliminar el contingut!',
  'Could not delete content: Access denied!' => 'No es pot eliminar el contingut: Accés denegat!',
  'Could not load requested object!' => 'No s\'ha pogut carregar l\'objecte sol·licitat!',
  'Invalid request method!' => 'Petició invàlida',
  'Maximum number of pinned items reached!

You can pin to top only two items at once.
To however pin this item, unpin another before!' => 'Has arribat al nombre màxim d\'elements ancorats! Pot ancorar al principi només dos elements alhora. No obstant això si necessitar ancorar aquest element, desancore un altre abans!',
  'This action is disabled!' => 'Aquesta acció no està habilitada!',
);
