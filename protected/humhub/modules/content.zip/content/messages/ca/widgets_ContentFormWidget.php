<?php
return array (
  'Submit' => 'Publica',
);
