<?php
return array (
  '<strong>Confirm</strong> post deletion' => '
<strong>Confirmar</strong> l\'eliminació del post
',
  'Cancel' => 'Cancel·la',
  'Delete' => 'Suprimeix',
  'Do you really want to delete this post? All likes and comments will be lost!' => 'De veritat vol eliminar aquest post? Tots els m\'agrada i els comentaris es perdran!',
);
