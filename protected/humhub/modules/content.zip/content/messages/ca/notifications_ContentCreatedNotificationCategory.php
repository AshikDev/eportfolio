<?php
return array (
  'New Content' => 'Nou contingut',
  'Receive Notifications for new content you follow.' => 'Rebre notificacions de nous continguts que segueix-ho.',
);
