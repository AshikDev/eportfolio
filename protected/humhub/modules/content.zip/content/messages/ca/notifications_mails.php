<?php
return array (
  'View Online' => 'Vore en línia',
);
