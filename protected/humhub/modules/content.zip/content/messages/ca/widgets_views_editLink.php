<?php
return array (
  'Cancel Edit' => 'Cancel·lar edició',
  'Edit' => 'Editar',
);
