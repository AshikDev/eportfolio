<?php
return array (
  'Could not find requested content!' => 'No s\'ha pogut trobar el contingut sol·licitat!',
);
