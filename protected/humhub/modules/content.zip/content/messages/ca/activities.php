<?php
return array (
  'Contents' => 'Continguts',
  'Whenever a new content (e.g. post) has been created.' => 'Un nou contingut (per exemple: un post) ha sigut creat',
);
