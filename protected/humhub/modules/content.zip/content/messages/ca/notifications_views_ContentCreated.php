<?php
return array (
  '{displayName} created {contentTitle}.' => '{displayName} ha creat {contentTitle}.
',
  '{displayName} posted on your profile {contentTitle}.' => '{displayName} ha publicat al vostre perfil {contentTitle}.',
);
