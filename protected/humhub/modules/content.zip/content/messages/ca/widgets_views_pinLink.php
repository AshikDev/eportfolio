<?php
return array (
  'Pin to top' => 'Ancorar al principi',
  'Unpin' => 'Desancorar',
);
