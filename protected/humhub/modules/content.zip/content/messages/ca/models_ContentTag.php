<?php
return array (
  'Tag' => 'Etiqueta',
  'The given name is already in use.' => 'El nom especificat ja està en ús.',
);
