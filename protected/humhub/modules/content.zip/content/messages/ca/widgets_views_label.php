<?php
return array (
  'Archived' => 'Arxivat',
  'Public' => 'Públic',
  'Pinned' => 'Fixat',
);
