<?php
return array (
  'Add a member to notify' => 'Afegir un membre a notificar',
  'Content visibility' => 'Visibilitat del contingut',
  'Make private' => 'Fer privat',
  'Make public' => 'Fer públic',
  'Notify members' => 'Notificar els membres',
  'Public' => 'Públic',
  'This space is archived.' => 'Aquest espai ha sigut arxivat',
);
