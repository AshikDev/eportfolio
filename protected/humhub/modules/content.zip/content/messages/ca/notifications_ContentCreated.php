<?php
return array (
  '{originator} just wrote {contentInfo}' => '
{originator} acabe d\'esctiure {contentInfo}
',
  '{originator} just wrote {contentInfo} in space {space}' => '{originator} acabe d\'esctiure {contentInfo} en l\'espai {space}',
  '{originator} notifies you about {contentInfo}' => '
{originator} t\'ha notificat sobre {contentInfo}
',
  '{originator} notifies you about {contentInfo} in {space}' => '{originator} t\'ha notificat sobre {contentInfo} en l\'espai',
);
