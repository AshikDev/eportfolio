<?php
/* @var $this humhub\components\View */
?>
<li>
    <a href="#" data-action-click="content.permalink" data-content-permalink="<?= $permaLink ?>">
        <i class="fa fa-link"></i><?= Yii::t('ContentModule.widgets_views_permaLink', 'Permalink') ?>
    </a>
</li>
