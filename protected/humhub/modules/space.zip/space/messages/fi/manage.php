<?php
return array (
  'As owner of this space you can transfer this role to another administrator in space.' => 'Tämän tilan omistajana voit siirtää tämän tehtävän toiselle ylläpitäjälle tällä sivulla.',
  'Remove from space' => 'Poista sivulta',
  'Show all' => 'Näytä kaikki',
  'Space owner' => 'Sivun omistaja',
  'The url contains illegal characters!' => 'linkki sisältää laittomia merkkejä!',
  'Transfer ownership' => 'Siirrä omistajuus',
  'e.g. example for {baseUrl}/s/example' => 'esim. esimerkki {baseUrl} esimerkille',
  'the default start page of this space for members' => 'Sivu joka näkyy jäsenille ensimmäisenä',
  'the default start page of this space for visitors' => 'Sivu joka näkyy vierailioille ensimmäisenä',
);
