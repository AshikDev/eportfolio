<?php
return array (
  '<strong>Request</strong> space membership' => '<strong>Lähetä</strong> liitymispyyntö',
  'Close' => 'Sulje',
  'Your request was successfully submitted to the space administrators.' => 'Pyyntösi lähetettiin onnistuneesti sivun ylläpitäjille.',
);
