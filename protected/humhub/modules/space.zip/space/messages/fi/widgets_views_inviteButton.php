<?php
return array (
  'Invite' => 'Kutsu',
);
