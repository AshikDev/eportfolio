<?php
return array (
  '<strong>Confirm</strong> image deleting' => '<strong>Vahvista</strong> kuvan poistaminen',
  'Cancel' => 'Peruuta',
  'Delete' => 'Poista',
  'Do you really want to delete your title image?' => 'Haluatko todella poistaa otsikko kuvan?',
);
