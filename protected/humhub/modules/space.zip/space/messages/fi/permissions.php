<?php
return array (
  'Allows the user to create private content' => 'Antaa käyttäjien luoda yksityistä sisältöä',
  'Allows the user to create public content' => 'Salli käyttäjien luoda julkista sisältöä',
  'Allows the user to invite new members to the space' => 'Anna käyttäjien kutsua uusia jäseniä sivulle',
  'Can create hidden (private) spaces.' => 'Voi luoda piilotettuja (yksityisiä) sivuja.',
  'Can create public visible spaces. (Listed in directory)' => 'Voi luoda julkisia näkyviä sivuja. (Näytetään hakemistossa)',
  'Create private content' => 'Luo yksityistä sisältöä',
  'Create private space' => 'Luoda yksityisiä sivuja',
  'Create public content' => 'Luoda julkista sisältöä',
  'Create public space' => 'Luoda julkisia sivuja',
  'Invite users' => 'Kutsua käyttäjiä',
);
