<?php
return array (
  'Receive Notifications of Space Membership events.' => 'Saat ilmoitukset sivujen tapahtumista.',
  'Space Membership' => 'Sivun jäsenyys',
);
