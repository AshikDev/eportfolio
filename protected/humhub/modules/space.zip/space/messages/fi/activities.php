<?php
return array (
  'Space has been archived' => 'Sivu arkistoitiin',
  'Space has been unarchived' => 'Sivun arkistointi poistettiin',
  'Space member joined' => 'Jäsen liityi sivulle',
  'Space member left' => 'Jäsen lähti sivulta',
  'Whenever a member leaves one of your spaces.' => 'Aina kun joku jättää jonkin sivun',
  'Whenever a new member joined one of your spaces.' => 'Aina kun uusi jäsen liittyi jollekkin sivulle.',
  'Whenever a space is archived.' => 'Aina kun sivu arkistoidaan',
  'Whenever a space is unarchived.' => 'Aina kun sivun arkistointi poistetaan',
);
