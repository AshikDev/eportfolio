<?php
return array (
  '<strong>Confirm</strong> image deleting' => '<strong>Vahvista</strong> kuvan poistaminen',
  'Cancel' => 'Peruuta',
  'Delete' => 'Poista',
  'Do you really want to delete your profile image?' => 'Haluatko todella poistaa profiilikuvan?',
);
