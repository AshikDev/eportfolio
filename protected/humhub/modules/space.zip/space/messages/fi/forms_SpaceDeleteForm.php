<?php
return array (
  'Your password' => 'Syötä salasana',
);
