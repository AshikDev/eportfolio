<?php
return array (
  '<strong>Invite</strong> members' => '<strong>Kutsu</strong> jäseniä',
  'Add users without invitation' => 'Lisää käyttäjiä ilman kutsua',
  'Done' => 'Tehty',
  'Email addresses' => 'Sähköpostiosoitteet',
  'Invite by email' => 'Kutsu sähköpostitse',
  'Login' => 'Kirjaudu sisään',
  'New user?' => 'Uusi käyttäjä?',
  'Pick users' => 'Valitse käyttäjät',
  'Select all registered users' => 'Valitse kaikki rekisteröityneet käyttäjät',
  'Send' => 'Lähetä',
  'To invite users to this space, please type their names below to find and pick them.' => 'Jos haluat kutsua käyttäjiä tälle sivulle, kirjoita heidän nimensä alle',
  'You can also invite external users, which are not registered now. Just add their e-mail addresses separated by comma.' => 'Voit myös kutsua ulkopuolisia käyttäjiä, joitka eivät ole vielä rekisteröityneitä. Lisää vain sähköpostiosoitteet pilkulla erotettuina.',
);
