<?php
return array (
  'Close' => 'Sulje',
  'Request workspace membership' => 'Lähetä liitymispyyntö',
  'Your request was successfully submitted to the workspace administrators.' => 'Pyyntösi lähetettiin onnistuneesti sivun ylläpitäjille.',
);
