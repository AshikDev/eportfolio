<?php
return array (
  'Follow' => 'Seuraa',
  'Unfollow' => 'Poista seuraus',
);
