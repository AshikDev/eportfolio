<?php
return array (
  '<i class="fa fa-cog"></i>' => '<i class="fa fa-cog"></i>',
  'Cancel Membership' => 'Peruuta jäsenyys',
  'Don\'t receive notifications for new content' => 'En halua ilmoituksia uudesta sisällöstä',
  'Hide posts on dashboard' => 'Piilota viestit hallintapaneelissa',
  'Members' => 'Jäsenet',
  'Modules' => 'Laajennukset',
  'Receive Notifications for new content' => 'Vastaanota ilmoituksia uudesta sisällöstä',
  'Security' => 'Turvallisuus',
  'Show posts on dashboard' => 'Näytä julkaisut työpöydällä',
  'This option will hide new content from this space at your dashboard' => 'Tämä vaihtoehto piilottaa uuden sisällön työpöydältäsi',
  'This option will show new content from this space at your dashboard' => 'Tämä vaihtoehto näyttää uuden sisällön työpöydältäsi',
);
