<?php
return array (
  '<strong>Something</strong> went wrong' => '<strong>Jokin</strong> meni vikaan',
  'Followers' => 'Seuraajat',
  'Members' => 'Jäsenet',
  'Ok' => 'Ok',
  'Posts' => 'Julkaisut',
);
