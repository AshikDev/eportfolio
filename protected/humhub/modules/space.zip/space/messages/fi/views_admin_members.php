<?php
return array (
  '-' => '-',
  '<strong>Manage</strong> members' => '<strong>Hallinnoi</strong> sivun jäseniä',
  'Actions' => 'Toiminnot',
  'Role' => 'Rooli',
  'never' => 'Ei koskaan',
);
