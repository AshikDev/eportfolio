<?php
return array (
  'Archive' => 'Arkisto',
  'Choose if new content should be public or private by default' => 'Valitse, onko uusi sisältö oletuksena julkinen vai yksityinen',
  'Choose the kind of membership you want to provide for this workspace.' => 'Valitse millaiset jäsenyydet holuat sivulle.',
  'Choose the security level for this workspace to define the visibleness.' => 'Valitse sivun turvallisuustaso määrittääksesi näkyvyyden.',
  'Delete' => 'Poista',
  'Save' => 'Tallenna',
  'Unarchive' => 'Poista arkistosta',
);
