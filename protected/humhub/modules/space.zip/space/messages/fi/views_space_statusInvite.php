<?php
return array (
  'Users has been invited.' => 'Käyttäjät on kutsuttu.',
);
