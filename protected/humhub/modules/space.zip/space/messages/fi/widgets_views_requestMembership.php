<?php
return array (
  'Cancel' => 'Peruuta',
  'Please shortly introduce yourself, to become a approved member of this workspace.' => 'Kerro itsestäsi jotain.',
  'Request workspace membership' => 'Lähetä liitymispyyntö',
  'Send' => 'Lähetä',
);
