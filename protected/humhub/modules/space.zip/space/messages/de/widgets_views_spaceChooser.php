<?php
return array (
  'Create new space' => 'Neuen Space erstellen',
  'My spaces' => 'Meine Spaces',
  'No member or following spaces found.' => 'Keine Mitglieder oder folgende Spaces gefunden.',
  'No result found for the given filter.' => 'Kein Ergebnis für den ausgewählten Filter.',
  'Search' => 'Suchen',
  'Search for spaces' => 'Nach Spaces suchen',
  'To search for other spaces, type at least {count} characters.' => 'Um nach anderen Spaces zu suchen, bitte wenigstens {count} Zeichen eingeben.',
);
