<?php
return array (
  '<strong>Invite</strong> members' => 'Mitglieder <strong>einladen</strong>',
  'Add users without invitation' => 'Benutzer ohne Einladung hinzufügen',
  'Done' => 'Abgeschlossen',
  'Email addresses' => 'E-Mail-Adressen',
  'Invite by email' => 'Per E-Mail einladen',
  'Login' => 'Login',
  'New user?' => 'Neuer User?',
  'Pick users' => 'Benutzer auswählen',
  'Select all registered users' => 'Alle registrierten Benutzer auswählen',
  'Send' => 'Senden',
  'To invite users to this space, please type their names below to find and pick them.' => 'Um Benutzer in diesen Space einzuladen, gib deren Name unten ein, um sie zu suchen und auszuwählen.',
  'You can also invite external users, which are not registered now. Just add their e-mail addresses separated by comma.' => 'Du kannst auch externe Benutzer einladen, die noch nicht registriert sind. Gib einfach ihre E-Mail-Adressen, durch Kommas getrennt, ein.',
);
