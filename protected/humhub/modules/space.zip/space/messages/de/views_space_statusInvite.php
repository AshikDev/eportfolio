<?php
return array (
  'Users has been invited.' => 'Benutzer wurden eingeladen.',
);
