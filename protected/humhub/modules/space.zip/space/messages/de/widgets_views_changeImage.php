<?php
return array (
  'Change image' => 'Bild ändern',
  'Current space image' => 'Aktuelles Space-Bild',
);
