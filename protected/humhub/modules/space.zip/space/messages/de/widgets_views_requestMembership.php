<?php
return array (
  'Cancel' => 'Abbrechen',
  'Please shortly introduce yourself, to become a approved member of this workspace.' => 'Um bestätigtes Mitglied dieses Spaces zu werden, stelle dich bitte kurz vor.',
  'Request workspace membership' => 'Space-Mitgliedschaft beantragen',
  'Send' => 'Senden',
);
