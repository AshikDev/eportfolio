<?php
return array (
  '-' => '-',
  '<strong>Manage</strong> members' => 'Mitglieder <strong>verwalten</strong>',
  'Actions' => 'Aktionen',
  'Role' => 'Rolle',
  'never' => 'Nie',
);
