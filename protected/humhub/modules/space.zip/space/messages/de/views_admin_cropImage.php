<?php
return array (
  '<strong>Modify</strong> space image' => 'Space-Bild <strong>ändern</strong>',
  'Close' => 'Schließen',
);
