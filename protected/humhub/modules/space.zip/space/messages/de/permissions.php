<?php
return array (
  'Allows the user to create private content' => 'Benutzer erlauben private Inhalte zu erstellen',
  'Allows the user to create public content' => 'Benutzern erlauben öffentliche Inhalte zu erstellen',
  'Allows the user to invite new members to the space' => 'Benutzern erlauben andere Benutzer in den Space einzuladen',
  'Can create hidden (private) spaces.' => 'Kann versteckte (private) Spaces erstellen.',
  'Can create public visible spaces. (Listed in directory)' => 'Kann öffentlich sichtbare Spaces erstellen. (gelistet im Verzeichnis)',
  'Create private content' => 'Private Inhalte erstellen',
  'Create private space' => 'Privaten Space anlegen',
  'Create public content' => 'Öffentlichen Inhalt erstellen',
  'Create public space' => 'Öffentlichen Space anlegen',
  'Invite users' => 'Benutzer einladen',
);
