<?php
return array (
  '<strong>Request</strong> space membership' => 'Space-Mitgliedschaft <strong>beantragen</strong> ',
  'Close' => 'Schließen',
  'Your request was successfully submitted to the space administrators.' => 'Deine Anfrage wurde erfolgreich an die Space-Administratoren weitergeleitet.',
);
