<?php
return array (
  'As owner you cannot revoke your membership!' => 'Als Besitzer kannst du deine Mitgliedschaft nicht kündigen!',
  'Could not request membership!' => 'Mitgliedschaft konnte nicht beantragt werden!',
  'Sorry, you are not allowed to leave this space!' => 'Sorry, aber du kannst diesen Space nicht verlassen.',
  'There is no pending invite!' => 'Keine ausstehenden Einladungen!',
  'This action is only available for workspace members!' => 'Diese Aktion ist nur für Space-Mitglieder verfügbar!',
  'This user is already a member of this space.' => 'Dieser Benutzer ist bereits Miglied dieses Space.',
  'This user is not a member of this space.' => 'Dieser Benutzer ist kein Mitglied dieses Space.',
  'You are not allowed to join this space!' => 'Du darfst diesem Space nicht betreten!',
);
