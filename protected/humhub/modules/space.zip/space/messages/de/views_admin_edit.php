<?php
return array (
  'Archive' => 'Archivieren',
  'Choose if new content should be public or private by default' => 'Festlegen, ob neue Inhalte standardmäßig als öffentlich oder privat gekennzeichnet werden',
  'Choose the kind of membership you want to provide for this workspace.' => 'Wähle den Typ der Mitgliedschaft, den du für diesen Space zur Verfügung stellen möchtest.',
  'Choose the security level for this workspace to define the visibleness.' => 'Wähle die Sicherheitsstufe für diesen Space, um die Sichtbarkeit zu bestimmen.',
  'Delete' => 'Löschen',
  'Save' => 'Speichern',
  'Unarchive' => 'Aus dem Archiv',
);
