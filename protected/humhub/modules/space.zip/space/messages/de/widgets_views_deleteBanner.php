<?php
return array (
  '<strong>Confirm</strong> image deleting' => 'Löschen des Bildes <strong>bestätigen</strong> ',
  'Cancel' => 'Abbrechen',
  'Delete' => 'Löschen',
  'Do you really want to delete your title image?' => 'Möchtest du wirklich dein Titelbild löschen?',
);
