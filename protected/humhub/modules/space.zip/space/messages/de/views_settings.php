<?php
return array (
  '<strong>Security</strong> settings' => '<strong>Sicherheits</strong>-Einstellungen',
  '<strong>Space</strong> settings' => '<strong>Space</strong>-Einstellungen',
  'Permissions are assigned to different user-roles. To edit a permission, select the user-role you want to edit and change the drop-down value of the given permission.' => 'Berechtigungen sind mit unterschiedlichen Benutzerollen verknüpft. Um eine Berechtigung zu bearbeiten, wähle die betreffende Benutzerrolle und ordne über das Dropdown-Feld eine andere Berechtigung zu.',
);
