<?php
return array (
  'Add {n,plural,=1{space} other{spaces}}' => '{n,plural,=1{Space} other{Spaces}} hinzufügen',
);
