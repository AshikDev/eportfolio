<?php
return array (
  'Add Space' => 'Space hinzufügen',
  'No spaces found for the given query' => 'Für diese Abfrage wurden keine Spaces gefunden',
  'Select {n,plural,=1{space} other{spaces}}' => '{n,plural,=1{Space} other{Spaces}} auswählen 
',
  'This field only allows a maximum of {n,plural,=1{# space} other{# spaces}}' => 'Dieses Feld erlaubt maximal {n,plural,=1{einen Space} other{# Spaces}}
',
);
