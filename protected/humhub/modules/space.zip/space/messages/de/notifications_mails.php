<?php
return array (
  'View Online' => 'Online ansehen',
);
