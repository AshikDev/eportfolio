<?php
return array (
  'Accept Invite' => 'Einladung annehmen',
  'Become member' => 'Mitglied werden',
  'Cancel pending membership application' => 'Ausstehenden Mitgliedsantrag zurückziehen',
  'Deny Invite' => 'Einladung ablehnen',
  'Request membership' => 'Mitgliedschaft beantragen',
);
