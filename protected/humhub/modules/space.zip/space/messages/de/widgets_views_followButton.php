<?php
return array (
  'Follow' => 'Folgen',
  'Unfollow' => 'Nicht mehr folgen',
);
