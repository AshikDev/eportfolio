<?php
return array (
  'Invite' => 'Einladen',
);
