<?php
return array (
  '<strong>Space</strong> Modules' => '<strong>Space</strong> Module',
  'Activated' => 'Aktiviert',
  'Are you sure? *ALL* module data for this space will be deleted!' => 'Bist du sicher? *ALLE* Modul-Daten für diesen Space werden gelöscht!',
  'Configure' => 'Konfigurieren',
  'Currently there are no modules available for this space!' => 'Derzeit sind keine Module für diesen Space verfügbar!',
  'Disable' => 'Deaktivieren',
  'Enable' => 'Aktivieren',
  'Enhance this space with modules.' => 'Diesen Space mit Modulen erweitern.',
);
