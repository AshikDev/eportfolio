<?php
return array (
  '<strong>Confirm</strong> image deleting' => '',
  'Cancel' => 'Отказ',
  'Delete' => 'Изтрий',
  'Do you really want to delete your profile image?' => '',
);
