<?php
return array (
  'Add <strong>Modules</strong>' => '追加 <strong>モジュール</strong>',
);
