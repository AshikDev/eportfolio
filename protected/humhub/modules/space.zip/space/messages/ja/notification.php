<?php
return array (
  'You were added to Space {spaceName}' => 'あなたはスペースに追加されました {spaceName}',
  '{displayName} accepted your invite for the space {spaceName}' => '{displayName} はあなたの招待を受けました スペース名： {spaceName}',
  '{displayName} approved your membership for the space {spaceName}' => '',
  '{displayName} changed your role to {roleName} in the space {spaceName}.' => '',
  '{displayName} declined your invite for the space {spaceName}' => '',
  '{displayName} declined your membership request for the space {spaceName}' => '',
  '{displayName} invited you to the space {spaceName}' => '{displayName} はあなたを招待しました スペース名： {spaceName}',
  '{displayName} requests membership for the space {spaceName}' => '',
);
