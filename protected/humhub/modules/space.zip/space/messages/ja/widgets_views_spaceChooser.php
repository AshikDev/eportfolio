<?php
return array (
  'Create new space' => 'スペースを作成する',
  'My spaces' => 'マイスペース',
  'No member or following spaces found.' => '',
  'No result found for the given filter.' => 'この文字列では見つかりませんでした',
  'Search' => '検索',
  'Search for spaces' => '',
  'To search for other spaces, type at least {count} characters.' => 'スペースを検索するには最低2文字必要です',
);
