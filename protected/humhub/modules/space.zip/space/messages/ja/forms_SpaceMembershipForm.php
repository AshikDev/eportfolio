<?php
return array (
  'Application message' => 'アプリケーションメッセージ',
);
