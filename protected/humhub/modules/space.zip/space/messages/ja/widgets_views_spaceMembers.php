<?php
return array (
  '<strong>New</strong> member request' => '<strong>新規</strong> メンバーのリクエスト',
  '<strong>Space</strong> members' => '<strong>スペース</strong> メンバー',
  'Show all' => '全て見る',
);
