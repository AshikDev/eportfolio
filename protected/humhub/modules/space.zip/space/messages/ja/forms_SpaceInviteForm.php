<?php
return array (
  'Invites' => '招待',
  'New user by e-mail (comma separated)' => 'メールで新規ユーザー登録（カンマ区切り）',
  'User \'{username}\' is already a member of this space!' => 'ユーザー \'{username}\' はもう既にメンバーです。',
  'User \'{username}\' is already an applicant of this space!' => '',
  'User not found!' => 'ユーザーが見つかりませんでした！',
  '{email} is already registered!' => '{email}は既に登録されています！',
  '{email} is not valid!' => '{email}は有効ではありません！',
);
