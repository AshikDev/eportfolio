<?php
return array (
  'Space is invisible!' => 'スペースが不可視です！',
  'You need to login to view contents of this space!' => 'このスペースを閲覧するにはログインが必要です',
);
