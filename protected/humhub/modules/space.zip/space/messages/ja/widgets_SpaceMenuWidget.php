<?php
return array (
  '<strong>Space</strong> menu' => '<strong>スペース</strong> メニュー',
  'Stream' => 'ストリーム',
);
