<?php
return array (
  'View Online' => 'オンラインで見る',
);
