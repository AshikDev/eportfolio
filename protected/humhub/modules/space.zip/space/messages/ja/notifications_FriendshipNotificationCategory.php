<?php
return array (
  'Friendship' => 'フレンドシップ',
  'Receive Notifications for Friendship Request and Approval events.' => '',
);
