<?php
return array (
  '-' => '-',
  '<strong>Manage</strong> members' => '<strong>メンバー</strong> 管理',
  'Actions' => '',
  'Role' => '役割',
  'never' => '',
);
