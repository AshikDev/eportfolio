<?php
return array (
  'This space is archived' => '',
  'You are a member of this space' => 'あなたは、このスペースのメンバーです',
  'You are following this space' => 'あなたは、このスペースをフォローしています',
);
