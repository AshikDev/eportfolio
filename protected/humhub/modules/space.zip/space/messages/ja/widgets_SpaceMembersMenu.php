<?php
return array (
  'Members' => 'メンバー',
  'Owner' => '所有者',
  'Pending Approvals' => '',
  'Pending Invites' => '',
);
