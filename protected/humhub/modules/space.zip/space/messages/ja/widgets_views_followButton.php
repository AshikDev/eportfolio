<?php
return array (
  'Follow' => 'フォロー',
  'Unfollow' => 'アンフォロー',
);
