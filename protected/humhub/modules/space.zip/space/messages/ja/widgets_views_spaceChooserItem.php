<?php
return array (
  '{n,plural,=1{# new entry} other{# new entries}} since your last visit' => '{n,plural,=1{# new entry} other{# new entries}} 最終ログインからの変化',
);
