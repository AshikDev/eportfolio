<?php
return array (
  'My Space List' => 'スペースのリスト',
  'My space summary' => 'スペースのサマリー',
  'Space directory' => 'スペースのディレクトリ',
  'Spaces' => 'スペース',
);
