<?php
return array (
  '<strong>Confirm</strong> image deleting' => '',
  'Cancel' => 'キャンセル',
  'Delete' => '削除',
  'Do you really want to delete your profile image?' => '',
);
