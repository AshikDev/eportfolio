<?php
return array (
  'Your password' => 'あなたのパスワード',
);
