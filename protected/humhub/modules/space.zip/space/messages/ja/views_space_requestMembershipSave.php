<?php
return array (
  '<strong>Request</strong> space membership' => '',
  'Close' => '閉じる',
  'Your request was successfully submitted to the space administrators.' => '',
);
