<?php
return array (
  'Stream (Default)' => 'ストリーム（デフォルト）',
);
