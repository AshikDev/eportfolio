<?php
return array (
  'Accept Invite' => '招待を受ける',
  'Become member' => 'メンバーになる',
  'Cancel pending membership application' => '',
  'Deny Invite' => '招待を断る',
  'Request membership' => '',
);
