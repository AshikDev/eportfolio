<?php
return array (
  'As owner of this space you can transfer this role to another administrator in space.' => 'スペースの所有者を別の管理者に移設できます。',
  'Remove from space' => 'このスペースから追放する',
  'Show all' => '所有者の移設',
  'Space owner' => 'スペースの所有者',
  'The url contains illegal characters!' => '',
  'Transfer ownership' => '所有者の移設',
  'e.g. example for {baseUrl}/s/example' => '',
  'the default start page of this space for members' => 'メンバーがこのスペースにアクセスしたときの画面です',
  'the default start page of this space for visitors' => 'メンバー以外がこのスペースにアクセスしたときの画面です',
);
