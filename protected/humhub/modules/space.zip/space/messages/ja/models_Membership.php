<?php
return array (
  'Created At' => '作成',
  'Created By' => '作成者',
  'Last Visit' => '最後の訪問',
  'Originator User ID' => '',
  'Request Message' => '',
  'Status' => 'ステータス',
  'Updated At' => '更新',
  'Updated By' => '',
);
