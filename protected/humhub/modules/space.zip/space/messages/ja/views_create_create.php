<?php
return array (
  '<strong>Create</strong> new space' => '<strong>新規作成</strong> スペース',
  'Advanced access settings' => '上級者向けのアクセス設定',
  'Next' => '次',
  'Space name' => 'スペース名',
  'space description' => 'スペースの説明文',
);
