<?php
return array (
  'Close' => '閉じる',
  'Request workspace membership' => '',
  'Your request was successfully submitted to the workspace administrators.' => '',
);
