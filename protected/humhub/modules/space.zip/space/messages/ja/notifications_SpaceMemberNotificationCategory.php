<?php
return array (
  'Receive Notifications of Space Membership events.' => 'スペースのメンバーに関する通知を受け取る',
  'Space Membership' => 'スペースのメンバー',
);
