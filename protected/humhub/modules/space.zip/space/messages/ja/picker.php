<?php
return array (
  'Add {n,plural,=1{space} other{spaces}}' => '追加 {n,plural,=1{space} other{spaces}}',
);
