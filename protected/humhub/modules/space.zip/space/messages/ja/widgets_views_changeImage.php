<?php
return array (
  'Change image' => 'イマージを変更',
  'Current space image' => '現在のイメージ',
);
