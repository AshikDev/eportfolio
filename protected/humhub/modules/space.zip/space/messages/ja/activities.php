<?php
return array (
  'Space has been archived' => 'スペースはアーカイブ化されました',
  'Space has been unarchived' => 'スペースはアーカイブ化を解除しました',
  'Space member joined' => 'スペースにメンバーが参加しました',
  'Space member left' => 'スペースからメンバーが脱退しました',
  'Whenever a member leaves one of your spaces.' => '',
  'Whenever a new member joined one of your spaces.' => '',
  'Whenever a space is archived.' => '',
  'Whenever a space is unarchived.' => '',
);
