<?php
return array (
  '<strong>Space</strong> Modules' => '<strong>スペース</strong> モジュール',
  'Activated' => '作動',
  'Are you sure? *ALL* module data for this space will be deleted!' => '',
  'Configure' => '設定',
  'Currently there are no modules available for this space!' => '現在、このスペースにはモジュールはありません',
  'Disable' => '無効化',
  'Enable' => '有効化',
  'Enhance this space with modules.' => '',
);
