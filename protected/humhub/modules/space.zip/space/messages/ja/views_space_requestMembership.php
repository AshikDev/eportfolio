<?php
return array (
  '<strong>Request</strong> space membership' => '<strong>リクエスト</strong> スペースメンバー',
  'Close' => '閉じる',
  'Please shortly introduce yourself, to become an approved member of this space.' => '',
);
