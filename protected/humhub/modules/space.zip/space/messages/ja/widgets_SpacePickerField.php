<?php
return array (
  'Add Space' => 'スペース追加',
  'No spaces found for the given query' => 'スペースは見つかりませんでした',
  'Select {n,plural,=1{space} other{spaces}}' => '',
  'This field only allows a maximum of {n,plural,=1{# space} other{# spaces}}' => '',
);
