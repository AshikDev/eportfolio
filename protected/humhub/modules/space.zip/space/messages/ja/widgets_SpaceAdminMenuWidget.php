<?php
return array (
  '<i class="fa fa-cog"></i>' => '<i class="fa fa-cog"></i> 設定',
  'Cancel Membership' => 'このスペースから脱退する',
  'Don\'t receive notifications for new content' => '通知を受け取らない',
  'Hide posts on dashboard' => 'ダッシュボードに表示しない',
  'Members' => 'メンバー',
  'Modules' => 'モジュール',
  'Receive Notifications for new content' => '通知を受け取る',
  'Security' => 'セキュリティ',
  'Show posts on dashboard' => 'ダッシュボードにも表示する',
  'This option will hide new content from this space at your dashboard' => 'このオプションを選ぶと、あなたのダッシュボードにこのスペースが表示されません',
  'This option will show new content from this space at your dashboard' => 'このオプションを選ぶと、あなたのダッシュボードにこのスペースが表示されます',
);
