<?php
return array (
  'Invite' => '招待',
);
