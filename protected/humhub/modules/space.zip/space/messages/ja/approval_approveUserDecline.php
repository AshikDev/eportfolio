<?php
return array (
  'Send & decline' => '送信 & 辞退',
);
