<?php
return array (
  '<strong>Something</strong> went wrong' => '<strong>何かが</strong> 誤っています',
  'Followers' => 'フォロワー',
  'Members' => 'メンバー',
  'Ok' => 'はい',
  'Posts' => '投稿数',
);
