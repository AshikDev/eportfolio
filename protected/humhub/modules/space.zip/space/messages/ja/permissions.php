<?php
return array (
  'Allows the user to create private content' => 'ユーザーが非公開コンテンツを作ることを許可する',
  'Allows the user to create public content' => 'ユーザーが公開コンテンツを作ることを許可する',
  'Allows the user to invite new members to the space' => '',
  'Can create hidden (private) spaces.' => '',
  'Can create public visible spaces. (Listed in directory)' => '',
  'Create private content' => '',
  'Create private space' => '',
  'Create public content' => '公開コンテンツ',
  'Create public space' => '',
  'Invite users' => 'ユーザー招待',
);
