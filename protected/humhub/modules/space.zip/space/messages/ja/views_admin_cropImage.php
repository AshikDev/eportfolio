<?php
return array (
  '<strong>Modify</strong> space image' => '<strong>編集</strong> スペースの画像',
  'Close' => '閉じる',
);
