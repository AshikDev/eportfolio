<?php
return array (
  '<b>This space is still empty!</b>' => '<b>このスペースにはまだ何も書かれていません</b>',
  '<b>This space is still empty!</b><br>Start by posting something here...' => '<b>このスペースにはまだ何も書かれていません</b><br>何か投稿してみてください…',
  '<b>You are not member of this space and there is no public content, yet!</b>' => '<b>このスペースは、メンバー以外の閲覧ができません。</b>',
);
