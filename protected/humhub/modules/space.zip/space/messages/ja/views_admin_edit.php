<?php
return array (
  'Archive' => '保管庫',
  'Choose if new content should be public or private by default' => '',
  'Choose the kind of membership you want to provide for this workspace.' => 'このワークスペースを提供したいメンバーシップの種類を選択してください。',
  'Choose the security level for this workspace to define the visibleness.' => '品質を定義するには、このワークスペースのセキュリティレベルを選択します。',
  'Delete' => '削除',
  'Save' => '保存',
  'Unarchive' => '解凍する',
);
