<?php
return array (
  '<strong>Create</strong> new space' => '<strong>Crea</strong> un nou espai',
  'Advanced access settings' => 'Configuració avançada',
  'Next' => 'Següent',
  'Space name' => '',
  'space description' => 'descripció de l\'espai',
);
