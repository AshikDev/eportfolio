<?php
return array (
  '<strong>Space</strong> Modules' => '<strong>Mòduls</strong> de l\'espai',
  'Activated' => 'Activat',
  'Are you sure? *ALL* module data for this space will be deleted!' => 'Estàs segur? *ALL* s\'eliminaran totes les dades dels mòduls d\'aquest espai!',
  'Configure' => 'Configura',
  'Currently there are no modules available for this space!' => 'Actualment no hi ha disponible cap mòdul per aquest espai!',
  'Disable' => 'Inhabilita',
  'Enable' => 'Habilita',
  'Enhance this space with modules.' => 'Millora aquest espai amb mòduls.',
);
