<?php
return array (
  'This space is archived' => '',
  'You are a member of this space' => 'Ets un membre d\'aquest espai',
  'You are following this space' => '',
);
