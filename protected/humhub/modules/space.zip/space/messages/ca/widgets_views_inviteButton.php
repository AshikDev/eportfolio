<?php
return array (
  'Invite' => 'Convida',
);
