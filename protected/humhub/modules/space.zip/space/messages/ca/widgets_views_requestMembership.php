<?php
return array (
  'Cancel' => 'Cancel·la',
  'Please shortly introduce yourself, to become a approved member of this workspace.' => 'Si us plau, presentat breument als administradors de l\'espai.',
  'Request workspace membership' => 'Sol·licita unir-te',
  'Send' => 'Envia',
);
