<?php
return array (
  '<strong>Confirm</strong> image deleting' => '',
  'Cancel' => 'Cancel·la',
  'Delete' => 'Suprimeix',
  'Do you really want to delete your title image?' => '',
);
