<?php
return array (
  'Your password' => 'La teva contrasenya',
);
