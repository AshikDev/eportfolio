<?php
return array (
  'Close' => 'Tanca',
  'Request workspace membership' => 'Sol·licita unir-te',
  'Your request was successfully submitted to the workspace administrators.' => 'La teva sol·licitud d\'unió s\'ha enviat correctament als administradors de l\'espai.',
);
