<?php
return array (
  'Change image' => 'Canvia la imatge',
  'Current space image' => 'Imatge de l\'espai actual',
);
