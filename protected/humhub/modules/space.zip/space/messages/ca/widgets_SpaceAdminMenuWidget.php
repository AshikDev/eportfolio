<?php
return array (
  '<i class="fa fa-cog"></i>' => '',
  'Cancel Membership' => '',
  'Don\'t receive notifications for new content' => '',
  'Hide posts on dashboard' => '',
  'Members' => 'Membres',
  'Modules' => 'Mòduls',
  'Receive Notifications for new content' => '',
  'Security' => 'Seguretat',
  'Show posts on dashboard' => '',
  'This option will hide new content from this space at your dashboard' => '',
  'This option will show new content from this space at your dashboard' => '',
);
