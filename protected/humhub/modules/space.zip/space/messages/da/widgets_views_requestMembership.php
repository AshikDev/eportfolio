<?php
return array (
  'Cancel' => 'Afbryd',
  'Please shortly introduce yourself, to become a approved member of this workspace.' => 'Venligst kort introducer dig selv, for at blive et anerkendt medlem af dette workspace.',
  'Request workspace membership' => 'Anmod om workspace medlemskab',
  'Send' => 'Send',
);
