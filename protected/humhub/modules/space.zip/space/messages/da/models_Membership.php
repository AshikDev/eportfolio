<?php
return array (
  'Created At' => 'Oprettet den',
  'Created By' => 'Oprettet af',
  'Last Visit' => '',
  'Originator User ID' => '',
  'Request Message' => '',
  'Status' => 'Status',
  'Updated At' => 'Opdateret den',
  'Updated By' => '',
);
