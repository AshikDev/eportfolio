<?php
return array (
  'Application message' => 'Applikations besked',
);
