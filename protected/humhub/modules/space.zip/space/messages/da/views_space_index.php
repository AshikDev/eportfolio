<?php
return array (
  '<b>This space is still empty!</b>' => '<b>Denne side er stadig tom!</b>',
  '<b>This space is still empty!</b><br>Start by posting something here...' => '<b>Denne side er stadig tom!</b><br>Start med at lave et opslag...',
  '<b>You are not member of this space and there is no public content, yet!</b>' => '<b>Du er ikke medlem af denne side og der er ikke noget offentlig indhold, endnu!</b>',
);
