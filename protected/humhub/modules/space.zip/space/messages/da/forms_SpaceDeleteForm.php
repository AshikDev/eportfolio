<?php
return array (
  'Your password' => 'Din adgangskode',
);
