<?php
return array (
  'Members' => 'Medlemmer',
  'Owner' => 'Ejer',
  'Pending Approvals' => '',
  'Pending Invites' => '',
);
