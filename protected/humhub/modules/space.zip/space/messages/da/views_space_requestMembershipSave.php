<?php
return array (
  '<strong>Request</strong> space membership' => '<strong>Anmod</strong> side medlemskab',
  'Close' => 'Luk',
  'Your request was successfully submitted to the space administrators.' => 'Din anmodning er med succes sendt til vores side administratorer.',
);
