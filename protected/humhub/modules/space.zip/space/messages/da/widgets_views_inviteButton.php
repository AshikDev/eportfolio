<?php
return array (
  'Invite' => 'Inviter',
);
