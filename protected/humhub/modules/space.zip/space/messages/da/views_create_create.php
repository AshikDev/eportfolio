<?php
return array (
  '<strong>Create</strong> new space' => '<strong>Opret</strong> ny side',
  'Advanced access settings' => 'Avancerede adgangsindstillinger',
  'Next' => 'Næste',
  'Space name' => 'Side navn',
  'space description' => 'side beskrivelse',
);
