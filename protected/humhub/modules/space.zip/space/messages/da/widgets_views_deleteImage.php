<?php
return array (
  '<strong>Confirm</strong> image deleting' => '<strong>Bekræft</strong> billede sletning',
  'Cancel' => 'Afbryd',
  'Delete' => 'Slet',
  'Do you really want to delete your profile image?' => 'Vil du virkelige slette dit profil billede?',
);
