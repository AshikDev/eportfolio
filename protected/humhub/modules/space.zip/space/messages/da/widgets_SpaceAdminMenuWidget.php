<?php
return array (
  '<i class="fa fa-cog"></i>' => '<i class="fa fa-cog"></i>',
  'Cancel Membership' => 'Afbryd Medlemsskab',
  'Don\'t receive notifications for new content' => '',
  'Hide posts on dashboard' => 'Skjul opslag på dashboard',
  'Members' => 'Medlemmer',
  'Modules' => 'Moduler',
  'Receive Notifications for new content' => '',
  'Security' => 'Sikkerhed',
  'Show posts on dashboard' => 'Vis opslag på dashboard',
  'This option will hide new content from this space at your dashboard' => 'Dette valg vil skjule nyt indhold fra denne side på dit dashboard',
  'This option will show new content from this space at your dashboard' => 'Dette valg vil vise nyt indhold fra denne side på dit dashboard',
);
