<?php
return array (
  'Follow' => 'Sledovat',
  'Unfollow' => 'Přestat sledovat',
);
