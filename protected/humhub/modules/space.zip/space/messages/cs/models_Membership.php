<?php
return array (
  'Created At' => 'Vytvořeno',
  'Created By' => 'Vytvořil(a)',
  'Last Visit' => 'Poslední návštěva ',
  'Originator User ID' => 'ID uživatele ',
  'Request Message' => 'Žádost o zprávu',
  'Status' => 'Stav',
  'Updated At' => 'Aktualizováno',
  'Updated By' => 'Aktualizoval/a',
);
