<?php
return array (
  '<strong>Security</strong> settings' => '<strong>Bezpečnostní</strong> nastavení',
  '<strong>Space</strong> settings' => 'Nastavení <strong>prostorů</strong> ',
  'Permissions are assigned to different user-roles. To edit a permission, select the user-role you want to edit and change the drop-down value of the given permission.' => 'Oprávnění jsou přiřazena různým uživatelským rolím. Chcete-li upravit oprávnění, vyberte roli uživatele, kterou chcete upravit, a změňte rozbalovací hodnotu daného oprávnění.',
);
