<?php
return array (
  'Stream (Default)' => 'Stream(Výchozí)',
);
