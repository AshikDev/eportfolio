<?php
return array (
  '<i class="fa fa-cog"></i>' => '<i class="fa fa-cog"></i>',
  'Cancel Membership' => 'Zrušit členství',
  'Don\'t receive notifications for new content' => 'Nepřijímá oznámení o novém obsahu',
  'Hide posts on dashboard' => 'Skrýt příspěvky na nástěnce',
  'Members' => 'Členové',
  'Modules' => 'Moduly',
  'Receive Notifications for new content' => 'Dostávat upozornění na nové příspěvky',
  'Security' => 'Zabezpečení',
  'Show posts on dashboard' => 'Zobrazit na nástěnce',
  'This option will hide new content from this space at your dashboard' => 'Tato volba skryje nový obsah z tohoto prostoru na nástěnce',
  'This option will show new content from this space at your dashboard' => 'Tato volba zobrazí nový obsah z tohoto prostoru na nástěnce',
);
