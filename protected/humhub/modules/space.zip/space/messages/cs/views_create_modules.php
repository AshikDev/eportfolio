<?php
return array (
  'Add <strong>Modules</strong>' => 'Přidat <strong>Moduly</strong>',
);
