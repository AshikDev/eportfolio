<?php
return array (
  '<strong>Create</strong> new space' => '<strong>Vytvořit</strong> nový prostor',
  'Advanced access settings' => 'Pokročilá nastavení přístupu a viditelnosti',
  'Next' => 'Další',
  'Space name' => 'Název prostoru',
  'space description' => 'Popis prostoru',
);
