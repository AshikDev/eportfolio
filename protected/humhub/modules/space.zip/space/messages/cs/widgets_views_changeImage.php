<?php
return array (
  'Change image' => 'Změnit obrázek',
  'Current space image' => 'Současný obrázek prostoru',
);
