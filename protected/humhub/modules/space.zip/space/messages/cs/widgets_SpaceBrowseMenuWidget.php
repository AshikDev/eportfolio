<?php
return array (
  'My Space List' => 'Můj seznam prostorů',
  'My space summary' => 'Můj souhrn z prostorů',
  'Space directory' => 'Adresář prostoru',
  'Spaces' => 'Prostory',
);
