<?php
return array (
  'Your password' => 'Vaše heslo',
);
