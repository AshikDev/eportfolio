<?php
return array (
  'Application message' => 'Zpráva aplikace',
);
