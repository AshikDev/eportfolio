<?php
return array (
  'Friendship' => 'Přátelství',
  'Receive Notifications for Friendship Request and Approval events.' => 'Obdržíte oznámení o událostech žádosti o přátelství a schválení.',
);
