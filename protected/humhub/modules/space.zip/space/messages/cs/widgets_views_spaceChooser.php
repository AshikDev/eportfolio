<?php
return array (
  'Create new space' => 'Vytvořit nový prostor',
  'My spaces' => 'Mé prostory',
  'No member or following spaces found.' => 'Žádný člen nebo následující prostory nebyly nalezeny.',
  'No result found for the given filter.' => 'Pro daný filtr nebyl nalezen žádný výsledek.',
  'Search' => 'Hledat',
  'Search for spaces' => 'Vyhledat prostor',
  'To search for other spaces, type at least {count} characters.' => 'Chcete-li hledat další prostory, zadejte alespoň {count} znaky.',
);
