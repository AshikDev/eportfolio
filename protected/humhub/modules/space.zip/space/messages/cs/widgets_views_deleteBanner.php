<?php
return array (
  '<strong>Confirm</strong> image deleting' => '<strong>Potvrďte</strong> smazání obrázku',
  'Cancel' => 'Zrušit',
  'Delete' => 'Smazat',
  'Do you really want to delete your title image?' => 'Opravdu chcete smazat svůj úvodní obrázek?',
);
