<?php
return array (
  'Invite' => 'Pozvat',
);
