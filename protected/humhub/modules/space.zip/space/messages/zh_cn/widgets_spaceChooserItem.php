<?php
return array (
  'This space is archived' => '该空间已归档',
  'You are a member of this space' => '你是这个空间成员之一',
  'You are following this space' => '你正在关注该空间',
);
