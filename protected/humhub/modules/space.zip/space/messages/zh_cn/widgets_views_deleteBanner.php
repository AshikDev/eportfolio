<?php
return array (
  '<strong>Confirm</strong> image deleting' => '<strong>确定</strong> 删除图片',
  'Cancel' => '取消',
  'Delete' => '删除',
  'Do you really want to delete your title image?' => '你真的要删除标题图片吗？',
);
