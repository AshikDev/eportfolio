<?php
return array (
  'Follow' => '关注',
  'Unfollow' => '取消关注',
);
