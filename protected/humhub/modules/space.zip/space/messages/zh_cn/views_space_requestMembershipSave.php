<?php
return array (
  '<strong>Request</strong> space membership' => '<strong>请求</strong> 加入空间',
  'Close' => '关闭',
  'Your request was successfully submitted to the space administrators.' => '你的请求已成功提交给了空间管理。',
);
