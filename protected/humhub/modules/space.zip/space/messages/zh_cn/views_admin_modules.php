<?php
return array (
  '<strong>Space</strong> Modules' => '<strong>空间</strong> 模块',
  'Activated' => '启用',
  'Are you sure? *ALL* module data for this space will be deleted!' => '你确定？这个模块的所有的数据将会被删除！',
  'Configure' => '配置',
  'Currently there are no modules available for this space!' => '该空间当前没有生效模块',
  'Disable' => '失效',
  'Enable' => '生效',
  'Enhance this space with modules.' => '用模块来增强这个空间。',
);
