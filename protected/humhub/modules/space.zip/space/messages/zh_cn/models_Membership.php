<?php
return array (
  'Created At' => '创建于',
  'Created By' => '创建人',
  'Last Visit' => '最后一次访问',
  'Originator User ID' => '原始用户ID',
  'Request Message' => '请求消息',
  'Status' => '状态',
  'Updated At' => '修改于',
  'Updated By' => '修改人',
);
