<?php
return array (
  'Invite' => '邀请',
);
