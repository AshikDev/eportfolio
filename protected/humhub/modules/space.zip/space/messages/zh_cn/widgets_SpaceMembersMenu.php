<?php
return array (
  'Members' => '成员',
  'Owner' => '拥有者',
  'Pending Approvals' => '待处理审核',
  'Pending Invites' => '待处理邀请',
);
