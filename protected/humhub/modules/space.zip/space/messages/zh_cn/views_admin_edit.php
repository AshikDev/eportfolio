<?php
return array (
  'Archive' => '存档',
  'Choose if new content should be public or private by default' => '选择新的内容默认应该是公开或是私有',
  'Choose the kind of membership you want to provide for this workspace.' => '选择你想为这个空间的哪种会员。',
  'Choose the security level for this workspace to define the visibleness.' => '选择这个空间的安全级别来定义可见性。',
  'Delete' => '删除',
  'Save' => '保存',
  'Unarchive' => '取消存档',
);
