<?php
return array (
  'Friendship' => '好友',
  'Receive Notifications for Friendship Request and Approval events.' => '接收友情请求和批准事件的通知。',
);
