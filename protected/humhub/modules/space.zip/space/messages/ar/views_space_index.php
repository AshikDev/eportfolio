<?php
return array (
  '<b>This space is still empty!</b>' => '',
  '<b>This space is still empty!</b><br>Start by posting something here...' => 'هذه الباحة تخلو من المحتويات! <br>يمكنك البدء و كتابة شيء ما...',
  '<b>You are not member of this space and there is no public content, yet!</b>' => '',
);
