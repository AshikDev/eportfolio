<?php
return array (
  'Your password' => 'كلمة المرور الخاصة بك',
);
