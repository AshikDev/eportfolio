<?php
return array (
  'Are you sure, that you want to delete this space? All published content will be removed!' => '',
  'Delete' => 'حذف',
  'Please provide your password to continue!' => '',
);
