<?php
return array (
  '<strong>Create</strong> new space' => '',
  'Advanced access settings' => '',
  'Next' => 'التالي',
  'Space name' => '',
  'space description' => '',
);
