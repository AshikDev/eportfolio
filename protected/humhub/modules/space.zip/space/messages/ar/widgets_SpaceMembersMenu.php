<?php
return array (
  'Members' => 'الأعضاء',
  'Owner' => '',
  'Pending Approvals' => '',
  'Pending Invites' => '',
);
