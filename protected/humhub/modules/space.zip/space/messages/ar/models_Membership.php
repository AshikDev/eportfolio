<?php
return array (
  'Created At' => '',
  'Created By' => 'تم وضعه بواسطة',
  'Last Visit' => '',
  'Originator User ID' => '',
  'Request Message' => '',
  'Status' => '',
  'Updated At' => '',
  'Updated By' => '',
);
