<?php
return array (
  '<strong>Request</strong> space membership' => '',
  'Close' => 'اغلاق',
  'Please shortly introduce yourself, to become an approved member of this space.' => '',
);
