<?php
return array (
  'Change image' => 'Zamień obrazek',
  'Current space image' => 'Obecny obrazek strefy ',
);
