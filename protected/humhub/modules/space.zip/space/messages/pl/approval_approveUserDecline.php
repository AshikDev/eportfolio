<?php
return array (
  'Send & decline' => 'Wyślij i odrzuć ',
);
