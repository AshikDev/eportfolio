<?php
return array (
  'Invite' => 'Zaproś',
);
