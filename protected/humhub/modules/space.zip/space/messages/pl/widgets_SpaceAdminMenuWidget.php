<?php
return array (
  '<i class="fa fa-cog"></i>' => '<i class="fa fa-cog"></i>',
  'Cancel Membership' => 'Anuluj Członkowstwo',
  'Don\'t receive notifications for new content' => '',
  'Hide posts on dashboard' => 'Ukryj wpisy na kokpicie',
  'Members' => 'Członkowie',
  'Modules' => 'Moduły ',
  'Receive Notifications for new content' => '',
  'Security' => 'Bezpieczeństwo',
  'Show posts on dashboard' => 'Pokaż wpisy na kokpicie',
  'This option will hide new content from this space at your dashboard' => 'Ta opcja ukryje nowe treści dla tej strefy na Twoim kokpicie',
  'This option will show new content from this space at your dashboard' => 'Ta opcja pokaże nowe treści dla tej strefy na Twoim kokpicie',
);
