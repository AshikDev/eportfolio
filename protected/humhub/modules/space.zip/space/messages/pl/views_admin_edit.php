<?php
return array (
  'Archive' => 'Archiwizuj',
  'Choose if new content should be public or private by default' => 'Wybierz czy nowe treści mają być domyślnie publiczne czy prywatne',
  'Choose the kind of membership you want to provide for this workspace.' => 'Wybierz rodzaj członkostwa który chcesz zapewnić tej grupie roboczej.',
  'Choose the security level for this workspace to define the visibleness.' => 'Wybierz poziom bezpieczeństwa dla tej grupy roboczej aby zdefiniować widoczność. ',
  'Delete' => 'Usuń',
  'Save' => 'Zapisz',
  'Unarchive' => 'Przywróć z archiwum',
);
