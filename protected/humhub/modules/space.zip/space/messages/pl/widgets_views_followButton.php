<?php
return array (
  'Follow' => 'Obserwuj',
  'Unfollow' => 'Nie obserwuj ',
);
