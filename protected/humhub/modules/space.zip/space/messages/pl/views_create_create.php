<?php
return array (
  '<strong>Create</strong> new space' => '<strong>Utwórz</strong> nową strefę',
  'Advanced access settings' => 'Zaawansowanie ustawienia dostępu',
  'Next' => 'Dalej',
  'Space name' => 'Nazwa strefy',
  'space description' => 'opis strefy',
);
