<?php
return array (
  'This space is archived' => '',
  'You are a member of this space' => 'Jesteś członkiem tej strefy ',
  'You are following this space' => '',
);
