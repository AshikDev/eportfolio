<?php
return array (
  '<strong>Request</strong> space membership' => '<strong>Złóż podanie</strong> o członkostwo w strefie',
  'Close' => 'Zamknij',
  'Your request was successfully submitted to the space administrators.' => 'Twoje podanie z powodzeniem zostało dodane i przesłane administratorom strefy.',
);
