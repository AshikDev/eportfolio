<?php
return array (
  'Space has been archived' => 'Strefa została zarchiwizowana',
  'Space has been unarchived' => 'Strefa została przywrócona z archiwum',
  'Space member joined' => 'Członek strefy dołączył',
  'Space member left' => 'Członek strefy odszedł',
  'Whenever a member leaves one of your spaces.' => '',
  'Whenever a new member joined one of your spaces.' => '',
  'Whenever a space is archived.' => '',
  'Whenever a space is unarchived.' => '',
);
