<?php
return array (
  'Members' => 'Członkowie',
  'Owner' => 'Właściciel',
  'Pending Approvals' => '',
  'Pending Invites' => '',
);
