<?php
return array (
  '<strong>New</strong> member request' => '<strong>Nowe</strong> podanie o członkostwo',
  '<strong>Space</strong> members' => '<strong>Członkowie</strong> strefy',
  'Show all' => 'Pokaż wszystko',
);
