<?php
return array (
  '<strong>Confirm</strong> image deleting' => '<strong>Potwierdź</strong> usunięcie obrazka',
  'Cancel' => 'Anuluj',
  'Delete' => 'Usuń',
  'Do you really want to delete your profile image?' => 'Na pewno chcesz usunąć obrazek profilowy?',
);
