<?php
return array (
  'Created At' => 'Utworzona o',
  'Created By' => 'Utworzona przez',
  'Last Visit' => '',
  'Originator User ID' => '',
  'Request Message' => '',
  'Status' => 'Status',
  'Updated At' => 'Zaktualizowana o ',
  'Updated By' => '',
);
