<?php
return array (
  'Application message' => 'Wiadomość o podanie',
);
