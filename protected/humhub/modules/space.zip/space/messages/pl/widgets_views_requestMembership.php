<?php
return array (
  'Cancel' => 'Anuluj',
  'Please shortly introduce yourself, to become a approved member of this workspace.' => 'Proszę krótko się przedstaw, aby zostać zatwierdzonym członkiem tej grupy roboczej.',
  'Request workspace membership' => 'Złóż podanie o członkostwo',
  'Send' => 'Wyślij',
);
