<?php
return array (
  'Add {n,plural,=1{space} other{spaces}}' => 'Dodaj {n,plural,=1{strefę} other{strefy}}',
);
