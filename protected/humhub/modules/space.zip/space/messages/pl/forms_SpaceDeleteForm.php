<?php
return array (
  'Your password' => 'Twoje hasło',
);
