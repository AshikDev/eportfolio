<?php
return array (
  '<strong>Confirm</strong> image deleting' => '<strong>Potwierdź</strong> usunięcie obrazka',
  'Cancel' => 'Anuluj',
  'Delete' => 'Usuń',
  'Do you really want to delete your title image?' => 'Na pewno chcesz usunąć obrazek tytułowy?',
);
