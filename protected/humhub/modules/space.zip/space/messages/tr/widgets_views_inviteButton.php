<?php
return array (
  'Invite' => 'Davet',
);
