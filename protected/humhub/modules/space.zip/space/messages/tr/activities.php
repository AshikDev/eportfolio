<?php
return array (
  'Space has been archived' => 'Mekan arşivlendi',
  'Space has been unarchived' => 'Mekan arşivlenmedi',
  'Space member joined' => 'Sayfa üyesi katıldı.',
  'Space member left' => 'Sayfa üyesi ayrıldı',
  'Whenever a member leaves one of your spaces.' => 'Sayfa üyelerinden biri sayfanızdan ayrıldığında.',
  'Whenever a new member joined one of your spaces.' => 'Yeni bir sayfa üyesi sayfanıza katıldığında.',
  'Whenever a space is archived.' => 'Bir mekan ne zaman arşivlendiğinde.',
  'Whenever a space is unarchived.' => 'Bir mekan ne zaman arşivden kaldırdıldığında.',
);
