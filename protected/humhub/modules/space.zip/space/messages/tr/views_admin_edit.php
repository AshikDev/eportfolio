<?php
return array (
  'Archive' => 'Arşiv',
  'Choose if new content should be public or private by default' => 'Yeni içeriğin varsayılan olarak genel mi yoksa özel mi olacağını seçin',
  'Choose the kind of membership you want to provide for this workspace.' => 'Bu çalışma alanı için sağlamak istediğiniz üyelik türünü seçin.',
  'Choose the security level for this workspace to define the visibleness.' => 'Görünürlüğü tanımlamak için bu çalışma alanının güvenlik seviyesini seçin.',
  'Delete' => 'Sil',
  'Save' => 'Kaydet',
  'Unarchive' => 'Arşivden çıkar',
);
