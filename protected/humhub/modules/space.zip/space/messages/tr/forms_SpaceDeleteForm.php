<?php
return array (
  'Your password' => 'Şifreniz',
);
