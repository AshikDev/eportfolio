<?php
return array (
  'Invites' => 'Davetler',
  'New user by e-mail (comma separated)' => 'e-posta adresi ile yeni kullanıcı (virgülle ayılmış)',
  'User \'{username}\' is already a member of this space!' => '{username} isimli kullanıcı zaten bu sayfa üyesi!',
  'User \'{username}\' is already an applicant of this space!' => '{username} isimli kullanıcı zaten bu sayfaya üyelik isteğinde bulunmuş!',
  'User not found!' => 'Kullanıcı bulunamadı!',
  '{email} is already registered!' => '{email} e-posta adresi zaten kayıtlı!',
  '{email} is not valid!' => '{email} adresi geçersiz!',
);
