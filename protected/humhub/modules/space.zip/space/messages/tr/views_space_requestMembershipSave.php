<?php
return array (
  '<strong>Request</strong> space membership' => '<strong>Mekan</strong> üyelik isteği',
  'Close' => 'Kapat',
  'Your request was successfully submitted to the space administrators.' => 'İsteğiniz başarılı bir şekilde mekan sahiplerine iletildi.',
);
