<?php
return array (
  'Send & decline' => 'Gönder ve Kabul etme',
);
