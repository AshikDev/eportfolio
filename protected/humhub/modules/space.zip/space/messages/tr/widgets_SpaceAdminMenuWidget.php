<?php
return array (
  '<i class="fa fa-cog"></i>' => '<i class="fa fa-cog"></i>',
  'Cancel Membership' => 'Üyeliği iptal et',
  'Don\'t receive notifications for new content' => 'Yeni içerik için bildirim alma',
  'Hide posts on dashboard' => 'Mesajları gizle',
  'Members' => 'Üyeler',
  'Modules' => 'Modüller',
  'Receive Notifications for new content' => 'Yeni içerik için bildirim al',
  'Security' => 'Güvenlik',
  'Show posts on dashboard' => 'Mesajları göster',
  'This option will hide new content from this space at your dashboard' => 'Bu seçenek, bu mekandaki yeni içeriği kontrol panelinizde gizler.',
  'This option will show new content from this space at your dashboard' => 'Bu seçenek, bu mekandaki yeni içeriği kontrol panelinizde gösterir.',
);
