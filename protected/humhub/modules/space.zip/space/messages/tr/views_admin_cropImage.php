<?php
return array (
  '<strong>Modify</strong> space image' => '<strong>Mekan</strong> resmini değiştir',
  'Close' => 'Kapat',
);
