<?php
return array (
  'As owner you cannot revoke your membership!' => 'Sayfa sahibi olarak siz üyeliğinizi iptal edemezsiniz!',
  'Could not request membership!' => 'Üyelik isteği gerçekleşmedi!',
  'Sorry, you are not allowed to leave this space!' => 'Üzgünüz, bu sayfayı terk etmenize izin verilmiyor.',
  'There is no pending invite!' => 'Bekleyen davet bulunmuyor!',
  'This action is only available for workspace members!' => 'Bu eylemi yalnızca çalışma alanı üyeleri kullanabilir!',
  'This user is already a member of this space.' => 'Bu kullanıcı zaten bu sayfanın üyesi.',
  'This user is not a member of this space.' => 'Bu kullanıcı bu sayfanın üyesi değil.',
  'You are not allowed to join this space!' => 'Bu sayfaya katılmanıza izin verilmiyor!',
);
