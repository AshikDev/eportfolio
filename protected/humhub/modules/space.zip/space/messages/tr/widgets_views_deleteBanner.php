<?php
return array (
  '<strong>Confirm</strong> image deleting' => '<strong>Resmi</strong> Sil',
  'Cancel' => 'İptal',
  'Delete' => 'Sil',
  'Do you really want to delete your title image?' => 'Kapak resmini silmek istiyor musun?',
);
