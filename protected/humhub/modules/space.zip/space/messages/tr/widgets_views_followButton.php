<?php
return array (
  'Follow' => 'Takip et',
  'Unfollow' => 'Takibi Bırak',
);
