<?php
return array (
  '<strong>New</strong> member request' => '<strong>Yeni</strong> üye isteği',
  '<strong>Space</strong> members' => '<strong>Mekan</strong> üyeleri',
  'Show all' => 'Tümünü göster',
);
