<?php
return array (
  'As owner of this space you can transfer this role to another administrator in space.' => 'Bu sayfanın sahibi olarak sayfanızdaki başka bir kullanıcıya yönetici rolünüzü aktarabilirsiniz.',
  'Remove from space' => 'Mekandan kaldır',
  'Show all' => 'Hepsini Göster',
  'Space owner' => 'Mekan sahibi',
  'The url contains illegal characters!' => 'Url geçersiz karakterler içeriyor!',
  'Transfer ownership' => 'Mülkiyet transfer',
  'e.g. example for {baseUrl}/s/example' => 'ör: {baseUrl}/s/örnek',
  'the default start page of this space for members' => 'sayfa üyeleri için gösterilecek varsayılan giriş sayfası',
  'the default start page of this space for visitors' => 'misafirler için gösterilecek varsayılan giriş sayfası',
);
