<?php
return array (
  'Change image' => 'Resmi değiştir',
  'Current space image' => 'Geçerli mekan resmi',
);
