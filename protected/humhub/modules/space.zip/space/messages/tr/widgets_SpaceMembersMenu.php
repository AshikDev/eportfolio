<?php
return array (
  'Members' => 'Üyeler',
  'Owner' => 'Yönetici',
  'Pending Approvals' => 'Bekleyen Onaylar',
  'Pending Invites' => 'Bekleyen Davetler',
);
