<?php
return array (
  '<strong>Security</strong> settings' => '<strong>Güvenlik</strong> ayarları',
  '<strong>Space</strong> settings' => '<strong>Mekan</strong> ayarları',
  'Permissions are assigned to different user-roles. To edit a permission, select the user-role you want to edit and change the drop-down value of the given permission.' => 'İzinler farklı kullanıcı rollerine atanmıştır. Bir izni düzenlemek için, düzenlemek istediğiniz kullanıcı rolünü seçin ve verilen izne uygun değeri değiştirin.',
);
