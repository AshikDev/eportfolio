<?php
return array (
  'Stream (Default)' => 'Yayın (Varsayılan)',
);
