<?php
return array (
  'Friendship' => 'Arkadaşlık',
  'Receive Notifications for Friendship Request and Approval events.' => '',
);
