<?php
return array (
  '<b>This space is still empty!</b>' => '<b>Bu alan halen boş!</b>',
  '<b>This space is still empty!</b><br>Start by posting something here...' => '<b>Bu mekan hala boş!</b><b>Burada bir şey paylaşarak başla...',
  '<b>You are not member of this space and there is no public content, yet!</b>' => '',
);
