<?php
return array (
  'Created At' => 'Oluşturma zamanı',
  'Created By' => 'Oluşturan',
  'Last Visit' => 'Son ziyaret',
  'Originator User ID' => 'Başlatan Kullanıcı ID',
  'Request Message' => 'İstek Mesajı',
  'Status' => 'Durum',
  'Updated At' => 'Güncelleme zamanı',
  'Updated By' => 'Güncelleyen',
);
