<?php
return array (
  'This space is archived' => '',
  'You are a member of this space' => 'Bu mekanın bir üyesisiniz',
  'You are following this space' => '',
);
