<?php
return array (
  'Cancel' => 'İptal',
  'Please shortly introduce yourself, to become a approved member of this workspace.' => 'Bu mekana üye olabilmek için lütfen kısaca kendinizi tanıtın.',
  'Request workspace membership' => 'Mekan üyeliği talebi',
  'Send' => 'Gönder',
);
