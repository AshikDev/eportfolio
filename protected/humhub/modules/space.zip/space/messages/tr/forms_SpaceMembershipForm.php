<?php
return array (
  'Application message' => 'Uygulama mesajı',
);
