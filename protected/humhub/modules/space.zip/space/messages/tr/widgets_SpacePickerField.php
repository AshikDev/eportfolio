<?php
return array (
  'Add Space' => 'Mekan ekle',
  'No spaces found for the given query' => 'Verilen sorgu için mekan bulunamadı',
  'Select {n,plural,=1{space} other{spaces}}' => 'Seçin {n,plural,=1{space} other{spaces}}',
  'This field only allows a maximum of {n,plural,=1{# space} other{# spaces}}' => 'Bu mekan yalnızca maksimum {n,plural,=1{# space} other{# spaces}}',
);
