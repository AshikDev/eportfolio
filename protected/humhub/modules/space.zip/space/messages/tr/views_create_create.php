<?php
return array (
  '<strong>Create</strong> new space' => '<strong>Yeni</strong> mekan oluştur',
  'Advanced access settings' => 'Gelişmiş erişim ayarları ',
  'Next' => 'Devam',
  'Space name' => 'Mekan adı',
  'space description' => 'mekan açıklaması',
);
