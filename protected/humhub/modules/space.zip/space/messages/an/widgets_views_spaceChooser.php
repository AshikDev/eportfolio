<?php
return array (
  'Create new space' => 'Creyar nuevo espacio',
  'My spaces' => 'Espacios',
  'No member or following spaces found.' => 'No s\'han trobau espacios que sigas u que sías miembro.',
  'No result found for the given filter.' => '',
  'Search' => 'Buscar',
  'Search for spaces' => 'Buscar espacios',
  'To search for other spaces, type at least {count} characters.' => 'Pa buscar atros espacios, mete {count} o mas caracters.',
);
