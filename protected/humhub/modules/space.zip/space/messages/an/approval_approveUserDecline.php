<?php
return array (
  'Send & decline' => ' Ninviar y denegar',
);
