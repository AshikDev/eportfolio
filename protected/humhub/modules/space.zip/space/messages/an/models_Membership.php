<?php
return array (
  'Created At' => 'Creyau o',
  'Created By' => 'Creyau per',
  'Last Visit' => 'Zaguera visita',
  'Originator User ID' => '',
  'Request Message' => '',
  'Status' => '',
  'Updated At' => '',
  'Updated By' => '',
);
