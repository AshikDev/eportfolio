<?php
return array (
  'Follow' => 'Seguir',
  'Unfollow' => 'Deixar de seguir',
);
