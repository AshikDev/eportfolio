<?php
return array (
  'Members' => 'Miembros',
  'Owner' => '',
  'Pending Approvals' => '',
  'Pending Invites' => '',
);
