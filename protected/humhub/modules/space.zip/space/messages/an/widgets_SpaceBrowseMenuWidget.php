<?php
return array (
  'My Space List' => 'A mía lista d\'espacios',
  'My space summary' => 'O mío resumen d\'os espacios',
  'Space directory' => 'Directorio d\'espacios',
  'Spaces' => 'Espacios',
);
