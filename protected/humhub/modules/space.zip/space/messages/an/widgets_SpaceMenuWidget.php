<?php
return array (
  '<strong>Space</strong> menu' => '<strong>Menu</strong> d\'o espacio',
  'Stream' => 'Actividatz',
);
