<?php
return array (
  'Author' => 'Julkaisija',
  'Content' => 'Sisältö',
  'Content Type' => 'Sisällön tyyppi',
  'Sorting' => 'Lajittelu',
  'Topic' => 'Aihe',
  'Visibility' => 'Näkyvyys',
);
