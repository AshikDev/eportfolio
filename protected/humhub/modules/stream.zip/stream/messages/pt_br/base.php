<?php
return array (
  'Show {i} more.' => 'Exibir mais {i}.',
);
