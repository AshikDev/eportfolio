<?php
return array (
  'Author' => 'Autor',
  'Content' => 'Conteúdo',
  'Content Type' => 'Tipo de conteúdo',
  'Sorting' => 'Classificação',
  'Topic' => 'Tópico',
  'Visibility' => 'Visibilidade',
);
