<?php
return array (
  'Show {i} more.' => 'Mostrar {i} más.',
);
