<?php
return array (
  'Show {i} more.' => 'Hiển thị thêm {i}.',
);
