<?php
return array (
  'Author' => 'Yazar',
  'Content' => 'İçerik',
  'Content Type' => 'İçerik Türü',
  'Sorting' => 'Sıralama',
  'Topic' => 'Konu',
  'Visibility' => 'Görünürlük',
);
