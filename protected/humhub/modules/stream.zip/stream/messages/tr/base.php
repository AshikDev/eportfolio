<?php
return array (
  'Show {i} more.' => '{i} tane daha göster.',
);
