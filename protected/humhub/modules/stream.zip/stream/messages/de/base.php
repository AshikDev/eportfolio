<?php
return array (
  'Show {i} more.' => 'Zeige {i} weitere.
',
);
