<?php
return array (
  'Author' => 'Autor',
  'Content' => 'Inhalt',
  'Content Type' => 'Inhaltstyp',
  'Sorting' => 'Sortierung',
  'Topic' => 'Thema',
  'Visibility' => 'Sichtbarkeit',
);
