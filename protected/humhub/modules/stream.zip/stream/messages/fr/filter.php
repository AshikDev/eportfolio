<?php
return array (
  'Author' => 'Auteur',
  'Content' => 'Contenu',
  'Content Type' => 'Type de contenu',
  'Sorting' => 'Tri',
  'Topic' => 'Étiquette',
  'Visibility' => 'Visibilité',
);
