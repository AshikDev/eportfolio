<?php
return array (
  'Show {i} more.' => 'Afficher {i} de plus',
);
