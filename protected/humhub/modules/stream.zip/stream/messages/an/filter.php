<?php
return array (
  'Author' => 'Autor',
  'Content' => 'Conteniu',
  'Content Type' => 'Tipo de conteniu',
  'Sorting' => 'Ordenación',
  'Topic' => 'Tema',
  'Visibility' => 'Visibilidat',
);
