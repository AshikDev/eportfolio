<?php
return array (
  'Show {i} more.' => 'Veyer {i} mas.',
);
