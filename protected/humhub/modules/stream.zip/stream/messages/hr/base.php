<?php
return array (
  'Show {i} more.' => 'Prikaži {i} više.',
);
