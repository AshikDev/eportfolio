<?php
return array (
  'Show {i} more.' => 'Zobrazit {i} více.',
);
