<?php
return array (
  'Show {i} more.' => 'Visa {i} fler.',
);
