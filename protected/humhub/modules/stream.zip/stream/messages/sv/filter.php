<?php
return array (
  'Author' => 'Författare',
  'Content' => 'Innehåll',
  'Content Type' => 'Innehållstyp',
  'Sorting' => 'Sortering',
  'Topic' => 'Ämne',
  'Visibility' => 'Synlighet',
);
