<?php
return array (
  'Show {i} more.' => 'Toon {i} meer.',
);
