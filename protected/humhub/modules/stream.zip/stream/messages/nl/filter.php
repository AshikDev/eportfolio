<?php
return array (
  'Author' => 'Auteur',
  'Content' => 'inhoud',
  'Content Type' => 'Inhoudstype',
  'Sorting' => 'Sorteer',
  'Topic' => 'Rubriek',
  'Visibility' => 'Zichtbaarheid',
);
