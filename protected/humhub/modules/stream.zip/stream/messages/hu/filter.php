<?php
return array (
  'Author' => 'Szerző',
  'Content' => 'Tartalom',
  'Content Type' => 'Tartalomtípus',
  'Sorting' => 'Rendezés',
  'Topic' => 'Téma',
  'Visibility' => 'Láthatóság',
);
