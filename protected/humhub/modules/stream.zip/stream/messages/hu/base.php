<?php
return array (
  'Show {i} more.' => 'Több {i} megjelenítése.',
);
