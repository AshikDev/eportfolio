<?php
return array (
  'Author' => 'Autore',
  'Content' => 'Contenuto',
  'Content Type' => 'Tipo di contenuto',
  'Sorting' => 'Ordinamento',
  'Topic' => 'Argomento',
  'Visibility' => 'Visibilità',
);
