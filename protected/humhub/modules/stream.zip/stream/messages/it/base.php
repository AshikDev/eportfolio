<?php
return array (
  'Show {i} more.' => 'Mostra {i} ulteriori.',
);
