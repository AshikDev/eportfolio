<?php
return array (
  'Author' => 'Forfatter',
  'Content' => 'Innhold',
  'Content Type' => 'Innholds type',
  'Sorting' => 'Sortering',
  'Topic' => 'Emne',
  'Visibility' => 'Synlighet',
);
