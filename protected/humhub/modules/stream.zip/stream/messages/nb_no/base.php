<?php
return array (
  'Show {i} more.' => 'Vise {i} mer.',
);
