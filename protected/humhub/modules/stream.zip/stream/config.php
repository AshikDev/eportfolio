<?php

return [
    'id' => 'stream',
    'class' => \humhub\modules\stream\Module::class,
    'isCoreModule' => true,
];
?>