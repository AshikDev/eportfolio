<?php
return array (
  'New message from {senderName}' => 'Nouveau message de {senderName}',
  'and {counter} other users' => 'et de {counter} autres utilisateurs',
);
