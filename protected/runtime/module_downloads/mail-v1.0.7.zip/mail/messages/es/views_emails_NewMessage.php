<?php
return array (
  '<strong>New</strong> message' => '<strong>Nuevo</strong> mensaje',
  'Reply now' => 'Responder ahora',
  'sent you a new message:' => 'te ha enviado un nuevo mensaje: ',
);
