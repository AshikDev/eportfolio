<?php

return [
    'Delete conversation' => '',
    'Leave conversation' => '',
    '<strong>Confirm</strong> deleting conversation' => '<strong>Bekreft</strong> sletting av samtale',
    '<strong>Confirm</strong> leaving conversation' => '<strong>Bekreft</strong> utmelding av samtale',
    '<strong>Confirm</strong> message deletion' => '<strong>Bekreft</strong> sletting av melding',
    'Add user' => 'Legg til bruker',
    'Cancel' => 'Avbryt',
    'Delete' => 'Slett',
    'Do you really want to delete this conversation?' => 'Ønsker du virkelig og slette denne samtalen?',
    'Do you really want to delete this message?' => 'Ønsker du virkelig og slette denne meldingen?',
    'Do you really want to leave this conversation?' => 'Ønsker du virkelig og forlate denne samtalen?',
    'Leave' => 'Forlat',
    'Send' => 'Send',
    'There are no messages yet.' => 'Det er ingen meldinger her enda.',
];
