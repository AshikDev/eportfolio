<?php

return [
    'Add recipients' => 'Dodaj odbiorców',
    'New message' => 'Nowa wiadomość ',
    'Send' => 'Wyślij ',
];
