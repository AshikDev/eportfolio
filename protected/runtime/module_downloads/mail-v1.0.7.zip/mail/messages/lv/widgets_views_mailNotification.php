<?php
return array (
  'Messages' => 'Ziņojumi',
  'New message' => 'Jauna ziņa',
  'Show all messages' => 'Rādīt visas ziņas',
);
