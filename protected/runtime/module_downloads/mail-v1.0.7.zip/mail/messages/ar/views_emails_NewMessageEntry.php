<?php
return array (
  'sent you a new message in' => 'ارسل لك رسالة جديدة في ',
);
