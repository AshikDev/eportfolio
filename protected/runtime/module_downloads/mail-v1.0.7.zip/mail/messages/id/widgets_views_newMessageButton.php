<?php
return array (
  'New message' => '',
  'Send message' => '',
);
