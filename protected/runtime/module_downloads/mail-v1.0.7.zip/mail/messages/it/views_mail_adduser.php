<?php

return [
    'Add more participants to your conversation...' => 'Aggiungi più partecipanti alla tua conversazione...',
];
