<?php

return [
    'Add recipients' => 'اضافه كردن گيرنده',
    'New message' => 'پیغام جدید',
    'Send' => 'ارسال',
];
