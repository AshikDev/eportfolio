<?php
return array (
  'New message' => 'Ny besked',
  'Send message' => 'Send besked',
);
