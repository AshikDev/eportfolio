<?php
return array (
  '<strong>Create</strong> new task' => 'Új feladat <strong>létrehozása</strong>',
  'Assign Users' => 'Felhasználók kijelölése',
  'Cancel' => 'Mégsem',
  'Deadline' => 'Határidő',
  'Save' => 'Mentés',
  'What is to do?' => 'Mik a teendők?',
);
