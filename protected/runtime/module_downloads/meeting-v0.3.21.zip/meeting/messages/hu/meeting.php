<?php
return array (
  'Begin' => 'Kezdés',
  'Can manage meeting content' => 'Kezelni tudom a találkozó tartalmát',
  'Date' => 'Dátum',
  'Duplicate agenda entries' => 'Duplikátum napirendi pontok',
  'End' => 'Vége',
  'Location' => 'Hely',
  'Manage Meetings' => 'Találkozók kezelése',
  'Participants' => 'Résztvevők',
  'Participants (External)' => 'Résztvevők (külsős)',
  'Room' => 'Szoba',
  'Title' => 'Cím',
);
