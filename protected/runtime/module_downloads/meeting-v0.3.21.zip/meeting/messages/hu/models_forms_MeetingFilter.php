<?php
return array (
  'Created by me' => 'Általam létrehozva',
  'Filter meetings' => 'Találkozók szűrése',
  'I\'m participating' => 'Részt veszek',
  'Only past meetings' => 'Csak múltbeli találkozók',
);
