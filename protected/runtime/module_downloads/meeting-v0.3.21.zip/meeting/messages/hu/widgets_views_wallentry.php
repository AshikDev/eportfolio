<?php
return array (
  'Open Meeting' => 'Találkozó megnyitása',
);
