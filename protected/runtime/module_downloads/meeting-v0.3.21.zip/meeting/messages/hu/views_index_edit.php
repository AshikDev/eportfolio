<?php
return array (
  '<strong>Confirm</strong> meeting deletion' => '<strong>Erősítsd meg</strong> a találkozó törlését',
  '<strong>Create</strong> new meeting' => 'Új találkozó <strong>létrehozása</strong>',
  '<strong>Edit</strong> meeting' => 'Új találkozó <strong>szerkesztésel</strong>',
  'Add external participants (free text)' => 'Külsős résztvevők hozzáadása (szabadon választott szöveg)',
  'Add participants' => 'Résztvevők hozzáadása',
  'Do you really want to delete this meeting?' => 'Tényleg törölni akarod ezt a találkozót?',
  'External participants' => 'Külsős résztvevők',
  'Location' => 'Helyszín',
  'Room' => 'Szoba',
  'Title of your meeting' => 'A találkozód címe',
  'hh:mm' => 'óra:perc',
);
