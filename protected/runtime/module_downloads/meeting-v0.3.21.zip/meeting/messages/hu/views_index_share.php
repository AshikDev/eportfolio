<?php
return array (
  '<strong>Share</strong> meeting' => 'Találkozó <strong>megosztása</strong>',
  'Add to your calendar and invite participants' => 'Add hozzá a naptáradhoz és hívj meg résztvevőket',
  'Add to your personal calendar' => 'Add hozzá a személyes naptáradhoz',
  'Export ICS' => 'ICS exportálása',
  'Send notifications to all participants' => 'Értesítés küldése minden résztvevő számára',
  'Send now' => 'Küldés most',
  'Sends internal notifications to all participants of the meeting.' => 'Belsős értesítéseket küld a találkozó valamennyi résztvevőjének.',
  'This will create an ICS file, which adds this meeting only to your private calendar.' => 'Létrehoz egy ICS fájlt, amely ezt a találkozót hozzáadja a személyes naptáradhoz.',
  'This will create an ICS file, which adds this meeting to your personal calendar, invite all other participants by email and waits for their response.' => 'Létrehoz egy ICS fájlt, amely hozzáadja ezt a találkozót a személyes naptáradhoz, minden más résztvevőt meghív emailben, és várja válaszukat.',
);
