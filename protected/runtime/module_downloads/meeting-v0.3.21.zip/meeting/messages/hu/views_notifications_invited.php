<?php
return array (
  '{userName} invited you to {meeting}.' => '{userName} meghívott téged ide: {meeting}.',
);
