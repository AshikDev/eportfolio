<?php
return array (
  'Participants have been notified' => 'A résztvevők értesítve lettek.',
);
