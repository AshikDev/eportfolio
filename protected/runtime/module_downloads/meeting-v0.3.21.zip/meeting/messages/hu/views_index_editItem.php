<?php
return array (
  '<strong>Confirm</strong> entry deletion' => 'Bevitt adat törlésének <strong>megerősítése</strong>',
  '<strong>Create</strong> new entry' => 'Új adatbevitel <strong>létrehozása</strong>',
  '<strong>Edit</strong> entry' => 'Adatbevitel <strong>szerkesztése</strong>',
  'Add external moderators (free text)' => 'Külső moderátorok hozzáadása (szabadon választott szöveg)',
  'Add moderator' => 'Moderátor hozzáadása',
  'Do you really want to delete this entry?' => 'Tényleg törölni akarod a bevitt adatot?',
  'External moderators' => 'Külsős moderátorok',
  'Subject' => 'Téma',
  'Title of this entry' => 'A bevitt adat címe',
);
