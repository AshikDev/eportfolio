<?php
return array (
  '<strong>Edit</strong> Note' => 'Jegyzet <strong>szerkesztése</strong>',
);
