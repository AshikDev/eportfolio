<?php
return array (
  'This task is related to %link%' => 'A feladat ehhez kapcsolódik: %link%',
);
