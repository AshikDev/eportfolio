<?php
return array (
  'Meeting details: %link%' => 'Találkjozó részletei: %link%',
);
