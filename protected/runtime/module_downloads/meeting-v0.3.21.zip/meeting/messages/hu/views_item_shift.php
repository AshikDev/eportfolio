<?php
return array (
  '<strong>Shift</strong> agenda item' => 'Napirendi pont <strong>áthelyezése</strong>',
  'Choose upcoming meeting' => 'Közelgő találkozó kiválasztása',
  'Chose upcoming meeting' => 'Közelgő találkozó kiválasztva',
  'Create new meeting' => 'Új találkozó létrehozása',
);
