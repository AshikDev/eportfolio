<?php
return array (
  'Description' => 'Leírás',
  'Duration (hh:mm)' => 'Időtartam (óra:perc)',
  'Minutes' => 'Jegyzőkönyv',
  'Title' => 'Cím',
);
