<?php
return array (
  'Back to overview' => 'Vissza az áttekkintéshez',
);
