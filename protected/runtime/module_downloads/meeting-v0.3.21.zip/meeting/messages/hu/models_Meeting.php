<?php
return array (
  'End must be after begin' => 'A végének az eleje után kell lennie',
);
