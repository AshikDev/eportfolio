<?php
return array (
  'Back to overview' => 'Tornar a la vista general',
);
