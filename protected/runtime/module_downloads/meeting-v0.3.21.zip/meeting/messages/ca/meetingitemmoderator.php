<?php
return array (
  'Name' => 'Nom',
);
