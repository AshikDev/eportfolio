<?php
return array (
  'Participants have been notified' => 'I partecipanti sono stati avvisati',
);
