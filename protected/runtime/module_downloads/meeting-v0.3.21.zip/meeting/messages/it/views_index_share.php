<?php
return array (
  '<strong>Share</strong> meeting' => '<strong>Condivid</strong> meeting',
  'Add to your calendar and invite participants' => 'Aggiungi al tuo calendario e invita i partecipanti',
  'Add to your personal calendar' => 'Aggiungi al tuo calendario personale',
  'Export ICS' => 'Esporta file ICS',
  'Send notifications to all participants' => 'Invia notifiche a tutti i partecipanti',
  'Send now' => 'Invia ora',
  'Sends internal notifications to all participants of the meeting.' => 'Invia notifiche interne a tutti i partecipanti alla riunione.',
  'This will create an ICS file, which adds this meeting only to your private calendar.' => 'Questo creerà un file ICS, che aggiunge questa riunione solo al tuo calendario personale.',
  'This will create an ICS file, which adds this meeting to your personal calendar, invite all other participants by email and waits for their response.' => 'Questo creerà un file ICS, che aggiunge questo incontro al tuo calendario personale, invita tutti gli altri partecipanti via e-mail e attende la loro risposta.',
);
