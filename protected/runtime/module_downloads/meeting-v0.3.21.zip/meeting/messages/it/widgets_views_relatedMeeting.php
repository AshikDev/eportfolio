<?php
return array (
  'This task is related to %link%' => 'Questa attività è collegata a %link%',
);
