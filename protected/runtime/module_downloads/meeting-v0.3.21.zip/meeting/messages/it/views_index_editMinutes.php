<?php
return array (
  '<strong>Edit</strong> Note' => '<strong>Modifica</strong> Note',
);
