<?php
return array (
  'Begin' => 'Inizio',
  'Can manage meeting content' => 'Può gestire i contenuti dei meeting',
  'Date' => 'Data',
  'Duplicate agenda entries' => 'Duplica ordine del giorno',
  'End' => 'Fine',
  'Location' => 'Luogo',
  'Manage Meetings' => 'Gestisci meeting',
  'Participants' => 'Partecipanti',
  'Participants (External)' => 'Partecipanti (esterni)',
  'Room' => 'Stanza',
  'Title' => 'Titolo',
);
