<?php
return array (
  '<strong>Confirm</strong> meeting deletion' => '<strong>Conferma</strong> eliminazione meeting',
  '<strong>Create</strong> new meeting' => '<strong>Crea</strong> un nuovo meeting',
  '<strong>Edit</strong> meeting' => '<strong>Modifica</strong> meeting',
  'Add external participants (free text)' => 'Aggiungi partecipanti esterni (testo libero)',
  'Add participants' => 'Aggiungi partecipanti',
  'Do you really want to delete this meeting?' => 'Sei sicuro di voler eliminare questo meeting?',
  'External participants' => 'Partecipanti esterni',
  'Location' => 'Luogo',
  'Room' => 'Stanza',
  'Title of your meeting' => 'Titolo del tuo meeting',
  'hh:mm' => 'hh:mm',
);
