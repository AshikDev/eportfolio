<?php
return array (
  '<strong>Create</strong> new task' => '<strong>Crea</strong> nuova attività',
  'Assign Users' => 'Assegna utenti',
  'Cancel' => 'Annulla',
  'Deadline' => 'Scadenza',
  'Save' => 'Salva',
  'What is to do?' => 'Cosa c\'è da fare?',
);
