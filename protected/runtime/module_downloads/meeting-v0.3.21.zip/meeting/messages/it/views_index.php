<?php
return array (
  'Back to overview' => 'Indietro alla panoramica',
);
