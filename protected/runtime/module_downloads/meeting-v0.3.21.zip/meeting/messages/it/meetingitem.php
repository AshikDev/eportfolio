<?php
return array (
  'Description' => 'Descrizione',
  'Duration (hh:mm)' => 'Durata (hh:mm)',
  'Minutes' => 'Minuti',
  'Title' => 'Titolo',
);
