<?php
return array (
  'Open Meeting' => 'Apri meeting',
);
