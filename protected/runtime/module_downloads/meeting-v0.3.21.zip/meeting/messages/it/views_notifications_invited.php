<?php
return array (
  '{userName} invited you to {meeting}.' => '{userName} ti ha invitato a {meeting}.',
);
