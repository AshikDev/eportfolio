<?php
return array (
  '<strong>Confirm</strong> entry deletion' => '<strong>Conferma</strong> eliminazione voce',
  '<strong>Create</strong> new entry' => '<strong>Crea</strong> nuova voce',
  '<strong>Edit</strong> entry' => '<strong>Modifica</strong> voce',
  'Add external moderators (free text)' => 'Aggiungi moderatori esterni (testo libero)',
  'Add moderator' => 'Aggiungi moderatori',
  'Do you really want to delete this entry?' => 'Vuoi veramente cancellare questa voce?',
  'External moderators' => 'Moderatori esterni',
  'Subject' => 'Soggetto',
  'Title of this entry' => 'Titolo di questa voce',
);
