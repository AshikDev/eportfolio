<?php
return array (
  '<strong>Shift</strong> agenda item' => '<strong>Passa</strong> l\'ordine del giorno',
  'Choose upcoming meeting' => 'Scegli il meeting imminente',
  'Chose upcoming meeting' => 'Scegli il meeting imminente',
  'Create new meeting' => 'Crea nuovo meeting',
);
