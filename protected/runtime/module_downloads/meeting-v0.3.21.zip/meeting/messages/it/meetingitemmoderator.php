<?php
return array (
  'Name' => 'Nome',
);
