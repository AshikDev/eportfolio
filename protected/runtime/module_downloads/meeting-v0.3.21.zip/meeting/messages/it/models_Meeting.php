<?php
return array (
  'End must be after begin' => 'La fine deve essere dopo l\'inizio',
);
