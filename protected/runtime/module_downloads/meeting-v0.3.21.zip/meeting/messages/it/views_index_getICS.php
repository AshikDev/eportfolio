<?php
return array (
  'Meeting details: %link%' => 'Dettagli meeting: %link%',
);
