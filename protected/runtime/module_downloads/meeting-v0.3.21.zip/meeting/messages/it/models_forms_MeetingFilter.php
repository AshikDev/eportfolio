<?php
return array (
  'Created by me' => 'Creato da me',
  'Filter meetings' => 'Filtri appuntamenti',
  'I\'m participating' => 'Partecipo',
  'Only past meetings' => 'Solo appuntamenti passati',
);
