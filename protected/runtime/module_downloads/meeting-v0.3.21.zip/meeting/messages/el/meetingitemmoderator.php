<?php
return array (
  'Name' => 'Όνομα',
);
