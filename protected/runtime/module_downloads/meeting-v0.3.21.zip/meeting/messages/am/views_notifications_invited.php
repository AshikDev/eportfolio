<?php

return [
    '{userName} invited you to {meeting}.' => '',
];
