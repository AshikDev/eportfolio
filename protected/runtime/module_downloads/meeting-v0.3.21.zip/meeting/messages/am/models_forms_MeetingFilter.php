<?php

return [
    'Created by me' => '',
    'Filter meetings' => '',
    'I\'m participating' => '',
    'Only past meetings' => '',
];
