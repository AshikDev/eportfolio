<?php

return [
    'End must be after begin' => '',
];
