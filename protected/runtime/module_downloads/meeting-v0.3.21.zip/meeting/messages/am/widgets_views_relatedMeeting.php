<?php

return [
    'This task is related to %link%' => '',
];
