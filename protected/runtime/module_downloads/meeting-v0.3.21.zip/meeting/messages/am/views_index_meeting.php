<?php

return [
    'Participants have been notified' => '',
];
