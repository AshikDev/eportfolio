<?php

return [
    'Meeting details: %link%' => '',
];
