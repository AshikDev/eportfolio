<?php

return [
    'Begin' => '',
    'Can manage meeting content' => '',
    'Date' => '',
    'Duplicate agenda entries' => '',
    'End' => '',
    'Location' => '',
    'Manage Meetings' => '',
    'Participants' => '',
    'Participants (External)' => '',
    'Room' => '',
    'Title' => '',
];
