<?php

return [
    'Description' => '',
    'Duration (hh:mm)' => '',
    'Minutes' => '',
    'Title' => '',
];
