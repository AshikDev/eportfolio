<?php

return [
    '<strong>Confirm</strong> meeting deletion' => '',
    '<strong>Create</strong> new meeting' => '',
    '<strong>Edit</strong> meeting' => '',
    'Add external participants (free text)' => '',
    'Add participants' => '',
    'Do you really want to delete this meeting?' => '',
    'External participants' => '',
    'Location' => '',
    'Room' => '',
    'Title of your meeting' => '',
    'hh:mm' => '',
];
