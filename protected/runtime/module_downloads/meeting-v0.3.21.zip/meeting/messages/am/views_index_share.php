<?php

return [
    '<strong>Share</strong> meeting' => '',
    'Add to your calendar and invite participants' => '',
    'Add to your personal calendar' => '',
    'Export ICS' => '',
    'Send notifications to all participants' => '',
    'Send now' => '',
    'Sends internal notifications to all participants of the meeting.' => '',
    'This will create an ICS file, which adds this meeting only to your private calendar.' => '',
    'This will create an ICS file, which adds this meeting to your personal calendar, invite all other participants by email and waits for their response.' => '',
];
