<?php

return [
    'Open Meeting' => '',
];
