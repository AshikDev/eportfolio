<?php

return [
    '<strong>Create</strong> new task' => '',
    'Assign Users' => '',
    'Cancel' => '',
    'Deadline' => '',
    'Save' => '',
    'What is to do?' => '',
];
