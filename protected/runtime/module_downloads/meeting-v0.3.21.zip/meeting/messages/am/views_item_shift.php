<?php

return [
    '<strong>Shift</strong> agenda item' => '',
    'Choose upcoming meeting' => '',
    'Chose upcoming meeting' => '',
    'Create new meeting' => '',
];
