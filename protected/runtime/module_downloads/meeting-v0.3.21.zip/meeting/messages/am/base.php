<?php

return [
    '<strong>Duplicate</strong> meeting' => '',
    '<strong>Shift</strong> agenda entry to new meeting' => '',
    'Adds a meeting manager to this space.' => '',
    'Agenda Entry' => '',
    'Back to overview' => '',
    'Delete' => '',
    'Duration' => '',
    'Duration in <strong>hh:mm</strong> format ' => '',
    'Edit' => '',
    'Format has to be HOUR : MINUTE' => '',
    'Info message has been sent.' => '',
    'Meeting' => '',
    'Meetings' => '',
    'Move down' => '',
    'Move up' => '',
    'Send as message' => '',
    'Shift to other meeting' => '',
];
