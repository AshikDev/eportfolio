<?php

return [
    '<strong>Confirm</strong> entry deletion' => '',
    '<strong>Create</strong> new entry' => '',
    '<strong>Edit</strong> entry' => '',
    'Add external moderators (free text)' => '',
    'Add moderator' => '',
    'Do you really want to delete this entry?' => '',
    'External moderators' => '',
    'Subject' => '',
    'Title of this entry' => '',
];
