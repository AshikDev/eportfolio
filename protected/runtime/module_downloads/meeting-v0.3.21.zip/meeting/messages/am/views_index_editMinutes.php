<?php

return [
    '<strong>Edit</strong> Note' => '',
];
