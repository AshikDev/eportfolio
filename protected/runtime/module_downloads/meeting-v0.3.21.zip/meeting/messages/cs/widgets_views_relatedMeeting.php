<?php
return array (
  'This task is related to %link%' => 'Tento úkol souvisí s %link%',
);
