<?php
return array (
  'Back to overview' => 'Zpět na přehled',
);
