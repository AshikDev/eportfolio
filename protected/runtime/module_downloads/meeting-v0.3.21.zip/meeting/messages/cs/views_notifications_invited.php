<?php
return array (
  '{userName} invited you to {meeting}.' => 'Uživatel {userName} Vás pozval na schůzku {meeting}.',
);
