<?php
return array (
  'Name' => 'Jméno skupiny',
);
