<?php
return array (
  '<strong>Create</strong> new task' => 'Neue Aufgabe <strong>erstellen</strong>',
  'Assign Users' => 'Benutzer zuordnen',
  'Cancel' => 'Abbrechen',
  'Deadline' => 'Frist',
  'Save' => 'Erstellen',
  'What is to do?' => 'Was ist zu tun?',
);
