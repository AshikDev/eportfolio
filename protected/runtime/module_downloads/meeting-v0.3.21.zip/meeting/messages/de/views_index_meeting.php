<?php
return array (
  'Participants have been notified' => 'Teilnehmer wurden benachrichtigt.',
);
