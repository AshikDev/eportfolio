<?php
return array (
  'Back to overview' => 'Zurück zur Übersicht',
);
