<?php
return array (
  '<strong>Edit</strong> Note' => 'Vermerk <strong>bearbeiten</strong> ',
);
