<?php
return array (
  '{userName} invited you to {meeting}.' => '{userName} hat dich zu {meeting} eingeladen.',
);
