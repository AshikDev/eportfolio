<?php
return array (
  'Open Meeting' => 'Besprechung öffnen',
);
