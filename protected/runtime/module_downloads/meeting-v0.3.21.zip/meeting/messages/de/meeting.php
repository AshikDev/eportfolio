<?php
return array (
  'Begin' => 'Beginn',
  'Can manage meeting content' => 'Kann Besprechungsinhalte verwalten',
  'Date' => 'Datum',
  'Duplicate agenda entries' => 'Agenda-Einträge duplizieren',
  'End' => 'Ende',
  'Location' => 'Ort',
  'Manage Meetings' => 'Besprechungen verwalten',
  'Participants' => 'Teilnehmer',
  'Participants (External)' => 'Teilnehmer (Extern)',
  'Room' => 'Raum',
  'Title' => 'Titel',
);
