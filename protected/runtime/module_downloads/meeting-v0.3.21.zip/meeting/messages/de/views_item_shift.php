<?php
return array (
  '<strong>Shift</strong> agenda item' => 'Agenda-Eintrag <strong>verschieben</strong> ',
  'Choose upcoming meeting' => 'Anstehende Besprechung wählen',
  'Chose upcoming meeting' => 'Anstehende Besprechung wählen',
  'Create new meeting' => 'Neue Besprechung erstellen',
);
