<?php
return array (
  'Description' => 'Beschreibung',
  'Duration (hh:mm)' => 'Dauer (ss:mm)',
  'Minutes' => 'Protokoll',
  'Title' => 'Titel',
);
