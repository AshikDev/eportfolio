<?php
return array (
  '<strong>Confirm</strong> meeting deletion' => 'Löschen der Bespechung <strong> bestätigen</strong>',
  '<strong>Create</strong> new meeting' => 'Neue Besprechung <strong>erstellen</strong> ',
  '<strong>Edit</strong> meeting' => 'Besprechung <strong>bearbeiten</strong> ',
  'Add external participants (free text)' => 'Externe Teilnehmer hinzufügen (Freitext)',
  'Add participants' => 'Teilnehmer hinzufügen',
  'Do you really want to delete this meeting?' => 'Möchtest du diese Besprechung wirklich löschen?',
  'External participants' => 'Externe Teilnehmer',
  'Location' => 'Ort',
  'Room' => 'Raum',
  'Title of your meeting' => 'Titel der Besprechung',
  'hh:mm' => 'hh:mm',
);
