<?php
return array (
  '<strong>Confirm</strong> entry deletion' => 'Eintrag löschen <strong>bestätigen</strong> ',
  '<strong>Create</strong> new entry' => 'Neuen Eintrag <strong>erstellen</strong>',
  '<strong>Edit</strong> entry' => 'Eintrag <strong>bearbeiten</strong> ',
  'Add external moderators (free text)' => 'Externe Moderatoren hinzufügen (Freitext)',
  'Add moderator' => 'Moderator hinzufügen',
  'Do you really want to delete this entry?' => 'Möchtest du diesen Eintrag wirklich löschen?',
  'External moderators' => 'Externe Moderatoren',
  'Subject' => 'Beschreibung',
  'Title of this entry' => 'Titel dieses Eintrags',
);
