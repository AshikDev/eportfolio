<?php
return array (
  '<strong>Share</strong> meeting' => 'Besprechung <strong>teilen</strong> ',
  'Add to your calendar and invite participants' => 'Zum Kalender hinzufügen und Teilnehmer einladen',
  'Add to your personal calendar' => 'Zum persönlichen Kalender hinzufügen',
  'Export ICS' => 'Exportiere ICS',
  'Send notifications to all participants' => 'Benachrichtigungen an alle Teilnehmer senden',
  'Send now' => 'Jetzt senden',
  'Sends internal notifications to all participants of the meeting.' => 'Sendet interne Benachrichtigungen an alle Teilnehmer.',
  'This will create an ICS file, which adds this meeting only to your private calendar.' => 'Erstellt eine ICS-Datei, welche diese Besprechung ausschließlich zu deinem persönlichen Kalender hinzufügt.',
  'This will create an ICS file, which adds this meeting to your personal calendar, invite all other participants by email and waits for their response.' => 'Erstellt eine ICS-Datei, die diese Besprechung deinem persönlichen Kalender hinzufügt, alle anderen Teilnehmer per E-Mail einlädt und auf ihre Antwort wartet.',
);
