<?php
return array (
  'Created by me' => 'Von mir erstellt',
  'Filter meetings' => 'Besprechungen filtern',
  'I\'m participating' => 'Ich nehme teil',
  'Only past meetings' => 'Nur zurückliegende Besprechungen',
);
