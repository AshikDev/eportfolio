<?php
return array (
  'Back to overview' => 'Kembali ke overview',
);
