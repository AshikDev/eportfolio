<?php
return array (
  'Name' => 'Vardas',
);
