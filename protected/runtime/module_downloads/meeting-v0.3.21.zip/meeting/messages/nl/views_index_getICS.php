<?php
return array (
  'Meeting details: %link%' => 'Details van de vergadering: %link%',
);
