<?php
return array (
  'Back to overview' => 'Terug naar het overzicht',
);
