<?php
return array (
  'Description' => 'Omschrijving',
  'Duration (hh:mm)' => 'Duur (uu:mm)',
  'Minutes' => 'Notulen',
  'Title' => 'Titel',
);
