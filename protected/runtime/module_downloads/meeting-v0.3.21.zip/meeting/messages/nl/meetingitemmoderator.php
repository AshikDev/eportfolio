<?php
return array (
  'Name' => 'Naam',
);
