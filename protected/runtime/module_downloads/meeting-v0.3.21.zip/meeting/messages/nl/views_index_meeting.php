<?php
return array (
  'Participants have been notified' => 'Deelnemers zijn in kennis gesteld',
);
