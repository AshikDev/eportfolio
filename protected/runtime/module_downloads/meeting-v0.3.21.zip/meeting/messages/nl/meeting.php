<?php
return array (
  'Begin' => 'Begin',
  'Can manage meeting content' => 'Kan bijeenkomsten beheren',
  'Date' => 'Datum',
  'Duplicate agenda entries' => 'Dupliceer agenda-onderwerpen',
  'End' => 'Einde',
  'Location' => 'Locatie',
  'Manage Meetings' => 'Beheer bijeenkomsten',
  'Participants' => 'Deelnemers',
  'Participants (External)' => 'Deelnemers van buiten',
  'Room' => 'kamer',
  'Title' => 'Titel',
);
