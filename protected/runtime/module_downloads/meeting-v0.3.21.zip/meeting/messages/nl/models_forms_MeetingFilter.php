<?php
return array (
  'Created by me' => 'Gemaakt door mij',
  'Filter meetings' => 'Filter bijeenkomsten',
  'I\'m participating' => 'I neem deel',
  'Only past meetings' => 'Allen bijeenkomsten in het verleden',
);
