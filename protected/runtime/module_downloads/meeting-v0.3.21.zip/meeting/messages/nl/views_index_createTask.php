<?php
return array (
  '<strong>Create</strong> new task' => '<strong>Maak</strong> een nieuwe taak',
  'Assign Users' => 'Gebruikers toewijzen',
  'Cancel' => 'Annuleer',
  'Deadline' => 'Uiterste termijn',
  'Save' => 'Bewaar',
  'What is to do?' => 'Wat gaan we doen?',
);
