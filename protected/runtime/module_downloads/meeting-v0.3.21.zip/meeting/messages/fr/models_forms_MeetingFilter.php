<?php
return array (
  'Created by me' => 'Créées par moi',
  'Filter meetings' => 'Filtrer les réunions',
  'I\'m participating' => 'Je participe',
  'Only past meetings' => 'Seulement les réunions terminées',
);
