<?php
return array (
  '<strong>Create</strong> new task' => '<strong>Créer</strong> une nouvelle tâche',
  'Assign Users' => 'Affecter des utilisateurs',
  'Cancel' => 'Annuler',
  'Deadline' => 'Date limite',
  'Save' => 'Enregistrer',
  'What is to do?' => 'Qu\'est-ce qu\'il y a à faire ?',
);
