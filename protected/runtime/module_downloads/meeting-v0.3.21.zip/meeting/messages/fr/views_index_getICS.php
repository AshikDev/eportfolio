<?php
return array (
  'Meeting details: %link%' => 'Détails de la réunion : %link%',
);
