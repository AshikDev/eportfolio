<?php
return array (
  'Open Meeting' => 'Réunion en cours',
);
