<?php
return array (
  'Participants have been notified' => 'Les participants ont été prévenus',
);
