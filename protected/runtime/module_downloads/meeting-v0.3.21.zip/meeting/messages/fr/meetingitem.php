<?php
return array (
  'Description' => 'Description',
  'Duration (hh:mm)' => 'Durée (hh:mm)',
  'Minutes' => 'Minutes',
  'Title' => 'Titre',
);
