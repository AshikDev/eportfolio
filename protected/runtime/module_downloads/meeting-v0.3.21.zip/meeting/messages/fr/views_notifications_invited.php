<?php
return array (
  '{userName} invited you to {meeting}.' => '{userName} vous a invité à {meeting}.',
);
