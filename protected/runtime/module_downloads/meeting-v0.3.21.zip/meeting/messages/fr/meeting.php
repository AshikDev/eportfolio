<?php
return array (
  'Begin' => 'Début',
  'Can manage meeting content' => 'Peut gérer le contenu de la réunion',
  'Date' => 'Date',
  'Duplicate agenda entries' => 'Dupliquer les événements',
  'End' => 'Fin',
  'Location' => 'Lieu',
  'Manage Meetings' => 'Gérer les réunions',
  'Participants' => 'Participants',
  'Participants (External)' => 'Participants (externes)',
  'Room' => 'Salle',
  'Title' => 'Titre',
);
