<?php
return array (
  'Back to overview' => 'Retour à l\'aperçu',
);
