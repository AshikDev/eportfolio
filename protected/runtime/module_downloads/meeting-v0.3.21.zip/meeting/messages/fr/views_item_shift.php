<?php
return array (
  '<strong>Shift</strong> agenda item' => '<strong>Basculer</strong> l\'événement',
  'Choose upcoming meeting' => 'Choisir une prochaine réunion',
  'Chose upcoming meeting' => 'A choisi une prochaine réunion',
  'Create new meeting' => 'Créer une nouvelle réunion',
);
