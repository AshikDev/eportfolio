<?php
return array (
  'Begin' => '',
  'Description' => '',
  'End' => '',
  'Minutes' => '',
  'Title' => '',
);
