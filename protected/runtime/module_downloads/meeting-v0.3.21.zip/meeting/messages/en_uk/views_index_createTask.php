<?php
return array (
  '<strong>Create</strong> new task' => '',
  'Assign users' => '',
  'Assign users to this task' => '',
  'Cancel' => '',
  'Deadline' => '',
  'Deadline for this task?' => '',
  'Preassign user(s) for this task.' => '',
  'Save' => '',
  'Task description' => '',
  'What is to do?' => '',
);
