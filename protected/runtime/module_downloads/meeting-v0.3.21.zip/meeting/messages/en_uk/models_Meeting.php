<?php
return array (
  'End must be after begin' => '',
  'No valid time' => '',
);
