<?php
return array (
  'Begin' => '',
  'Date' => '',
  'End' => '',
  'Location' => '',
  'Room' => '',
  'Title' => '',
);
