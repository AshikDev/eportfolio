<?php
return array (
  'Meeting details: %link%' => 'Detalji sastanka: %link%',
);
