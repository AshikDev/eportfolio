<?php
return array (
  'End must be after begin' => 'Kraj mora biti nakon početka',
);
