<?php

return [
    'Info message has been sent.' => '',
    'Send as message' => '',
    '<strong>Duplicate</strong> meeting' => '<strong>Kopiraj</strong> sastanak',
    '<strong>Shift</strong> agenda entry to new meeting' => '<strong>Prebaci</strong> unos dnevnog reda na idući sastanak',
    'Adds a meeting manager to this space.' => 'Dodaje koordinatora sastanka ovom prostoru',
    'Agenda Entry' => 'Unos dnevnog reda',
    'Back to overview' => 'Natrag na pregled',
    'Delete' => 'Obriši',
    'Duration' => 'Trajanje',
    'Duration in <strong>hh:mm</strong> format ' => 'Trajanje u <strong>hh:mm</strong> formatu ',
    'Edit' => 'Uredi',
    'Format has to be HOUR : MINUTE' => 'Format mora biti SAT:MINUTA',
    'Meeting' => 'Sastanak',
    'Meetings' => 'Sastanci',
    'Move down' => 'Pomakni dolje',
    'Move up' => 'Pomakni gore',
    'Shift to other meeting' => 'Prebaci na drugi sastanak',
];
