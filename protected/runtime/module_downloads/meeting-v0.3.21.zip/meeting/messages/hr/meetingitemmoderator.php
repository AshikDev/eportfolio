<?php
return array (
  'Name' => 'Ime',
);
