<?php
return array (
  '{userName} invited you to {meeting}.' => '{userName} pozvao vas je {meeting}.',
);
