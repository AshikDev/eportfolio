<?php
return array (
  '<strong>Create</strong> new task' => '<strong>Kreiraj</strong> novi zadatak',
  'Assign Users' => 'Dodijeli korisnike',
  'Cancel' => 'Poništi',
  'Deadline' => 'Krajnji rok',
  'Save' => 'Spremi',
  'What is to do?' => 'Što treba učiniti?',
);
