<?php
return array (
  '<strong>Confirm</strong> entry deletion' => '<strong>Potvrdi</strong> brisanje unosa',
  '<strong>Create</strong> new entry' => '<strong>Kreiraj</strong> novi unos',
  '<strong>Edit</strong> entry' => '<strong>Uredi</strong> unos',
  'Add external moderators (free text)' => 'Dodaj vanjske moderatore (unos teksta)',
  'Add moderator' => 'Dodaj moderatora',
  'Do you really want to delete this entry?' => 'Zaista želite obrisati ovaj unos?',
  'External moderators' => 'Vanjski moderatori',
  'Subject' => 'Predmet',
  'Title of this entry' => 'Naziv ovog unosa',
);
