<?php
return array (
  '<strong>Share</strong> meeting' => '<strong>Dijeli</strong> sastanak',
  'Add to your calendar and invite participants' => 'Dodajte u vaš kalendar i pozovi sudionike',
  'Add to your personal calendar' => 'Dodajte u svoj osobni kalendar',
  'Export ICS' => 'Izvezi ICS',
  'Send notifications to all participants' => 'Pošaljite obavijesti svim sudionicima',
  'Send now' => 'Pošalji sada',
  'Sends internal notifications to all participants of the meeting.' => 'Šalje interne obavijesti svim sudionicima sastanka.',
  'This will create an ICS file, which adds this meeting only to your private calendar.' => 'To će stvoriti ICS datoteku, koja ovaj sastanak dodaje samo vašem privatnom kalendaru.',
  'This will create an ICS file, which adds this meeting to your personal calendar, invite all other participants by email and waits for their response.' => 'Time će se stvoriti ICS datoteka, koja ovaj sastanak dodaje vašem osobnom kalendaru, poziva sve ostale sudionike putem e-pošte i čeka njihov odgovor.',
);
