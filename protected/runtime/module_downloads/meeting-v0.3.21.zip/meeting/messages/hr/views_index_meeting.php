<?php
return array (
  'Participants have been notified' => 'Sudionici su obaviješteni',
);
