<?php
return array (
  'Description' => 'Opis',
  'Duration (hh:mm)' => 'Trajanje (hh:mm)',
  'Minutes' => 'Minuta',
  'Title' => 'Naziv',
);
