<?php
return array (
  'This task is related to %link%' => 'Ovaj zadatak je povezan s %link%',
);
