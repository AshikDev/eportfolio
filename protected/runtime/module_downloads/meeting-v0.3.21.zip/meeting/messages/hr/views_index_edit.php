<?php
return array (
  '<strong>Confirm</strong> meeting deletion' => '<strong>Potvrdi</strong> brisanje sastanka',
  '<strong>Create</strong> new meeting' => '<strong>Kreiraj</strong> novi sastanak',
  '<strong>Edit</strong> meeting' => '<strong>Uredi</strong> sastanak',
  'Add external participants (free text)' => 'Dodaj vanjske sudionike (unos teksta)',
  'Add participants' => 'Dodaj sudionike',
  'Do you really want to delete this meeting?' => 'Zaista želite obrisati ovaj sastanak?',
  'External participants' => 'Vanjski sudionici',
  'Location' => 'Lokacija',
  'Room' => 'Sala',
  'Title of your meeting' => 'Naziv sastanka',
  'hh:mm' => 'hh:mm',
);
