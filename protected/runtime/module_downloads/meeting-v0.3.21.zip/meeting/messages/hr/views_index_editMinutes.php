<?php
return array (
  '<strong>Edit</strong> Note' => '<strong>Uredi</strong> bilješku',
);
