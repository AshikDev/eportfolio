<?php
return array (
  '<strong>Shift</strong> agenda item' => '<strong>Promijeni</strong> stavku dnevnok reda',
  'Choose upcoming meeting' => 'Odaberi nadolazeći sastanak',
  'Chose upcoming meeting' => 'Izaberite nadolazeći sastanak',
  'Create new meeting' => 'Kreirajte novi sastanak',
);
