<?php
return array (
  'Created by me' => 'Kreirano od mene',
  'Filter meetings' => 'Filtriraj sastanke',
  'I\'m participating' => 'Sudjelujem',
  'Only past meetings' => 'Samo prošli sastanci',
);
