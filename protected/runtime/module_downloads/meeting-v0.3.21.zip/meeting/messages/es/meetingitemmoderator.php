<?php
return array (
  'Name' => 'Nombre',
);
