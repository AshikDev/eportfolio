<?php
return array (
  'Back to overview' => 'Regresar a la vista previa',
);
