<?php

return [
    '<strong>Duplicate</strong> meeting' => '',
    '<strong>Shift</strong> agenda entry to new meeting' => '',
    'Back to overview' => '',
    'Delete' => '',
    'Duration' => '',
    'Duration in <strong>hh:mm</strong> format ' => '',
    'Edit' => '',
    'Info message has been sent.' => '',
    'Move down' => '',
    'Move up' => '',
    'Send as message' => '',
    'Shift to other meeting' => '',
    'Adds a meeting manager to this space.' => 'Agrega un gestor de reuniones a este espacio.',
    'Agenda Entry' => 'Entrada a la agenda',
    'Format has to be HOUR : MINUTE' => 'El formato debe ser HORA : MINUTO',
    'Meeting' => 'Reunión',
    'Meetings' => 'Reuniones',
];
