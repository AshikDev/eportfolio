<?php
return array (
  'Name' => 'Navn',
);
