<?php
return array (
  'Name' => '名前',
);
