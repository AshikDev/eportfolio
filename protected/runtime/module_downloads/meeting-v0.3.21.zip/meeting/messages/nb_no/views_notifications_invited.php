<?php
return array (
  '{userName} invited you to {meeting}.' => '{userName} inviterte deg til {meeting}.',
);
