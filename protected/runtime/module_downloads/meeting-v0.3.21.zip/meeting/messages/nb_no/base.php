<?php

return [
    '<strong>Duplicate</strong> meeting' => '',
    '<strong>Shift</strong> agenda entry to new meeting' => '',
    'Back to overview' => '',
    'Delete' => '',
    'Duration' => '',
    'Duration in <strong>hh:mm</strong> format ' => '',
    'Edit' => '',
    'Info message has been sent.' => '',
    'Move down' => '',
    'Move up' => '',
    'Send as message' => '',
    'Shift to other meeting' => '',
    'Adds a meeting manager to this space.' => 'Legger til møtebehandler til denne gruppen.',
    'Agenda Entry' => 'Agenda',
    'Format has to be HOUR : MINUTE' => 'Formatet må være TIME:MINUTT',
    'Meeting' => 'Møte',
    'Meetings' => 'Møter',
];
