<?php
return array (
  'This task is related to %link%' => 'Denne oppgaven er relatert til %link%',
);
