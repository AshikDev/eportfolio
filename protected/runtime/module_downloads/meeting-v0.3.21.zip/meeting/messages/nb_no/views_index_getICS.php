<?php
return array (
  'Meeting details: %link%' => 'Møtedetaljer: %link%',
);
