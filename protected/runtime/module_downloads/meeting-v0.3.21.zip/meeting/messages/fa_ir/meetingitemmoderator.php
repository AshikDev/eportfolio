<?php
return array (
  'Name' => 'نام',
);
