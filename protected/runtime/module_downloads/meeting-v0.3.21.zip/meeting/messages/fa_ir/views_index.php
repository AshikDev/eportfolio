<?php
return array (
  'Back to overview' => 'برگشت به دید کلی',
);
