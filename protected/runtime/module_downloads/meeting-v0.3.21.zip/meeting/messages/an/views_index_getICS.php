<?php
return array (
  'Meeting details: %link%' => '',
);
