<?php
return array (
  'This task is related to %link%' => '',
);
