<?php

return [
    'Hide sidebar' => '',
    'Show sidebar' => '',
];
