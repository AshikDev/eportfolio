<?php
return array (
  'Enterprise Edition <strong>Licence</strong>' => 'Enterprise Edition <strong>Lizenz</strong>',
  'Licence Serial Code' => 'Lizenzschlüssel',
  'Please specify your Enterprise Edition Licence Code below, you can also leave it blank to start a 14 days trial.' => 'Gebe unten deinen Enterpise-Lizenzschlüssel ein. Wenn Du keinen Lizenzschlüssel hinterlegst, beginnt eine 14-tägige Testphase.',
);
