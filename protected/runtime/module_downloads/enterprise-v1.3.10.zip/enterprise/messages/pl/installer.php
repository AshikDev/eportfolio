<?php
return array (
  'Enterprise Edition <strong>Licence</strong>' => '<strong>Licencja</strong> Edycji Enterprise',
  'Licence Serial Code' => 'Numer Seryjny Licencji',
  'Please specify your Enterprise Edition Licence Code below, you can also leave it blank to start a 14 days trial.' => 'Wprowadź proszę Twój klucz licencyjny Edycji Enterprise, możesz także zostawić to pole puste aby rozpocząć 14-dniowy okres próbny.',
);
