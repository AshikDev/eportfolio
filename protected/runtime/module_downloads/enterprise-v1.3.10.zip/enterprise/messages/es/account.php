<?php
return array (
  '<strong>Enterprise Edition</strong> Trial Period' => '<strong>Enterprise Edition</strong> Período de prueba',
  '<strong>Invalid</strong> Enterprise Edition Licence' => '',
  '<strong>Register</strong> Enterprise Edition' => '<strong>Registrar</strong> Enterprise Edition',
  '<strong>Unregistered</strong> Enterprise Edition' => 'Enterprise Edition <strong>sin registrar</strong> ',
  'Enterprise Edition' => 'Enterprise Edition',
  'Please enter your <strong>HumHub - Enterprise Edition</strong> licence key below. If you don\'t have a licence key yet, you can obtain one at %link%.' => '',
  'Please register this <strong>HumHub - Enterprise Edition</strong>!' => '',
  'Please update this <strong>HumHub - Enterprise Edition</strong> licence!' => '',
  'Registration successful!' => '¡Registro exitoso!',
  'Validating...' => 'Validando...',
  'You have <strong>{daysLeft}</strong> days left in your trial period.' => '',
);
