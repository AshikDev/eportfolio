<?php
return array (
  'A whitelist rule can either be in the form <strong>@example.com</strong> to allow each email of the given host or a complete address as <strong>user@example.com</strong>' => 'En hvitlist regel kan enten være i form <strong> @ example.com </ strong> for å tillate hver e-post til en gitt vert eller et komplett adresse som <strong> user@example.com </ strong>',
  'Separate multiple rules by a new line.' => 'Del opp flere regler med en ny linje.',
  'Separate multiple whitelist rules by a new line.' => 'Del opp flere regler for hvitlisting med en ny linje.',
);
