<?php
return array (
  'A whitelist rule can either be in the form <strong>@example.com</strong> to allow each email of the given host or a complete address as <strong>user@example.com</strong>' => '',
  'Separate multiple rules by a new line.' => 'Separate multiple rules by a new line.',
  'Separate multiple whitelist rules by a new line.' => '',
);
