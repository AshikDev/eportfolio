<?php
return array (
  'A whitelist rule can either be in the form <strong>@example.com</strong> to allow each email of the given host or a complete address as <strong>user@example.com</strong>' => 'Una regola whitelisti deve essere nel formato <strong>@example.com</strong> per permettere all\'host di completare l\'email con il nome utente es. <strong>user@example.com</strong>',
  'Separate multiple rules by a new line.' => 'Separa più regole andando a capo.',
  'Separate multiple whitelist rules by a new line.' => 'Separa più regole whitelist andando a capo.',
);
