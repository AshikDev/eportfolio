<?php
return array (
  'Enterprise Edition <strong>Licence</strong>' => '<strong>Licenza</strong> Enterprise Edition',
  'Licence Serial Code' => 'Codice seriale licenza',
  'Please specify your Enterprise Edition Licence Code below, you can also leave it blank to start a 14 days trial.' => 'Prego inserisci il codice seriale licenza qui sotto, lasciando in bianco inizierai il periodo di valutazione di 14 giorni.',
);
