<?php
return array (
  'Hide sidebar' => 'Nascondi la barra laterale',
  'Show sidebar' => 'Mostra la barra laterale',
);
