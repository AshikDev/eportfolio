<?php
return array (
  '<strong>Enterprise Edition</strong> Trial Period' => 'Période d\'essai <strong>Edition Enterprise</strong>',
  '<strong>Invalid</strong> Enterprise Edition Licence' => 'Licence Edition Enterprise <strong>invalide</strong>',
  '<strong>Register</strong> Enterprise Edition' => '<strong>Enregister</strong> votre Edition Enterprise',
  '<strong>Unregistered</strong> Enterprise Edition' => 'Edition Enterprise <strong>non enregistrée</strong>',
  'Enterprise Edition' => 'Edition Enterprise',
  'Please enter your <strong>HumHub - Enterprise Edition</strong> licence key below. If you don\'t have a licence key yet, you can obtain one at %link%.' => 'Merci de saisir ci-dessous votre clé de licence <strong>HumHub - Edition Enterprise</strong>. Si vous n\'avez pas encore de clé de licence, vous pouvez en obtenir une sur %link%.',
  'Please register this <strong>HumHub - Enterprise Edition</strong>!' => 'Merci d\'enregistrer votre version de <strong>HumHub - Enterprise Edition</strong> !',
  'Please update this <strong>HumHub - Enterprise Edition</strong> licence!' => 'Merci de mettre à jour cette licence de <strong>HumHub - Enterprise Edition</strong> !',
  'Registration successful!' => 'Enregistrement réussi !',
  'Validating...' => 'En cours de validation',
  'You have <strong>{daysLeft}</strong> days left in your trial period.' => 'Vous avez encore <strong>{daysLeft}</strong> jours de période d\'essai.',
);
