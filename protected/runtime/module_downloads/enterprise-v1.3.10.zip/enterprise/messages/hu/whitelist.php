<?php
return array (
  'A whitelist rule can either be in the form <strong>@example.com</strong> to allow each email of the given host or a complete address as <strong>user@example.com</strong>' => 'Az engedélyezési listára vonatkozó szabály lehet <strong>@example.com</strong> formátumban, hogy az adott hoszt minden emailjét engedélyezze, vagy lehet teljes cím, úgymint <strong>user@example.com</strong>',
  'Separate multiple rules by a new line.' => 'Ha több szabály van, válassza el őket egy sorral.',
  'Separate multiple whitelist rules by a new line.' => 'Több engedélyezési lista szabályt új sorral különítsen el.',
);
