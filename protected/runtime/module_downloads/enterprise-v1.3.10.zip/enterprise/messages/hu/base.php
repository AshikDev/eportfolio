<?php
return array (
  'Hide sidebar' => 'Oldalsáv elrejtése',
  'Show sidebar' => 'Oldalsáv mutatása',
);
