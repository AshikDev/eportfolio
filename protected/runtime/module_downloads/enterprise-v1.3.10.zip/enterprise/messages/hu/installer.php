<?php
return array (
  'Enterprise Edition <strong>Licence</strong>' => 'Céges kiadás <strong>licensz</strong>',
  'Licence Serial Code' => 'Licensz kódja',
  'Please specify your Enterprise Edition Licence Code below, you can also leave it blank to start a 14 days trial.' => 'Kérjük, add meg a céges kiadás verzióját alább - üresen is hagyhatod, ezzel egy 14 napos próbaiadőszak kezdődik.',
);
