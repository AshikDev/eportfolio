<?php

use yii\helpers\Html;
use yii\bootstrap\ActiveForm;
?>
<div class="panel panel-success">
    <div class="panel-heading"><?php echo Yii::t('EnterpriseModule.account', '<strong>Register</strong> Enterprise Edition'); ?></div>
    <div class="panel-body">
        <?php echo Yii::t('EnterpriseModule.account', 'Registration successful!'); ?>
    </div>
</div>
