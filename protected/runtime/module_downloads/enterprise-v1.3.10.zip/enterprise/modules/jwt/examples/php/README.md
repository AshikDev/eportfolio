## HumHub - PHP

A JWT implementation in PHP based on PHP-JWT (https://github.com/firebase/php-jwt)

### Installation

1. Place this script in your htdocs folder
2. Change configuration in file index.php

Please note that the ISS does not have to be in the DMZ or in any way accessible via the internet, as the authentication is driven via browser redirects.


### License

3-Clause BSD.