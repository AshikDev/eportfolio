<?php
/*$config = require(dirname(__DIR__) . '/../../../../tests/codeception/config/acceptance.php');
new humhub\components\Application($config);*/
