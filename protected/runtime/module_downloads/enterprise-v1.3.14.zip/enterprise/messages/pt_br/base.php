<?php
return array (
  'Hide sidebar' => 'Esconder menu lateral',
  'Show sidebar' => 'Exibir menu lateral',
);
