<?php
return array (
  'A whitelist rule can either be in the form <strong>@example.com</strong> to allow each email of the given host or a complete address as <strong>user@example.com</strong>' => 'Uma regra de lista brancs pode estar no formato <strong>@example.com</strong> para permitir que cada e-mail do host especificado ou um endereço completo como <strong>user@example.com</strong>',
  'Separate multiple rules by a new line.' => 'Separe várias regras por uma nova linha.',
  'Separate multiple whitelist rules by a new line.' => 'Separe várias regras da lista de permissões por uma nova linha.',
);
