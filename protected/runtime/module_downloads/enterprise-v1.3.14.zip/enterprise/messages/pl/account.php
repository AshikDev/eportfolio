<?php
return array (
  '<strong>Enterprise Edition</strong> Trial Period' => '<strong>Edycja Enterprise</strong> Okres Testowy',
  '<strong>Invalid</strong> Enterprise Edition Licence' => '<strong>Niepoprawna</strong> Licencja Edycji Enterprise',
  '<strong>Register</strong> Enterprise Edition' => '<strong>Zarejestruj</strong> Edycję Enterprise',
  '<strong>Unregistered</strong> Enterprise Edition' => '<strong>Niezarejestrowana</strong> Edycja Enterprise',
  'Enterprise Edition' => 'Edycja Enterprise',
  'Please enter your <strong>HumHub - Enterprise Edition</strong> licence key below. If you don\'t have a licence key yet, you can obtain one at %link%.' => 'Wprowadź proszę poniżej Twój klucz licencyjny dla <strong>HumHub - Edycja Enterprise</strong>. Jeśli nie masz klucza licencyjnego, możesz go uzyskać pod adresem %link%.',
  'Please register this <strong>HumHub - Enterprise Edition</strong>!' => 'Proszę, zarejestruj <strong>HumHub - Edycja Enterprise</strong>!',
  'Please update this <strong>HumHub - Enterprise Edition</strong> licence!' => 'Proszę, uaktualnij licencję dla <strong>HumHub - Edycja Enterprise</strong>!',
  'Registration successful!' => 'Rejstracja zakończona powodzeniem!',
  'Validating...' => 'Waliduję...',
  'You have <strong>{daysLeft}</strong> days left in your trial period.' => 'Pozostało <strong>{daysLeft}</strong> dni do końca okresu testowego.',
);
