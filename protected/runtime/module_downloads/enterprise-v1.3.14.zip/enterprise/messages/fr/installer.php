<?php
return array (
  'Enterprise Edition <strong>Licence</strong>' => 'Licence <strong>Edition Enterprise</strong>',
  'Licence Serial Code' => 'Code série de la licence',
  'Please specify your Enterprise Edition Licence Code below, you can also leave it blank to start a 14 days trial.' => 'Précisez ci-dessous le code de votre licence Edition Entreprise. Vous pouvez également laisser cette information en blanc pour démarrer votre période d\'essai de 14 jours.',
);
