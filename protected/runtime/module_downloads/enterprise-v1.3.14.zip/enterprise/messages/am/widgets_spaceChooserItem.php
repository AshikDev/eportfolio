<?php

return [
    'Your are not a member of this space' => '',
];
