<?php

return [
    '<strong>Create</strong> new ldap mapping' => '',
    '<strong>Edit</strong> ldap mapping' => '',
    '<strong>LDAP</strong> member mapping' => '',
    'Assign LDAP users which becomes automatically member of this group.' => '',
    'Assign LDAP users which becomes automatically member of this space.' => '',
    'Attribute value (e.g. street==Some Street <i>or</i> street=~Street)' => '',
    'Back to overview' => '',
    'Create new mapping' => '',
    'Group' => '',
    'ID' => '',
    'LDAP' => '',
    'LDAP Mapping' => '',
    'Mapping options:' => '',
    'Note: This option is only available for global user administrators.' => '',
    'Part of the users base DN (e.g. OU=People,DC=example,DC=com)' => '',
    'Space ID' => '',
    'User Memberships (MemberOf, e.g. CN=xyz_space_access,OU=Groups,DC=example,DC=com)' => '',
];
