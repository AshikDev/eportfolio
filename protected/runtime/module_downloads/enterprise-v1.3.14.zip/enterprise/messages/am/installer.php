<?php

return [
    'Enterprise Edition <strong>Licence</strong>' => '',
    'Licence Serial Code' => '',
    'Please specify your Enterprise Edition Licence Code below, you can also leave it blank to start a 14 days trial.' => '',
];
