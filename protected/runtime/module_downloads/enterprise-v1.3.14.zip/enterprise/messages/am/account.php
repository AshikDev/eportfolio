<?php

return [
    '<strong>Enterprise Edition</strong> Trial Period' => '',
    '<strong>Invalid</strong> Enterprise Edition Licence' => '',
    '<strong>Register</strong> Enterprise Edition' => '',
    '<strong>Unregistered</strong> Enterprise Edition' => '',
    'Enterprise Edition' => '',
    'Please enter your <strong>HumHub - Enterprise Edition</strong> licence key below. If you don\'t have a licence key yet, you can obtain one at %link%.' => '',
    'Please register this <strong>HumHub - Enterprise Edition</strong>!' => '',
    'Please update this <strong>HumHub - Enterprise Edition</strong> licence!' => '',
    'Registration successful!' => '',
    'Validating...' => '',
    'You have <strong>{daysLeft}</strong> days left in your trial period.' => '',
];
