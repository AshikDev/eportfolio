<?php

return [
    '<strong>Change</strong> space image' => '',
    '<strong>Change</strong> type' => '',
    '<strong>Create</strong> new %typeTitle%' => '',
    '<strong>Create</strong> new space type' => '',
    '<strong>Delete</strong> space type' => '',
    '<strong>Edit</strong> space type' => '',
    'Create new type' => '',
    'Crop image' => '',
    'Current image' => '',
    'Delete image' => '',
    'Here you can manage your space types, which can be used to categorize your spaces.' => '',
    'Image' => '',
    'Space Types' => '',
    'To delete the space type <strong>"{type}"</strong> you need to set an alternative type for existing spaces:' => '',
    'Type' => '',
    'Types' => '',
    'Upload image' => '',
    'e.g. Project' => '',
    'e.g. Projects' => '',
];
