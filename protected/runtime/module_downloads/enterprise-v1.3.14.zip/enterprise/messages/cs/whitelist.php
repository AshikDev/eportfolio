<?php
return array (
  'A whitelist rule can either be in the form <strong>@example.com</strong> to allow each email of the given host or a complete address as <strong>user@example.com</strong>' => 'Pravidlo pro bílou listinu může mít buď formu <strong> @ example.com </ strong>, aby povolil každý e-mail daného hostitele nebo úplnou adresu jako <strong> user@example.com </ strong>',
  'Separate multiple rules by a new line.' => 'Oddělte více pravidel novým řádkem.',
  'Separate multiple whitelist rules by a new line.' => 'Oddělte několik pravidel whitelistů novým řádkem.',
);
