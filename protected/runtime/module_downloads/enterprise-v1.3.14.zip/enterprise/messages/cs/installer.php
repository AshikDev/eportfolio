<?php
return array (
  'Enterprise Edition <strong>Licence</strong>' => '<strong> Licence </strong>Pro podniky',
  'Licence Serial Code' => 'Seriové číslo',
  'Please specify your Enterprise Edition Licence Code below, you can also leave it blank to start a 14 days trial.' => 'Zadejte prosím níže uvedený licenční kód verze Pro podniky, můžete také nechat prázdné, abyste mohli začít 14denní zkušební dobu.',
);
