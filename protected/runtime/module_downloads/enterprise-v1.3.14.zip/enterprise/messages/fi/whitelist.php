<?php
return array (
  'A whitelist rule can either be in the form <strong>@example.com</strong> to allow each email of the given host or a complete address as <strong>user@example.com</strong>' => 'Sallituiden osoitteiden muoto voi olla joko <strong>@esimerkki.fi</strong>, jotta tietyn isännän tai täydellisen osoitteen jokainen sähköpostiosoite on <strong>käyttäjä@esimerkki.fi</strong>',
  'Separate multiple rules by a new line.' => 'Erota useita sääntöjä uudella rivillä.',
  'Separate multiple whitelist rules by a new line.' => 'Erota sallituiden osoitteidenlistan säännöt uudella rivillä.',
);
