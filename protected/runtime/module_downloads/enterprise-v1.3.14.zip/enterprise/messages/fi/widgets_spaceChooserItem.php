<?php
return array (
  'Your are not a member of this space' => 'Et ole tämän sivun jäsen',
);
