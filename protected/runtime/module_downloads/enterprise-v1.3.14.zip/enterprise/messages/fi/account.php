<?php
return array (
  '<strong>Enterprise Edition</strong> Trial Period' => '<strong>Enterprise Edition</strong> kokeilujakso',
  '<strong>Invalid</strong> Enterprise Edition Licence' => '<strong>Virheellinen</strong> Enterprise Edition -lisenssi',
  '<strong>Register</strong> Enterprise Edition' => '<strong>Rekisteröi</strong> Enterprise Edition',
  '<strong>Unregistered</strong> Enterprise Edition' => '<strong> Rekisteröimätön</strong> Enterprise Edition',
  'Enterprise Edition' => 'Enterprise Edition',
  'Please enter your <strong>HumHub - Enterprise Edition</strong> licence key below. If you don\'t have a licence key yet, you can obtain one at %link%.' => 'Anna <strong>HumHub - Enterprise Edition</strong> -lisenssiavain alla. Jos sinulla ei vielä ole lisenssiavainta, voit hankkia sen osoitteesta %link%.',
  'Please register this <strong>HumHub - Enterprise Edition</strong>!' => 'Rekisteröi <strong>HumHub - Enterprise Edition</strong>!',
  'Please update this <strong>HumHub - Enterprise Edition</strong> licence!' => 'Päivitä <strong>HumHub - Enterprise Edition</strong> -lisenssi!',
  'Registration successful!' => 'Rekisteröinti onnistui!',
  'Validating...' => 'Vahvistetaan ...',
  'You have <strong>{daysLeft}</strong> days left in your trial period.' => 'Sinulla on <strong>{daysLeft}</strong> päivää jäljellä kokeilujaksoasi.',
);
