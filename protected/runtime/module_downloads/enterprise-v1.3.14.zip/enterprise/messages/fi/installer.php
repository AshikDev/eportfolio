<?php
return array (
  'Enterprise Edition <strong>Licence</strong>' => 'Enterprise Edition <strong>Lisenssi</strong>',
  'Licence Serial Code' => 'Lisenssin koodi',
  'Please specify your Enterprise Edition Licence Code below, you can also leave it blank to start a 14 days trial.' => 'Määritä Enterprise Edition -lisenssikoodi alla, voit myös jättää sen tyhjäksi 14 päivän kokeilun aloittamiseksi.',
);
