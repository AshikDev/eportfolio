<?php
return array (
  'Hide sidebar' => 'Piilota sivupalkki',
  'Show sidebar' => 'Näytä sivupalkki',
);
