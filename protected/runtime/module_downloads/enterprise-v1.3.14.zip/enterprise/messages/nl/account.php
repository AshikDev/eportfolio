<?php
return array (
  '<strong>Enterprise Edition</strong> Trial Period' => '<strong>Enterprise Edition</strong> Proefperiode',
  '<strong>Invalid</strong> Enterprise Edition Licence' => '<strong>Ongeldige</strong> Enterprise Edition Licentie',
  '<strong>Register</strong> Enterprise Edition' => '<strong>Registreer</strong> de  Enterprise Edition',
  '<strong>Unregistered</strong> Enterprise Edition' => '<strong>Unregistreerde</strong> Enterprise Edition',
  'Enterprise Edition' => 'Enterprise Edition',
  'Please enter your <strong>HumHub - Enterprise Edition</strong> licence key below. If you don\'t have a licence key yet, you can obtain one at %link%.' => 'Voer alstublieft uw <strong> HumHub - Enterprise Edition</ strong> licentiesleutel in. Als u nog geen licentiesleutel hebt, kunt u een bij %link% verkrijgen.',
  'Please register this <strong>HumHub - Enterprise Edition</strong>!' => 'Registreer deze<strong>HumHub - Enterprise Edition</strong>!',
  'Please update this <strong>HumHub - Enterprise Edition</strong> licence!' => 'Vernieuw deze <strong>HumHub - Enterprise Edition</strong> licentie!',
  'Registration successful!' => 'Registratie is gelukt!',
  'Validating...' => 'Valideren ...
',
  'You have <strong>{daysLeft}</strong> days left in your trial period.' => 'U heeft <strong>{daysLeft}</strong> dagen over in uw proefperiode.',
);
