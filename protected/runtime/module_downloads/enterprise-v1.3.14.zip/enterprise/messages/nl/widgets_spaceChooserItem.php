<?php
return array (
  'Your are not a member of this space' => 'U bent niet lid van deze ruimte.',
);
