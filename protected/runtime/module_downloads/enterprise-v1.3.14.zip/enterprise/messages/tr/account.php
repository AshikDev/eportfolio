<?php
return array (
  '<strong>Enterprise Edition</strong> Trial Period' => 'Kurumsal Sürüm Deneme Süresi',
  '<strong>Invalid</strong> Enterprise Edition Licence' => 'Geçersiz Kurumsal Sürüm Lisansı',
  '<strong>Register</strong> Enterprise Edition' => 'Kurumsal Sürüm Kayıt',
  '<strong>Unregistered</strong> Enterprise Edition' => 'Kayıtsız Kurumsal Sürüm',
  'Enterprise Edition' => 'Kurumsal Sürüm',
  'Please enter your <strong>HumHub - Enterprise Edition</strong> licence key below. If you don\'t have a licence key yet, you can obtain one at %link%.' => '',
  'Please register this <strong>HumHub - Enterprise Edition</strong>!' => '',
  'Please update this <strong>HumHub - Enterprise Edition</strong> licence!' => '',
  'Registration successful!' => 'Kayıt başarılı!',
  'Validating...' => 'Doğrulanıyor...',
  'You have <strong>{daysLeft}</strong> days left in your trial period.' => '',
);
