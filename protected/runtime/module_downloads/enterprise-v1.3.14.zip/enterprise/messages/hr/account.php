<?php
return array (
  '<strong>Enterprise Edition</strong> Trial Period' => '<strong>Poduzetničko izdanje</ strong> probno razdoblje',
  '<strong>Invalid</strong> Enterprise Edition Licence' => '<strong>Nevažeća</strong> licenca Poduzetničkog izdanja',
  '<strong>Register</strong> Enterprise Edition' => '<strong>Registriraj</strong> Poduzetničko izdanje',
  '<strong>Unregistered</strong> Enterprise Edition' => '<strong>Neregistrirano</strong> Poduzetničko izdanje',
  'Enterprise Edition' => 'Poduzetničko izdanje',
  'Please enter your <strong>HumHub - Enterprise Edition</strong> licence key below. If you don\'t have a licence key yet, you can obtain one at %link%.' => 'Molimo unesite licencni ključ <strong>HumHub - Poduzetničko izdanje</strong> . Ako još nemate licencni ključ možete ga nabaviti na  %link%.',
  'Please register this <strong>HumHub - Enterprise Edition</strong>!' => 'Molimo registrirajte <strong>HumHub - Poduzetničko izdanje</strong>!',
  'Please update this <strong>HumHub - Enterprise Edition</strong> licence!' => 'Molimo ažurirajte licencu <strong>HumHub - Poduzetničko izdanje</strong>! ',
  'Registration successful!' => 'Registracija uspješna!',
  'Validating...' => 'Potvrđujem...',
  'You have <strong>{daysLeft}</strong> days left in your trial period.' => 'Imate <strong>{daysLeft}</strong> preostalo dana probnog perioda.',
);
