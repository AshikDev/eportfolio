<?php
return array (
  'Your are not a member of this space' => 'Non sei membro di questo spazio',
);
