<?php
return array (
  '<strong>Enterprise Edition</strong> Trial Period' => '<strong>Vállalati kiadás</strong> próbaidőszak',
  '<strong>Invalid</strong> Enterprise Edition Licence' => '<strong>Érvénytelen</strong> Vállalati kiadás licenckód',
  '<strong>Register</strong> Enterprise Edition' => 'Vállalati kiadás <strong>regisztráció</strong>',
  '<strong>Unregistered</strong> Enterprise Edition' => '<strong>Nem regisztrált</strong> Vállalati kiadás',
  'Enterprise Edition' => 'Vállalati kiadás',
  'Please enter your <strong>HumHub - Enterprise Edition</strong> licence key below. If you don\'t have a licence key yet, you can obtain one at %link%.' => 'Kérjük, alább add meg termékkulcsodat az alábbi <strong>HumHub - Vállalati kiadás</strong>-hoz. Ha még nem rendelkezel termékkulccsal, a %link%-en igényelhetsz egyet.',
  'Please register this <strong>HumHub - Enterprise Edition</strong>!' => 'Kérjük, regisztráld ezt a <strong>HumHub - Vállalati kiadás</strong>-t!',
  'Please update this <strong>HumHub - Enterprise Edition</strong> licence!' => 'Kérjük, frissítsd ezt a <strong>HumHub - Vállalati kiadás</strong> licencet!',
  'Registration successful!' => 'Sikeres regisztráció!',
  'Validating...' => 'Ellenőrzés...',
  'You have <strong>{daysLeft}</strong> days left in your trial period.' => 'A próbaidőszakból <strong>{daysLeft}</strong> nap maradt.',
);
