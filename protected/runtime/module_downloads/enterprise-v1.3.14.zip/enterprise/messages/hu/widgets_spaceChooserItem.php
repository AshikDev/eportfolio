<?php
return array (
  'Your are not a member of this space' => 'Nem vagy tagja ennek a közösségnek.',
);
