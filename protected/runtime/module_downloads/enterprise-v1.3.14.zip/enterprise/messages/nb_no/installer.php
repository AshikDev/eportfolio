<?php
return array (
  'Enterprise Edition <strong>Licence</strong>' => 'Enterprise Edition <strong>Lisens</strong>',
  'Licence Serial Code' => 'Lisens nøkkel',
  'Please specify your Enterprise Edition Licence Code below, you can also leave it blank to start a 14 days trial.' => 'Vennligst skriv inn din Enterprise Edition lisenskode nedenfor. Lar du den stå tom starter du en 14 prøveperiode.',
);
