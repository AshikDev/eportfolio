<?php
return array (
  'A whitelist rule can either be in the form <strong>@example.com</strong> to allow each email of the given host or a complete address as <strong>user@example.com</strong>' => 'Eine Whitelist-Regel kann entweder mit der Form <strong>@example.com</strong> jede E-Mail des angegebenen Hosts, oder mittels <strong>user@example.com</strong> nur eine vollständige Adresse zulassen',
  'Separate multiple rules by a new line.' => 'Mehrere Regeln durch eine neue Zeile trennen.',
  'Separate multiple whitelist rules by a new line.' => 'Mehrere Whitelist-Regeln durch eine neue Zeile trennen.',
);
