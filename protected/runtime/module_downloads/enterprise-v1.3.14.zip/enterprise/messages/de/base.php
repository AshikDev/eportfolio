<?php
return array (
  'Hide sidebar' => 'Seitenleiste verbergen',
  'Show sidebar' => 'Seitenleiste anzeigen',
);
