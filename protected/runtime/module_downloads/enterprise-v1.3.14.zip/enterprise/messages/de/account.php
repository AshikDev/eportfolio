<?php
return array (
  '<strong>Enterprise Edition</strong> Trial Period' => '<strong>Enterprise Edition</strong> Testzeitraum',
  '<strong>Invalid</strong> Enterprise Edition Licence' => '<strong>Ungültige</strong> Enterprise Lizenz',
  '<strong>Register</strong> Enterprise Edition' => '<strong>Registrierung</strong> Enterprise Edition',
  '<strong>Unregistered</strong> Enterprise Edition' => '<strong>Unregistrierte</strong> Enterprise Edition',
  'Enterprise Edition' => 'Enterprise Edition',
  'Please enter your <strong>HumHub - Enterprise Edition</strong> licence key below. If you don\'t have a licence key yet, you can obtain one at %link%.' => 'Bitte gebe hier deinen <strong>HumHub - Enterprise Edition</strong>-Lizenzschlüssel ein. Solltest du noch keinen Lizenzschlüssel besitzen, kannst du unter %link% einen erwerben.',
  'Please register this <strong>HumHub - Enterprise Edition</strong>!' => 'Bitte registriere deine <strong>HumHub - Enterprise Edition</strong>!',
  'Please update this <strong>HumHub - Enterprise Edition</strong> licence!' => 'Bitte aktualisiere deine <strong>HumHub - Enterprise Edition</strong> Lizenz!',
  'Registration successful!' => 'Die Registrierung war erfolgreich!',
  'Validating...' => 'Überprüfe...',
  'You have <strong>{daysLeft}</strong> days left in your trial period.' => 'Noch <strong>{daysLeft}</strong> Tage bis zum Ablauf des Testzeitraums.',
);
