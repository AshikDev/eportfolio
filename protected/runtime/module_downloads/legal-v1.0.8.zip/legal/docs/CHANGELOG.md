Changelog
=========

1.0.8  (July 10, 2018)
-----------------------
- Fix: Added max-height for cookie content + button white space wrap

1.0.7  (July 10, 2018)
-----------------------
- Fix: LDAP Sync issues


1.0.6  (July 5, 2018)
-----------------------
- Fix: LDAP Sync issues


1.0.5  (June 5, 2018)
-----------------------
- Fix: Swapped registration check labels


1.0.4  (May 23, 2018)
-----------------------
- Enh: Added module screenshots


1.0.2  (May 15, 2018)
-----------------------
- Fix: Removed debug statement


1.0.1  (May 15, 2018)
-----------------------
- Fix: Event methods not method call


1.0.0  (May 15, 2018)
-----------------------
- Enh: Initial release

