HumHub - Auto Patch
===================

Automatically fetches patches (bugfixes for critical bugs) which can be installed in the administration section without the need of a complete HumHub version update.

