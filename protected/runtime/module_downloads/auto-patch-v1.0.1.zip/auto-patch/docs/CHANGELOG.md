Changelog
=========

1.0.1  (October 24, 2018)
---------------------
- Fix: Text fixes


1.0.0  (October 24, 2018)
---------------------
Initial release
