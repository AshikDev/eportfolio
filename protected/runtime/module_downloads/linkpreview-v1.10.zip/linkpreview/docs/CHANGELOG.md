Changelog
=========
1.10 - 20 August 2018
-----------------------
- Fix: Restrict linkpreview to post and comments.

1.9 - 17 January 2018
-----------------------
- v1.3 Prosemirror richtext compatibility

1.8.4 - 17 January 2018
-----------------------
- Fix: Breaks console cron jobs on rare scenarios


1.8.3 - 10 November 2017
------------------------
- Fix: Linkpreview image max-width issue.


1.8.2
-----
- Fix: Linkpreview in comment bar not cleared.


1.8.1
-----
- Fix: Word break for linkpreview link overlapping stream entry.


1.8.0
-----
- Fix: Fixed guest mode linkpreview error
- Fix: Fixed paste event (core version 1.2.1)


