<?php
return array (
  'Choose a thumbnail' => 'Выберите значок',
);
