<?php
return array (
  'Choose a thumbnail' => 'Escolha uma miniatura',
);
