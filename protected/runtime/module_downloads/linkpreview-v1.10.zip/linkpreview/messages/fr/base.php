<?php
return array (
  'Choose a thumbnail' => 'Choisir une vignette',
);
