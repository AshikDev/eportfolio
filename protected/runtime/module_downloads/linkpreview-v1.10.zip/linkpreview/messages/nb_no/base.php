<?php
return array (
  'Choose a thumbnail' => 'Velg forhåndsvisning',
);
