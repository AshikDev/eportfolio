<?php
return array (
  'Choose a thumbnail' => 'Kies een afbeelding',
);
