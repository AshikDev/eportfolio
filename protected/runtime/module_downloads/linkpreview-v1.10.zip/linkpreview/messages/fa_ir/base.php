<?php
return array (
  'Choose a thumbnail' => 'انتخاب تصوير',
);
