<?php
return array (
  'Choose a thumbnail' => 'Wybierz miniaturkę',
);
