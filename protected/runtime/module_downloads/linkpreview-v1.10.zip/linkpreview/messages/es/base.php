<?php
return array (
  'Choose a thumbnail' => 'Selecciona una miniatura de la imágen',
);
