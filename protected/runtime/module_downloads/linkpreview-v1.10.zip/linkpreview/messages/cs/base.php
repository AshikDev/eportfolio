<?php
return array (
  'Choose a thumbnail' => 'Zvolte miniaturu',
);
