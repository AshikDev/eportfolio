<?php
return array (
  'Choose a thumbnail' => 'Vorschaubild auswählen',
);
