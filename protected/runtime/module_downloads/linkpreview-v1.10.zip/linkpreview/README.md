Link Preview Widget 
=================

The Link Preview Widget enable users to share links in posts and comments with rich previews attached. Users can select thumbnails, edit title and description.
<br />
<br />
<br />
<br />
<img src="http://www.consense-communications.de/content/download/3014/23118/file/Logo_consense_72dpi.jpg" alt="Drawing" style="width: 200px;"/>

__Author:__       
consense communications gmbh (GPRA)      
  
__Author description:__       
consense communications in Munich cares for the reputation of companies and products. Our international customers, be they world leaders or start-ups, rely on our many years of expertise in public relations and marketing across various industries. We act as a full-service agency, creating and running customized communication campaigns for all relevant target groups. As a modern agency, our services naturally cover online-PR, social media, blogs, communities, and twitter. Our views of, and experience in, online reputation management are given ample space in our agency blog, [http://netz-reputation.de](http://netz-reputation.de).
    
__Author website:__      
[http://www.consense-communications.de/](http://www.consense-communications.de)    
