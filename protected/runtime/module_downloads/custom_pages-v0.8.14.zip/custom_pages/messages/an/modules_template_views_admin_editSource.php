<?php

return [
    'Add Element' => '',
    'Edit All' => '',
    'Edit template \'{templateName}\'' => '',
    'Here you can edit the source of your template by defining the template layout and adding content elements. Each element can be assigned with a default content and additional definitions.' => '',
    'You haven\'t saved your last changes yet. Do you want to leave without saving?' => '',
];
