<?php
return array (
  'Content' => 'ይዘት',
  'ID' => 'መታወቂያ',
  'Icon' => 'አርማ',
  'Invalid template selection!' => 'የአማያገለግል አብነት መርጠዋል!',
  'Invalid view file selection!' => 'የማያገለግል የፋይል መመልከቻ መርጠዋል!',
  'Sort Order' => 'ቅደም ተከተል ያስይዙ',
  'Style Class' => 'የቅጥ ክፍል',
  'Target Url' => 'የታለመ url',
  'Template Layout' => 'የአብነት አቀማመጥ',
  'Title' => 'ርዕስ',
  'Type' => 'አይነት',
);
