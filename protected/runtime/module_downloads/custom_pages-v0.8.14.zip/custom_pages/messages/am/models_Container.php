<?php
return array (
  'Empty <br />Container' => 'ባዶ <br /> ማዕቀፍ',
);
