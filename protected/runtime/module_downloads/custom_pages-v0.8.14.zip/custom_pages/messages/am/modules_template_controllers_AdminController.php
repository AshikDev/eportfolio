<?php
return array (
  '<strong>Add</strong> new {type} element' => 'አዲስ የ{type} አካል <strong> ያክሉ </strong>',
  '<strong>Edit</strong> element {name}' => 'የ{name} አካልን <strong>ያስተካክሉ </strong>',
  '<strong>Edit</strong> elements of {templateName}' => 'የ{templateName} አካላትን <strong>ያስተካክሉ </strong>',
  '<strong>Edit</strong> {templateName}' => 'የ{templateName}ን <strong> ያስተካክሉ </strong>',
  'Template not found!' => 'አብነት አልተገኘም!',
  'The template could not be deleted, please get sure that this template is not in use.' => 'አብነቱ ሊወገድ አይችልም። እባክዎን ይህ አብነት አገልግሎት በመስጠት ላይ አለመሆኑ  ያረጋግጡ። ',
);
