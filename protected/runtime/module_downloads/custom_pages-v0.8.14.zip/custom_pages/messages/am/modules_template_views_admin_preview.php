<?php
return array (
  'Display Empty Content' => 'የሚታየው ባዶ ይዘት ነው',
  'Update' => 'አዘምን',
);
