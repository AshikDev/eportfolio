<?php
return array (
  '<strong>Confirm</strong> container item deletion' => 'የማዕቀፉን አካላት ለማስወገድ መፈለግዎን <strong>ያረጋግጡ</strong>',
  '<strong>Confirm</strong> content deletion' => 'ይዘቱን ለማስወገድ መፈለግዎን <strong>ያረጋግጡ</strong>',
  '<strong>Confirm</strong> element deletion' => 'የማዕቀፉን አባል ለማስወገድ መፈለግዎን <strong>ያረጋግጡ</strong>',
);
