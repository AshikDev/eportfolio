<?php
return array (
  'Save' => 'አስቀምጥ',
);
