<?php
return array (
  'Here you can manage your template layouts. Layouts are the root of your template pages and can not be combined with other templates.' => 'የአብነትዎን አቀማመጥ እዚህ ማስተካከል ይችላሉ። አቀማመጦች የአብነትዎ መሰረቶች ናቸው። እናም ከሌሎች አብነቶች ጋር ሊቀናጁ አይችሉም።',
);
