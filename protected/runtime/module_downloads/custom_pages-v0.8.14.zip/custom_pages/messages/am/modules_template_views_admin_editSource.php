<?php
return array (
  'Add Element' => 'አካል ያስገቡ',
  'Edit All' => 'ሁሉንም ያስተካክሉ',
  'Edit template \'{templateName}\'' => 'የ\'{templateName}\' አብነትን ያስተካክሉ',
  'Here you can edit the source of your template by defining the template layout and adding content elements. Each element can be assigned with a default content and additional definitions.' => 'የአብነቱን አቀማመጥ በመወሰን እና የይዘት አካላትን በማከል እዚህ የአብነትዎን ምንጭ ማስተካከል ይችላሉ። እያንዳንዱ አካላት ከነባሪ ይዘቶች እና ተጨማሪ ብያኔዎች ጋር በመሆን ሊደለደሉ ይችላሉ።',
  'You haven\'t saved your last changes yet. Do you want to leave without saving?' => 'የመጨረሻ ለውጦችዎን እስካሁን መዝግበው እላስቀመጧቸውም። መዝግበው ሳያስቀምጡ ከዚህ ገፅ ለቀው መሄድ ይፈልጋሉ?',
);
