<?php
return array (
  'Content' => 'ይዘት',
  'Sidebar' => 'የጎን ገፅታ',
  'snippet' => 'ቁንፅልመረጃ',
);
