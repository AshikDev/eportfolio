<?php
return array (
  'Here you can manage your template container elements.' => 'የአብነትዎን የማዕቀፍ አካላትን እዚህ ማስተካከል ይችላሉ።',
);
