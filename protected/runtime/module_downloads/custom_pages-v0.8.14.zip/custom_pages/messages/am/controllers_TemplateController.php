<?php
return array (
  '<strong>Edit</strong> {type} element' => 'የ{type} አካል<strong>አስተካካ</strong> ',
  'Access denied!' => 'ትዕዛዝዎ ተቀባይነት አላገኘም!',
  'Empty content elements cannot be delted!' => 'ባዶ ይዘት ያላቸው አካላት ሊወገዱ አይችሉም።',
  'Invalid request data!' => 'የማያገለግል የመረጃ ጥያቄ ቀርቧል!',
  'You are not allowed to delete default content!' => 'ነባሪ ይዘቶችን ለማስወገድ አልተፈቀደልዎትም።',
);
