<?php
return array (
  'snippet' => 'ቁንፅልመረጃ',
);
