<?php
return array (
  'Height' => 'ቁመት',
  'Style' => 'ቅጥ',
  'Width' => 'ስፋት',
);
