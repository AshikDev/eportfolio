<?php
return array (
  'Edit Page' => 'ገፁን ያርትዑ',
);
