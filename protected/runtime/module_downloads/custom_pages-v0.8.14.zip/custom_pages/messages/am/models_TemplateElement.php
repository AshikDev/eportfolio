<?php
return array (
  'Label' => 'ምልክት',
  'Placeholder name' => 'የቦታያዡ ስም',
  'The element name must contain at least two characters without spaces or special signs except \'_\'' => 'የአካሉ ስም ከ \'_\' ምልክት ውጪ ያለክፈተት እና ልዩ ምልክቶች ቢያንስ ሁለት የፅሁፍ ምልክቶችን መያዝ ይጠበቅበታል።',
  'The given element name is already in use for this template.' => 'የቀረበው አካል ስም በዚህ የድረገፅ አብነት ላይ ከዚህ ቀደም  አገልግሎት ላይ ውሏል።',
);
