<?php
return array (
  'Use default content' => 'የነበረውን ይዘት ተጠቀም',
);
