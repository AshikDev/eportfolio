<?php
return array (
  'Show less' => 'በትንሹ አሳይ',
  'Show more' => 'ዝርዝር አሳይ',
);
