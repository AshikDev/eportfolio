<?php
return array (
  'Add new {pageType}' => 'አዲስ {pageType} ያክሉ',
  'Create new template' => 'አዲስ አብነት ይፍጠሩ',
  'Edit template' => 'አብነቱን ያርትዑ',
  'Settings' => 'ማስተካከያዎች',
);
