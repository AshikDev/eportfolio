<?php
return array (
  'Allow multiple items?' => 'ነገሮች በጅምላ ይፈቀዱ?',
  'Allowed Templates' => 'የተፈቀደ አብነት',
  'Render items as inline-blocks within the inline editor?' => 'በአግባቡ የተሰደሩ ነገሮች በማስተካከያው ላይ እንዳላቸው አግባብ ይተርጎሙ?',
);
