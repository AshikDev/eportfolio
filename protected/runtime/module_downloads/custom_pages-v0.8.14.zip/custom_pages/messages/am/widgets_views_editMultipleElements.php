<?php
return array (
  'Empty' => 'ባዶ',
  'Inline' => 'አግባባዊ',
  'Multiple' => 'በብዛት',
  'This template does not contain any elements yet.' => 'ይህ አብነት እስካሁን ምንም አይነት ነገሮችን አልያዘም።',
);
