<?php
return array (
  'Use empty content' => 'ባዶ ይዘት ተጠቀም',
);
