<?php
return array (
  '<strong>Add</strong> {templateName} item' => ' {templateName} <strong>አክል</stron>',
  '<strong>Edit</strong> item' => 'ይህን <strong>አስተካክል</strong>',
);
