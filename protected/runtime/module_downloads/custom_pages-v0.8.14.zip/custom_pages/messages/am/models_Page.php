<?php
return array (
  'Navigation' => 'የማውጫ ቁልፍ',
  'Only visible for admins' => 'ለአስተዳዳሪዎች ብቻ የሚታይ',
  'Open in new window' => 'በአዲስ መስኮት ውስጥ ክፈት',
  'Url shortcut' => 'የurl አቋራጭመንገድ',
  'View' => 'ተመልከት',
  'page' => 'ገፅ',
);
