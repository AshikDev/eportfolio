<?php

return [
    'No {label} entry created yet!' => '',
    'Create new {label}' => 'Luo uusi {label}',
    'This page lists all available {label} entries.' => 'Tällä sivulla on luettelo kaikista saatavilla olevista {label} -merkinnöistä.',
];
