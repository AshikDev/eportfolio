<?php
return array (
  'none' => 'ei mitään',
);
