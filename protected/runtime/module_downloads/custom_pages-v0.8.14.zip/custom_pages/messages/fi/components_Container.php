<?php

return [
    'Invalid template selection!' => '',
    'Invalid view file selection!' => '',
    'Sort Order' => '',
    'Target Url' => '',
    'Template Layout' => '',
    'Content' => 'Sisältö',
    'ID' => 'ID',
    'Icon' => 'Iconi',
    'Style Class' => 'Tyyli luokka',
    'Title' => 'Otsikko',
    'Type' => 'Tyyppi',
];
