<?php

return [
    'View not found' => '',
];
