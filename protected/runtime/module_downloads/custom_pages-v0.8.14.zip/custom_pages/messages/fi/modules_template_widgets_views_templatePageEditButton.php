<?php

return [
    'Edit Page' => '',
];
