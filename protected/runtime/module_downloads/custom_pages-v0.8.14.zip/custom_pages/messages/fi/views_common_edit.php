<?php

return [
    'By setting an url shortcut value, you can create a better readable url for your page. If <b>URL Rewriting</b> is enabled on your site, the value \'mypage\' will result in an url \'www.example.de/p/mypage\'.' => '',
    'Configuration' => '',
    'Delete' => '',
    'Here you can configure the general settings of your {label}.' => '',
    'Inline Editor' => '',
    'Save' => '',
    'e.g. http://www.example.de' => '',
];
