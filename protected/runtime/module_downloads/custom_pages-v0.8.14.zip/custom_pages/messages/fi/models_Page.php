<?php

return [
    'Url shortcut' => '',
    'View' => '',
    'Navigation' => 'Navigointi',
    'Only visible for admins' => 'Näkyvissä vain ylläpitäjille',
    'Open in new window' => 'Avaa uuteen ikkunaan',
    'page' => 'sivu',
];
