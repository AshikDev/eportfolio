<?php
/**
 * Created by PhpStorm.
 * User: 001101
 * Date: 25.01.2017
 * Time: 03:42
 */

return array (
    'Here you can manage your snipped layouts. Snippet layouts are templates, which can be included into sidebars.' => 'Täällä voit hallita laatikkoja. Laatikot ovat malleja, jotka voidaan sisällyttää sivupalkkeihin.',

);