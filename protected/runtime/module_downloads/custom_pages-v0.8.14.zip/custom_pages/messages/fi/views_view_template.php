<?php

return [
    'Edit elements' => '',
    'Edit template' => '',
    'Page configuration' => '',
    'Turn edit off' => '',
    'Edit Template' => 'Muokkaa Ulkoasua',
];
