<?php

return [
    'Display Empty Content' => '',
    'Update' => '',
];
