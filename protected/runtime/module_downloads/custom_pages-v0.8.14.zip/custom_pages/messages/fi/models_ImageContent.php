<?php

return [
    'Empty Image' => '',
];
