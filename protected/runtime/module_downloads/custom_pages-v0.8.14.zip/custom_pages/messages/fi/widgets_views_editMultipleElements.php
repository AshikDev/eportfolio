<?php
return array (
  'Empty' => 'Tyhjä',
  'Inline' => '',
  'Multiple' => '',
  'This template does not contain any elements yet.' => '',
);
