<?php

return [
    '<strong>Edit</strong> item' => '',
    '<strong>Add</strong> {templateName} item' => '<strong>Lis��</strong> {templateName} er�',
];
