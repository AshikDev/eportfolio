<?php

return [
    'Create new {type}' => 'Luo uusi {type}',
    'Edit template \'{templateName}\'' => 'Muokkaa mallia \'{templateName}\' ',
    'Save' => 'Tallenna',
];
