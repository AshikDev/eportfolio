<?php

return [
    'Activate PHP based Pages and Snippets' => '',
    'If disabled, existing php pages will still be online, but can\'t be created.' => '',
    'PHP view path for custom space pages' => '',
    'PHP view path for custom space snippets' => '',
    'PHP view path for global custom pages' => '',
    'PHP view path for global custom snippets' => '',
    'The given view file path does not exist.' => '',
];
