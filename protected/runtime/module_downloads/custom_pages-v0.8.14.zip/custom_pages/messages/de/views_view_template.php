<?php
return array (
  'Edit Template' => 'Vorlage bearbeiten',
  'Edit elements' => 'Elemente bearbeiten',
  'Edit template' => 'Vorlage bearbeiten',
  'Page configuration' => 'Seiten Konfiguration',
  'Turn edit off' => 'Bearbeiten ausschalten',
);
