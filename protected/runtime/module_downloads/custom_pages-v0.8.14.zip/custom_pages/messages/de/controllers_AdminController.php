<?php
return array (
  '<strong>Add</strong> {templateName} item' => '{templateName} Element <strong>hinzufügen</strong>',
  '<strong>Edit</strong> item' => 'Element <strong>bearbeiten</strong>',
);
