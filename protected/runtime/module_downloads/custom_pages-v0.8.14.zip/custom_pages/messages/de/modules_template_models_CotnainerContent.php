<?php
return array (
  'Allow multiple items?' => 'Mehrere Elemente zulassen?',
  'Allowed Templates' => 'Erlaubte Vorlagen',
  'Render items as inline-blocks within the inline editor?' => 'Elemente als Inline-Blöcke im Inline-Editor rendern?',
);
