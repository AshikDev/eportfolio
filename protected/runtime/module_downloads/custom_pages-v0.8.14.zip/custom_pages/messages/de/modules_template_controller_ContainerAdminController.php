<?php
return array (
  'Here you can manage your template container elements.' => 'Hier kannst du deine Container Vorlagen-Elemente verwalten',
);
