<?php
return array (
  'snippet' => 'Schnipsel',
);
