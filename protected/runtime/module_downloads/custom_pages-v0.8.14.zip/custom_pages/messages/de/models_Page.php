<?php
return array (
  'Navigation' => 'Navigation',
  'Only visible for admins' => 'Nur für Admins sichtbar',
  'Open in new window' => 'In neuem Fenster öffnen',
  'Url shortcut' => 'URL-Verknüpfung',
  'View' => 'Ansicht',
  'page' => 'Seite',
);
