<?php
return array (
  'Add new {pageType}' => 'Neuen {pageType} hinzufügen',
  'Create new template' => 'Neue Vorlage erstellen',
  'Edit template' => 'Vorlage bearbeiten',
  'Settings' => 'Einstellungen',
);
