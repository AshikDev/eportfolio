<?php
return array (
  'Use default content' => 'Standardinhalt verwenden',
);
