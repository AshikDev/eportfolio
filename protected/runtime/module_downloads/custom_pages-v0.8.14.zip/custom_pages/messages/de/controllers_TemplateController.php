<?php
return array (
  '<strong>Edit</strong> {type} element' => '{type} Element<strong>bearbeiten</strong> ',
  'Access denied!' => 'Zugang verweigert!',
  'Empty content elements cannot be delted!' => 'Leere Inhaltselemente können nicht gelöscht werden!',
  'Invalid request data!' => 'Ungültige Anfrage Daten!',
  'You are not allowed to delete default content!' => 'Du darfst keine Standardinhalte löschen!',
);
