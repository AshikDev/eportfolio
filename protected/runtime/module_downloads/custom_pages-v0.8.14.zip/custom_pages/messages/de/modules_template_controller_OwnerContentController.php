<?php
return array (
  '<strong>Confirm</strong> container item deletion' => 'Löschen des Container-Elements <strong>bestätigen</strong>',
  '<strong>Confirm</strong> content deletion' => 'Löschen der Inhalte <strong>bestätigen</strong>',
  '<strong>Confirm</strong> element deletion' => 'Löschen des Elements <strong>bestätigen</strong>',
);
