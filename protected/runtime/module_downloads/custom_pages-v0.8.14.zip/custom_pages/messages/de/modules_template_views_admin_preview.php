<?php
return array (
  'Display Empty Content' => 'Leeren Inhalt anzeigen',
  'Update' => 'Aktualisieren',
);
