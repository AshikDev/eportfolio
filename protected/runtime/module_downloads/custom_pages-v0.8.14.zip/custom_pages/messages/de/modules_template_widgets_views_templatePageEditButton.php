<?php
return array (
  'Edit Page' => 'Seite bearbeiten',
);
