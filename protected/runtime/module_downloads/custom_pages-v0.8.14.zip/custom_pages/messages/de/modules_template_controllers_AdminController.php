<?php
return array (
  '<strong>Add</strong> new {type} element' => 'Neues {type} Element <strong>hinzufügen</strong>',
  '<strong>Edit</strong> element {name}' => 'Element {name} <strong>bearbeiten</strong>',
  '<strong>Edit</strong> elements of {templateName}' => ' {templateName} Elemente <strong>bearbeiten</strong>',
  '<strong>Edit</strong> {templateName}' => ' {templateName} <strong>bearbeiten</strong>',
  'Template not found!' => 'Vorlage nicht gefunden!',
  'The template could not be deleted, please get sure that this template is not in use.' => 'Die Vorlage konnte nicht gelöscht werden. Bitte prüfen, ob diese Vorlage nicht verwendet wird.',
);
