<?php
return array (
  'Empty' => 'Leer',
  'Inline' => 'Inline',
  'Multiple' => 'Mehrere',
  'This template does not contain any elements yet.' => 'Diese Vorlage enthält noch keine Elemente.',
);
