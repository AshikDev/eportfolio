<?php
return array (
  'none' => 'keine',
);
