0.8.14  (April 5, 2019)
---------------------
- Fix: Missed confirm box on page deletion


0.8.13  (February 25, 2019)
---------------------
- Fixed xss vulnerability issue

0.8.12  (February 05, 2019)
---------------------
- Fix: Space admin can't add template components
- Chng: Updated min version to 1.3.0

0.8.11  (February 01, 2019)
---------------------
- Enh: Updated translations
- Fix #89: XSS vulnerability

0.8.10  (October 27, 2018)
---------------------
- Enh: Translation updates

0.8.9  (October 04, 2018)
---------------------
- Fix: Iframe loader not removed

0.8.8  (September 18, 2018)
---------------------
- Fix: Use of deprecated jQuery load instead of .on('load')

0.8.6  (July 13, 2018)
---------------------
- Fix: added missing custom directories

0.8.5  (July 12, 2018)
---------------------
- Fix: added check for php page active in php file count check
- Fix: edit snippet not working in addition with footer nav

0.8.4  (July 2, 2018)
---------------------
- Fix: PHP 7.2 compatibility issues

0.8.3
-----
- Fix: 1.3 compatibility
- Fix: 1.2.0 compatibility

0.8.2:
- Chg: Use of 'Pages' overview as first admin page

0.8:
- Fix #73: Richtext uploads not attached on initial edit;
- Fix #33: fixed strict access for global pages
- Fix #68: wrong translation key
- Enh: Added page type PHP
- Enh: Added module setting page

0.7.13:
- Fix: Error with FileManager afterSave logic
- Enh: Open FileDownload items in new window

0.7.9:
- Enh: Allow target _blank links in richtext

0.7.8: 
- Enh: Added directory menu pages

0.7.7:
- Enh: Added file download content + download item/download list template
- Enh: Usability enhancements
- Fix: Add item with only one allowed template not working
- Enh: Allow Inline Activation only for certain container items
- Enh: Added template elemen title field
- Enh: Use select2 dropdown as template select

0.7.6:
- Fix: Iframe page size fix.

0.7.5:
- Fix: edit snippet issue.
- Fix: icon 'none' in snippet icon selector.
- Fix: Don't show container page in stream.

0.7.4: 
- Fix: select2  template selection shrink if rendered in hidden panel
- Fix: Cancel button color
- Fix: Fixed account setting template page container issue
- Enh: #56 Use of select2 dropdown as icon chooser
- Fix: #40 Image/File upload ajax error handling
- Fix: HumHub 1.2.beta.3 support

