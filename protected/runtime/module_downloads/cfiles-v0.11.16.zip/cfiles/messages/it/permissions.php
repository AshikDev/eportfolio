<?php
return array (
  'Add files' => 'Aggiungi file',
  'Allows the user to modify or delete any files.' => 'Permetti agli utenti di modificare o cancellare i file',
  'Allows the user to upload new files and create folders' => 'Permetti agli utenti di caricare nuovi file e creare cartelle',
  'Manage files' => 'Gestisci file',
);
