<?php
return array (
  'Description' => 'Descrizione',
  'Parent Folder ID' => 'ID cartella superiore',
  'Title' => 'Titolo',
);
