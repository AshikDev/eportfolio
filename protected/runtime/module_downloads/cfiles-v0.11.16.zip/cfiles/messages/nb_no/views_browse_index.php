<?php
return array (
  'Could not save file %title%. ' => 'Kunne ikke lagre filen %title%.',
);
