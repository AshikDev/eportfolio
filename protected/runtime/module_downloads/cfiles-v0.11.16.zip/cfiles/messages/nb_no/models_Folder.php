<?php
return array (
  'Description' => 'Beskrivelse',
  'Parent Folder ID' => 'Overordnet mappe ID',
  'Title' => 'Tittel',
);
