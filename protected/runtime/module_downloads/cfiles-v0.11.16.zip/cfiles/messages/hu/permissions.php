<?php
return array (
  'Add files' => 'Fájlok feltöltése',
  'Allows the user to modify or delete any files.' => 'A felhasználó bármelyik fájlt szerkesztheti vagy törölheti.',
  'Allows the user to upload new files and create folders' => '',
  'Manage files' => '',
);
