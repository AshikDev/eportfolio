<?php
return array (
  'Is Public' => 'Is openbaar',
  'Note: Changes of the folders visibility, will be inherited by all contained files and folders.' => 'Opmerking: Wijzigingen in de zichtbaarheid wijzigen van de mappen worden ook toegepast op alle bestanden en mappen in de mappen.',
);
