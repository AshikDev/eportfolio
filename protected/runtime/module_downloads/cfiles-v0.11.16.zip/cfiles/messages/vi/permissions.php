<?php
return array (
  'Add files' => 'Thêm files',
  'Allows the user to modify or delete any files.' => 'Cho phép người dùng chỉnh sửa hoặc xóa bất kỳ files nào.',
  'Allows the user to upload new files and create folders' => 'Cho phép người dùng upload file và tạo thư mục',
  'Manage files' => 'Quản lý files',
);
