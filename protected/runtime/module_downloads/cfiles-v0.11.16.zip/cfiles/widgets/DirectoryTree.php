<?php
/**
 * @link https://www.humhub.org/
 * @copyright Copyright (c) 2017 HumHub GmbH & Co. KG
 * @license https://www.humhub.com/licences
 *
 */

/**
 * Created by PhpStorm.
 * User: buddha
 * Date: 19.08.2017
 * Time: 19:49
 */

namespace humhub\modules\cfiles\widgets;


use humhub\components\Widget;
use humhub\modules\cfiles\models\Folder;

class DirectoryTree extends Widget
{
    /**
     * @var Folder current folder
     */
    public $folder;

    public function run()
    {

    }

}