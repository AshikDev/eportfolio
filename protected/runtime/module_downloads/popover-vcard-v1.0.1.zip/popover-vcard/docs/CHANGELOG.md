Changelog
=========

1.0.0  (July 17, 2018)
-----------------------
- Enh: Added screenshots


1.0.0  (July 16, 2018)
-----------------------
- Enh: Initial release
