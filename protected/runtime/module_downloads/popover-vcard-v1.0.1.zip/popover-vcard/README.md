## Description

This module shows an overlay with further information on stream links to spaces or user profiles.

### Features

- Individual templating of overlay vcards
 

__Author:__ HumHub
__Author website:__ [www.humhub.org](http://www.humhub.org)


