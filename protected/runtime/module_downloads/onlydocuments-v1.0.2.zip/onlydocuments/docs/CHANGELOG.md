Changelog
=========

1.0.2 (July 2, 2018)
--------------------
- Fix: PHP 7.2 compatibility issues


1.0.1  (May 08, 2018)
-----------------------
- Enh: Updated translations
