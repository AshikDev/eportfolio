Changelog
=========

1.0.3  (July 2, 2018)
---------------------
- Fix: PHP 7.2 compatibility issues


1.0.2  (October 11, 2017)
------------------------_
- Enh: Added possiblity to hide users when terms not accepted yet
- Enh: Moved terms accepted flag to the user model to improve lookup speed 
