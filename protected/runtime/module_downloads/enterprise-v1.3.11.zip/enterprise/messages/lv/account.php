<?php
return array (
  '<strong>Enterprise Edition</strong> Trial Period' => '<strong>Uzņēmuma Izdevums</strong> Izmēģinājuma periods',
  '<strong>Invalid</strong> Enterprise Edition Licence' => '<strong>Kļūdaina</strong> Uzņēmuma Izdevuma licence',
  '<strong>Register</strong> Enterprise Edition' => '<strong>Reģistrēt</strong> Uzņēmuma Izdevumu',
  '<strong>Unregistered</strong> Enterprise Edition' => '<strong>Noņemt reģistrāciju</strong> Uzņēmuma Izdevumam',
  'Enterprise Edition' => 'Uzņēmuma Izdevums',
  'Please enter your <strong>HumHub - Enterprise Edition</strong> licence key below. If you don\'t have a licence key yet, you can obtain one at %link%.' => 'Lūdzu ievadi savu <strong>HumHub - Uzņēmuma Izdevuma</strong> licenci zemāk. Ja tev vēl nav licences atslēga, tu vari tādu iegūt šeit %link%.',
  'Please register this <strong>HumHub - Enterprise Edition</strong>!' => 'Lūdzu reģistrē šo <strong>HumHub - Uzņēmuma Izdevumu</strong>!',
  'Please update this <strong>HumHub - Enterprise Edition</strong> licence!' => 'Lūdzu atjaunini šo <strong>HumHub - Uzņēmuma Izdevuma</strong> licenci!',
  'Registration successful!' => 'Reģistrācija ir veiksmīga!',
  'Validating...' => 'Pārbauda...',
  'You have <strong>{daysLeft}</strong> days left in your trial period.' => 'Tev ir atlikušas <strong>{daysLeft}</strong> dienas līdz izmēģinājuma perioda beigām.',
);
