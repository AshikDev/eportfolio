<?php
return array (
  'Hide sidebar' => 'Skjul sidebar',
  'Show sidebar' => 'Vis sidebar',
);
