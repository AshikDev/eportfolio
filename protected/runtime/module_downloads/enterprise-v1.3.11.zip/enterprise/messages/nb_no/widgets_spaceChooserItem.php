<?php
return array (
  'Your are not a member of this space' => 'Dessverre er du ikke medlem av denne gruppen',
);
