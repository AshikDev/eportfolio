<?php
return array (
  '<strong>Enterprise Edition</strong> Trial Period' => '<strong>Enterprise Edition</strong> periodo di valutazione',
  '<strong>Invalid</strong> Enterprise Edition Licence' => 'Licenza Enterprise Edition <strong>non valida</strong>',
  '<strong>Register</strong> Enterprise Edition' => 'Enterprise Edition <strong>Registrata</strong> ',
  '<strong>Unregistered</strong> Enterprise Edition' => 'Enterprise Edition <strong>Non registrata</strong> ',
  'Enterprise Edition' => 'Enterprise Edition',
  'Please enter your <strong>HumHub - Enterprise Edition</strong> licence key below. If you don\'t have a licence key yet, you can obtain one at %link%.' => 'Inserisci la tua chiave di licenza <strong>HumHub - Enterprise Edition</strong> qui sotto. Se ancora non hai una chiave di licenza, puoi ottenerne una qui %link%.',
  'Please register this <strong>HumHub - Enterprise Edition</strong>!' => 'Registra questa <strong>HumHub - Enterprise Edition</strong>!',
  'Please update this <strong>HumHub - Enterprise Edition</strong> licence!' => 'Aggiorna la licenza <strong>HumHub - Enterprise Edition</strong>!',
  'Registration successful!' => 'Registrazione completata!',
  'Validating...' => 'Validazione...',
  'You have <strong>{daysLeft}</strong> days left in your trial period.' => 'Hai ancora <strong>{daysLeft}</strong> giorni per il tuo periodo di valutazione.',
);
