<?php
return array (
  '<strong>Enterprise Edition</strong> Trial Period' => 'Período de avaliação <strong>Enterprise Edition</strong>',
  '<strong>Invalid</strong> Enterprise Edition Licence' => 'Licença Enterprise Edition <strong>inválida</strong>',
  '<strong>Register</strong> Enterprise Edition' => '<strong>Registro</strong> de Enterprise Edition',
  '<strong>Unregistered</strong> Enterprise Edition' => 'Enterprise Edition <strong>Não Registrada</strong>',
  'Enterprise Edition' => 'Enterprise Edition',
  'Please enter your <strong>HumHub - Enterprise Edition</strong> licence key below. If you don\'t have a licence key yet, you can obtain one at %link%.' => 'Introduza a sua chave de licença <strong>HumHub - Enterprise Edition</strong> abaixo. Se ainda não tem uma chave de licença, obtenha uma em %link%.',
  'Please register this <strong>HumHub - Enterprise Edition</strong>!' => 'Por favor, registre esta versão <strong>HumHub - Enterprise Edition</strong>!',
  'Please update this <strong>HumHub - Enterprise Edition</strong> licence!' => 'Por favor, atualize esta licença <strong>HumHub - Enterprise Edition</strong>!',
  'Registration successful!' => 'Registo bem sucedido!',
  'Validating...' => 'Validando...',
  'You have <strong>{daysLeft}</strong> days left in your trial period.' => 'Você tem <strong>{daysLeft}</strong> dias restantes em seu período de avaliação.',
);
