<?php
return array (
  'Hide sidebar' => 'Kenar çubuğunu gizle',
  'Show sidebar' => 'Kenar çubuğunu göster',
);
