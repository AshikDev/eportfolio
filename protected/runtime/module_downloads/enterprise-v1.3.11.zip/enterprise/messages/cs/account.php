<?php
return array (
  '<strong>Enterprise Edition</strong> Trial Period' => '<strong>Podniková edice</strong> Zkušební doba',
  '<strong>Invalid</strong> Enterprise Edition Licence' => '<strong>Neplatná licence</strong> Podnikové edice',
  '<strong>Register</strong> Enterprise Edition' => '<strong>Zaregistrovat </strong> Podnikovou edici',
  '<strong>Unregistered</strong> Enterprise Edition' => '<strong>Odregistrovat </strong> Podnikovou edici',
  'Enterprise Edition' => 'Podniková edice',
  'Please enter your <strong>HumHub - Enterprise Edition</strong> licence key below. If you don\'t have a licence key yet, you can obtain one at %link%.' => 'Zadejte Váš  licenční klíč pro verzi <strong>HumHub Pro podniky</strong>. Pokud klíč nemáte, můžete jej získat na následujícím odkazu %link%.',
  'Please register this <strong>HumHub - Enterprise Edition</strong>!' => 'Prosím zaregistrujte tuto verzi <strong>HumHub Pro podniky</strong>!',
  'Please update this <strong>HumHub - Enterprise Edition</strong> licence!' => 'Prosím aktualizujte licenci <strong>HumHub Pro podniky</strong> !',
  'Registration successful!' => 'Registrace úspěšná!',
  'Validating...' => 'Ověřování...',
  'You have <strong>{daysLeft}</strong> days left in your trial period.' => 'Zbývá <strong>{daysLeft}</strong> dní zkušební licence.',
);
