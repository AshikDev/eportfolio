<?php
return array (
  'A whitelist rule can either be in the form <strong>@example.com</strong> to allow each email of the given host or a complete address as <strong>user@example.com</strong>' => 'Une règle de liste blanche peut être soit de la forme <strong>@exemple.com</strong> pour autoriser tous les e-mails d\'un domaine donné, soit une adresse complète comme <strong>utilisateur@exemple.com</strong>',
  'Separate multiple rules by a new line.' => 'Séparer les règles multiples par une nouvelle ligne.',
  'Separate multiple whitelist rules by a new line.' => 'Séparer les règles multiples de liste blanche par une nouvelle ligne.',
);
