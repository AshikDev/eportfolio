<?php
return array (
  'Hide sidebar' => 'Cacher le menu latéral',
  'Show sidebar' => 'Afficher le menu latéral',
);
