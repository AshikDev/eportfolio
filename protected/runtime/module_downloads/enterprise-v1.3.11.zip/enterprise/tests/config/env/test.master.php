<?php

return [
    'humhub_root' => 'D:\codebase\humhub\v1.2-dev'
];



