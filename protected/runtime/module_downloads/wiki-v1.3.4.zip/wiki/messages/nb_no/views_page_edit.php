<?php

return [
    '<strong>Create</strong> new page' => '<strong>Opprett</strong> side',
    '<strong>Edit</strong> page' => '<strong>Rediger</strong> side',
    'New page title' => 'Ny sidetittel',
];
