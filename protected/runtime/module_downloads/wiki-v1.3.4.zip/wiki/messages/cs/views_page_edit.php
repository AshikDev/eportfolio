<?php

return [
    '<strong>Create</strong> new page' => '<strong>Vytvoření</strong> nové stránky',
    '<strong>Edit</strong> page' => '<strong>Změna</strong> stránky',
    'New page title' => 'Titulek stránky',
];
