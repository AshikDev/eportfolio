<?php
return array (
  'Open wiki page...' => 'Otwórz stronę wiki...',
);
