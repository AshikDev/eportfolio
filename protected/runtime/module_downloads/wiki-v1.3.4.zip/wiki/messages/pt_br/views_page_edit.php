<?php

return [
    '<strong>Create</strong> new page' => '<strong>Criar</strong> nova página',
    '<strong>Edit</strong> page' => '<strong>Editar</strong> página',
    'New page title' => 'Título da nova página',
];
