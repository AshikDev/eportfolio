<?php
return array (
  'Open wiki page...' => 'Wiki-Seite öffnen...',
);
