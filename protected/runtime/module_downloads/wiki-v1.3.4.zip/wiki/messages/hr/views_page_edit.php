<?php

return [
    '<strong>Create</strong> new page' => '<strong>Kreiraj</strong> novu stranicu',
    '<strong>Edit</strong> page' => '<strong>Uredi</strong> stranicu',
    'New page title' => 'Novi naziv stranice',
];
