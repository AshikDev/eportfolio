<?php

return [
    'Open wiki page...' => '',
];
