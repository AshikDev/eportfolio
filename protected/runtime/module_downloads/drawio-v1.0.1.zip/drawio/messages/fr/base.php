<?php
return array (
  '<strong>Create</strong> draw.io diagram' => '<strong>Créer</strong> un diagramme draw.io',
  '<strong>Draw.io </strong> module configuration' => 'Configuration du module <strong>draw.io</strong>',
  'Could not find requested file!' => 'Impossible de trouver le fichier demandé.',
  'Create draw.io document' => 'Créer un document draw.io',
  'Edit using draw.io' => 'Modifier via draw.io',
  'File write access denied!' => 'Accès en écriture refusé.',
  'Hostname' => 'Nom de l\'hôte',
  'Open the new document in the next step' => 'Ouvrir le nouveau document dans la prochaine étape',
  'e.g. https://draw.io' => 'p.ex. https://draw.io',
);
