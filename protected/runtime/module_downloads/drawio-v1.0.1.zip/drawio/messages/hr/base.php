<?php
return array (
  '<strong>Create</strong> draw.io diagram' => '<strong>Kreiraj</strong> draw.io diagram',
  '<strong>Draw.io </strong> module configuration' => '<strong>Draw.io </strong> konfiguracija modula',
  'Could not find requested file!' => 'Ne mogu pronaći traženu datoteku!',
  'Create draw.io document' => 'Kreiraj draw.io dokument',
  'Edit using draw.io' => 'Uredi koristeći draw.io',
  'File write access denied!' => 'Pristup za pisanje zapisa odbijen!',
  'Hostname' => 'Hostaname',
  'Open the new document in the next step' => 'Otvorite novi dokument u sljedećem koraku',
  'e.g. https://draw.io' => 'e.g. https://draw.io',
);
