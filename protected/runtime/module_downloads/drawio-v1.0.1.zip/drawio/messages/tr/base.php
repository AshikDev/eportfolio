<?php
return array (
  '<strong>Create</strong> draw.io diagram' => '',
  '<strong>Draw.io </strong> module configuration' => '',
  'Could not find requested file!' => 'İstenen dosya bulunamadı!',
  'Create draw.io document' => 'Draw.io belgesi oluştur',
  'Edit using draw.io' => 'Draw.io dosyasını düzenleme',
  'File write access denied!' => 'Dosya yazma erişimi reddedildi!',
  'Hostname' => 'Host Adı',
  'Open the new document in the next step' => '',
  'e.g. https://draw.io' => 'örn: https://draw.io',
);
