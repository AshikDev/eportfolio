<?php
return array (
  '<strong>Create</strong> draw.io diagram' => '<strong>Maak</strong> een  draw.io diagram',
  '<strong>Draw.io </strong> module configuration' => '<strong>Draw.io </strong> module configuratie',
  'Could not find requested file!' => 'Kan het aangevraagde bestand niet vinden!',
  'Create draw.io document' => 'Maak een draw.io document',
  'Edit using draw.io' => 'Bewerken met draw.io',
  'File write access denied!' => 'Schrijftoegang tot het bestand geweigerd.',
  'Hostname' => 'Computernaam',
  'Open the new document in the next step' => 'Open het nieuwe document in de volgende stap',
  'e.g. https://draw.io' => 'bijvoorbeeld https://draw.io',
);
