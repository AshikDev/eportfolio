<?php
return array (
  '<strong>Create</strong> draw.io diagram' => 'Draw.io-Diagramm <strong> erstellen</strong>',
  '<strong>Draw.io </strong> module configuration' => 'Draw.io-Modulkonfiguration',
  'Could not find requested file!' => 'Die angeforderte Datei konnte nicht gefunden werden!',
  'Create draw.io document' => 'Draw.io-Dokument erstellen',
  'Edit using draw.io' => 'Mit draw.io bearbeiten',
  'File write access denied!' => 'Datei-Schreibzugriff verweigert!',
  'Hostname' => 'Host-Name',
  'Open the new document in the next step' => 'Öffnen Sie das neue Dokument im nächsten Schritt',
  'e.g. https://draw.io' => 'z. B. https://draw.io',
);
