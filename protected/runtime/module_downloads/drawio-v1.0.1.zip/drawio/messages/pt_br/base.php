<?php
return array (
  '<strong>Create</strong> draw.io diagram' => '<strong>Criar</strong> diagrama do draw.io',
  '<strong>Draw.io </strong> module configuration' => 'Módulo de configuração do <strong>Draw.io</strong>',
  'Could not find requested file!' => 'Não foi possível encontrar o arquivo solicitado!',
  'Create draw.io document' => 'Criar documento do draw.io',
  'Edit using draw.io' => 'Alterar usando o draw.io',
  'File write access denied!' => 'Acesso de escrita negado!',
  'Hostname' => 'Hostname',
  'Open the new document in the next step' => 'Abrir o novo documento na próxima etapa',
  'e.g. https://draw.io' => 'exemplo: https://draw.io',
);
