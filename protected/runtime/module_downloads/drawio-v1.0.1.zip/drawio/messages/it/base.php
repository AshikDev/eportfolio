<?php
return array (
  '<strong>Create</strong> draw.io diagram' => '<strong>Crea</strong> diagramma draw.io',
  '<strong>Draw.io </strong> module configuration' => 'Configurazione modulo <strong>Draw.io</strong>',
  'Could not find requested file!' => 'Non riesco a trovare il file richiesto!',
  'Create draw.io document' => 'Crea documento draw.io ',
  'Edit using draw.io' => 'Modifica usando draw.io',
  'File write access denied!' => 'Permesso di scrittura al file negato!',
  'Hostname' => 'Hostname',
  'Open the new document in the next step' => 'Apri il nuovo documento nel prossimo passaggio',
  'e.g. https://draw.io' => 'es. https://draw.io',
);
