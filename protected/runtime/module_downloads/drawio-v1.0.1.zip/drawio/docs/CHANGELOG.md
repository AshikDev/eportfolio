Changelog
=========

1.0.1  (July 2, 2018)
---------------------
- Fix: PHP 7.2 compatibility issues


