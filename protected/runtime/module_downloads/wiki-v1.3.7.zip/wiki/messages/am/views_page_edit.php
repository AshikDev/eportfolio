<?php

return [
    '<strong>Create</strong> new page' => '',
    '<strong>Edit</strong> page' => '',
    'New page title' => '',
];
