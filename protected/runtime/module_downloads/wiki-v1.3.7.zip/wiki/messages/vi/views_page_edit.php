<?php

return [
    '<strong>Create</strong> new page' => '<strong>Tạo</strong> trang mới',
    '<strong>Edit</strong> page' => '<strong>Chỉnh sửa</strong> trang',
    'New page title' => 'Tiêu đề trang mới',
];
