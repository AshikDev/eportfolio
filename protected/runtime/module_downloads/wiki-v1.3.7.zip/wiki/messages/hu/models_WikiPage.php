<?php
return array (
  'Wiki page' => 'Wiki oldal',
);
