<?php
return array (
  'Wiki page' => 'Wiki Seite',
);
