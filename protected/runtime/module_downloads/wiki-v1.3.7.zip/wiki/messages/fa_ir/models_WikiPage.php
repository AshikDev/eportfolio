<?php
return array (
  'Wiki page' => 'صفحه‌ی ویکی',
);
