<?php

return [
    '<strong>Create</strong> new page' => '<strong>Créer</strong> une nouvelle page',
    '<strong>Edit</strong> page' => '<strong>Editer</strong> la page',
    'New page title' => 'Titre de la page',
];
