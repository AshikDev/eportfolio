<?php

return [
    'Add recipients' => 'Agregar destinatarios',
    'New message' => 'Nuevo mensaje',
    'Send' => 'Enviar',
];
