<?php
return array (
  'Sign up now' => 'Registriere dich jetzt',
);
