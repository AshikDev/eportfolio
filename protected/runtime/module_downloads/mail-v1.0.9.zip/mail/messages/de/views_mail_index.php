<?php

return [
    'Conversations' => 'Unterhaltungen',
    'New' => 'Neu',
    'There are no messages yet.' => 'Es sind noch keine Nachrichten vorhanden.',
];
