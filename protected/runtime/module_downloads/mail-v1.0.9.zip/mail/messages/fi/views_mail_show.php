<?php
return array (
  '<strong>Confirm</strong> deleting conversation' => '<strong>Poista</strong> keskustelu',
  '<strong>Confirm</strong> leaving conversation' => '<strong>Poistu</strong> keskustelusta',
  '<strong>Confirm</strong> message deletion' => '<strong>Vahvista</strong> viestin poistaminen',
  'Add user' => 'Lisää käyttäjä',
  'Cancel' => 'Poistu',
  'Delete' => 'Poista',
  'Delete conversation' => 'Poista keskustelu',
  'Do you really want to delete this conversation?' => 'Haluatko varmasti poistaa tämän keskustelun?',
  'Do you really want to delete this message?' => 'Haluatko varmasti poistaa tämän viestin?',
  'Do you really want to leave this conversation?' => 'Haluatko varmasti poistua tästä keskustelusta?',
  'Leave' => 'Poistu',
  'Leave conversation' => 'Poistu keskustelusta',
  'Send' => 'Lähetä',
  'There are no messages yet.' => 'Täällä ei ole viestejä vielä.',
);
