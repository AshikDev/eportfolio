<?php
return array (
  'Groups' => 'Ryhmät',
  'Members' => 'Jäsenet',
  'Spaces' => 'Sivut',
  'User Posts' => 'Käyttäjän Julkaisut',
);
