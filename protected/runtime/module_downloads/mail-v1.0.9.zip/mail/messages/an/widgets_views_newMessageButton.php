<?php
return array (
  'New message' => 'Nuevo mensache',
  'Send message' => 'Ninviar mensache',
);
