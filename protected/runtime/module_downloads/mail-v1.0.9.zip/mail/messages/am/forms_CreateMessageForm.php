<?php

return [
    'Message' => '',
    'Recipient' => '',
    'Subject' => '',
    'You cannot send a email to yourself!' => '',
];
