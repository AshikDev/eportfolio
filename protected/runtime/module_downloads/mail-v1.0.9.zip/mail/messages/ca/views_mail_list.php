<?php
return array (
  'There are no messages yet.' => 'No tens cap missatge.',
);
