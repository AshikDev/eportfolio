<?php
return array (
  'Sign up now' => 'Registrer deg nå',
);
