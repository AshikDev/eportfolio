<?php
return array (
  'There are no messages yet.' => 'Det er ingen meldinger her enda.',
);
