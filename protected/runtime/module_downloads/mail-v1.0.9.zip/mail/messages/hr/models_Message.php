<?php
return array (
  'New message from {senderName}' => 'Nova poruka od {senderName}',
  'and {counter} other users' => 'i {counter} ostali korisnici',
);
