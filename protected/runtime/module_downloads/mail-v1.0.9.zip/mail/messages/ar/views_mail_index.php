<?php

return [
    'Conversations' => '',
    'New' => 'جديد',
    'There are no messages yet.' => 'لا توجد رسائل',
];
