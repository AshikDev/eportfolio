<?php
return [
    '<strong>Twitch</strong> Chat' => '<strong>Twitch</strong> Sohbet',
    'Discord Settings' => 'Twitch Ayarlar',
    'Twitch URL:' => 'Twitch URL:',
    '<strong>Twitch</strong> module configuration' => '<strong>Twitch</strong> modül yapılandırması',
    'Save' => 'Kaydet',
];
