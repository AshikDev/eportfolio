<?php

	return [
		'<strong>Twitch</strong> Chat' => '<strong>Twitch</strong> Chat',
		'Discord Settings' => 'Twitch Settings',
		'Twitch URL:' => 'Twitch URL:',
		'<strong>Twitch</strong> module configuration' => '<strong>Twitch</strong> module configuration',
		'Save' => 'Save',
	];
