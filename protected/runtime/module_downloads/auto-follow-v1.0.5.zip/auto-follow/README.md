## Description

Define an automatic following for new or already registered users.


__Author:__ HumHub
__Author website:__ [www.humhub.org](http://www.humhub.org)