Changelog
=========


1.0.5  (February 2, 2019)
-----------------------
- Fix: Handle soft deleted users


1.0.1  (June 13, 2018)
-----------------------
- Fix: Removed auto send notification on

